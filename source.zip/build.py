#!/usr/bin/env python3
"""CouponDepots static site generator.

Run:  python3 build.py   ->  writes the full site into ./site
Add a vendor: append a dict to BRANDS (and its offers) and rebuild.
"""
import html, json, os, re, shutil, datetime
import markdown

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "site")
BASE = "https://coupondepots.info"
# Build date (US Eastern). The site deploys daily, so "Updated" labels and sitemap dates stay fresh.
# Override for testing with BUILD_DATE=YYYY-MM-DD.
TODAY = os.environ.get("BUILD_DATE") or (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=5)).date().isoformat()
def human_date(iso):
    d = datetime.date.fromisoformat(iso)
    return f"{d:%B} {d.day}, {d.year}"
TODAY_HUMAN = human_date(TODAY)
SITE = "CouponDepots"
EMAIL = "admin@coupondepots.info"
PHONE = "(313) 729-1534"
PHONE_TEL = "+13137291534"
GSV = "f5EBxMKiRzq4QLfrGuWn0_knSgEWnAcJ2Pe1cTImSNU"
IMPACT = "https://utt.impactcdn.com/P-A7726983-53fa-48ae-8dc4-a8dc062c5b021.js"
# Footer social links point to GetServices.ai, the team behind CouponDepots.
# Icons: Simple Icons (CC0), https://simpleicons.org. To change a link, edit the URL here and run build.py.
SOCIAL = [
    ("LinkedIn", "https://www.linkedin.com/company/www-getservices-ai/"),
    ("Facebook", "https://www.facebook.com/profile.php?id=61593811161300"),
    ("Instagram", "https://www.instagram.com/getservices.ai/"),
    ("YouTube", "https://www.youtube.com/@Agent4Business"),
    ("X", "https://x.com/getservicesai"),
]
SOCIAL_ICONS = {
    "LinkedIn": "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z",
    "Facebook": "M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z",
    "Instagram": "M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077",
    "YouTube": "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z",
    "X": "M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"
}
# sameAs = profiles that belong to CouponDepots itself (its own Facebook page).
SAME_AS = ["https://www.facebook.com/1358114907379644"]

def awin(mid, aff, campaign=None, ued=None):
    u = f"https://www.awin1.com/cread.php?awinmid={mid}&awinaffid={aff}"
    if campaign:
        u += "&campaign=" + campaign
    if ued:  # deep link to a specific merchant page. Help: https://help.awin.com/s/article/What-is-a-deeplink
        from urllib.parse import quote
        u += "&ued=" + quote(ued, safe="")
    return u

# ---------------------------------------------------------------- vendors
# Affiliate links copied exactly from the live coupondepots.info pages.
BRANDS = [
    dict(slug="monvane", name="Monvane", cat="home", cat_label="Home & Furniture",
         img="local:monvane", link=awin(127859, 3067297),
         tagline="Modular boneless sofas built for everyday living",
         short="Modular boneless sofas with deep seating, high-resilience foam and recyclable materials."),
    dict(slug="simple-project", name="Simple Project US", cat="home", cat_label="Home Improvement",
         img="local:simple-project", link=awin(99013, 3067297),
         tagline="Macerating toilets and bathroom upgrades",
         short="Bathroom upgrades including the SNFLEX macerating toilet, with free shipping, 30-day returns and a 1-year warranty."),
    dict(slug="everblog", name="Everblog", cat="home", cat_label="Smart Home & Kitchen",
         img="local:everblog", link=awin(128579, 3075433),
         tagline="FridgeCal smart family calendar display",
         short="FridgeCal, a smart family display for kitchen planning, shared calendars and household organization."),
    dict(slug="zlike-hair", name="Zlike Hair", cat="beauty", cat_label="Beauty & Hair",
         img="local:zlike-hair", link=awin(102013, 3067297),
         tagline="Glueless lace wigs, extensions and textures",
         short="Wigs, extensions and style-focused hair, including glueless lace wigs and 300% density styles."),
    dict(slug="brkox", name="BRKOX", cat="hobbies", cat_label="Hobbies & Collectibles",
         img="local:brkox", link=awin(129093, 3067297, "BRKOX+US+Affiliate+Push"),
         tagline="Display cases and light kits for LEGO builds",
         short="Display cases and light kits that keep LEGO builds visible and protected from everyday dust."),
    dict(slug="fntcase", name="FNTCASE", cat="tech", cat_label="Phone Cases & Accessories",
         img="local:fntcase", link=awin(45915, 3067297),
         tagline="Rugged, MagSafe and clear cases for iPhone and Samsung",
         short="Protective phone cases for iPhone, Samsung, Google Pixel and Motorola, from rugged belt-clip holsters to slim MagSafe and clear designs."),
]
B = {b["slug"]: b for b in BRANDS}
for b in BRANDS:
    b["url"] = f"/store/{b['slug']}-coupon-code/"

# Offers shown on the one-page coupon board (home). type: code | deal
OFFERS = [
    dict(brand="monvane", type="code", code="MONAFF10", value="10%", unit="OFF",
         title="10% off for new customers",
         detail="No minimum spend. Can be combined with spend-based discounts. One use per customer.",
         label="Brand code"),
    dict(brand="monvane", type="code", code="AFF5OFF", value="5%", unit="OFF",
         title="5% off sitewide, unlimited use", img="local:monvane-u",
         detail="No minimum spend. Use it as often as you like.", label="Brand code"),
    dict(brand="monvane", type="deal", value="$139", unit="FROM",
         title="Oversized Sofa Bed: 3-in-1 sofa, lounger & sleeper", img="local:monvane-room",
         detail="Ideal for apartments and small spaces. Stack it with code MONAFF10 if you're a new customer.",
         label="Featured product"),
    dict(brand="everblog", type="deal", value="NEW", unit="",
         title="FridgeCal smart family calendar",
         detail="Shared calendars, reminders and kitchen planning in one fridge display. Check current pricing on Everblog.",
         label="Featured deal"),
    dict(brand="zlike-hair", type="deal", value="SHOP", unit="",
         title="Glueless lace wigs & 300% density styles",
         detail="Body Wave, Water Wave and layered looks. Check Zlike Hair for current promotions.",
         label="Featured deal"),
    dict(brand="brkox", type="deal", value="SHOP", unit="",
         title="LEGO display cases & light kits",
         detail="Dust protection and lighting for your favorite builds. See current BRKOX offers.",
         label="Featured deal"),
    dict(brand="fntcase", type="deal", value="SHOP", unit="",
         title="iPhone 17 & Samsung cases from $18.99",
         detail="Rugged kickstand and belt-clip holsters, MagSafe ring-stand cases and clear cases. Free shipping per FNTCASE's site; check current prices there.",
         label="Featured deal"),
]

# Merchant images: downloaded from each brand's own Shopify CDN by the GitHub
# Action (fetch_images.py) and served from /img/ as WebP. Keep in sync with images.json.
LOCAL_IMG = json.load(open(os.path.join(ROOT, "images.json"), encoding="utf-8"))
LOCAL_IMG = {d["name"]: d for d in LOCAL_IMG}
LOCAL_STEPS = [480, 800, 1200, 1600, 2000]

def local_widths(name):
    d = LOCAL_IMG[name]
    ws = [x for x in LOCAL_STEPS if x < d["w"]]
    return ws + [min(d["w"], 2000)]

# ---------------------------------------------------------------- PROMOS (email-to-site pipeline)
# promos.json is written daily by automation/promo-pipeline.gs from the Awin promo emails in
# Gmail (see automation/README.md). New brands and codes in it are added to the site here;
# expired offers drop off automatically.
PROMO_FILE = os.environ.get("PROMOS_JSON", os.path.join(ROOT, "promos.json"))
IMG_DIR = os.environ.get("IMG_DIR", os.path.join(ROOT, "img"))
BLOCKED_MIDS = {131143, 113386}   # adult / cannabis programs are never published (brand safety)
DEFAULT_DAYS = 30                  # codes with no end date in the email are listed for 30 days
HOME_PER_BRAND = 2                 # homepage shows up to 2 offers per new brand; store pages show all
PROMO_CONFIG, PROMO_STATS = {}, {"added": 0, "expired": 0}

def load_promos():
    if not os.path.exists(PROMO_FILE):
        return
    data = json.load(open(PROMO_FILE, encoding="utf-8"))
    PROMO_CONFIG.update(data.get("config", {}))
    by_mid = {}
    for pb in data.get("brands", []):
        if pb.get("blocked") or pb["mid"] in BLOCKED_MIDS:
            continue
        slug = pb["slug"]
        if slug in B:                      # brand already hand-built in BRANDS
            B[slug]["mid"] = pb["mid"]
            by_mid[pb["mid"]] = slug
            continue
        im = pb.get("image") or {}
        imgid = im.get("src", "")
        if imgid:
            LOCAL_IMG[slug] = dict(name=slug, src=im["src"], w=int(im.get("w", 1600)), h=int(im.get("h", 900)),
                                   pos=im.get("pos", "50% 50%"), alt=im.get("alt", pb["name"]))
            if os.path.exists(os.path.join(IMG_DIR, f"{slug}-{local_widths(slug)[0]}.webp")):
                imgid = "local:" + slug      # optimized copy saved by fetch_images.py
            else:
                del LOCAL_IMG[slug]          # not downloaded yet: use the merchant's own image URL
        if not imgid:
            continue                         # a real image is required; skip until one is available
        b = dict(slug=slug, name=pb["name"], cat=pb.get("cat", "home"), cat_label=pb.get("cat_label", "Featured brand"),
                 img=imgid, link=pb.get("link") or awin(pb["mid"], pb.get("aff", 3067297)), tagline=pb.get("tagline", ""),
                 short=pb.get("short", ""), site=pb.get("site", ""), topic=pb.get("topic", ""), promo=True, mid=pb["mid"], aff=pb.get("aff", 3067297))
        b["url"] = f"/store/{slug}-coupon-code/"
        BRANDS.append(b)
        B[slug] = b
        by_mid[pb["mid"]] = slug
    rank, fresh = {}, []
    for po in data.get("offers", []):
        slug = by_mid.get(po.get("mid"))
        if not slug:
            continue
        exp = po.get("expires") or (datetime.date.fromisoformat(po["listed"]) + datetime.timedelta(days=DEFAULT_DAYS)).isoformat()
        if exp < TODAY:
            PROMO_STATS["expired"] += 1
            continue
        if po.get("starts") and po["starts"] > TODAY:
            continue
        b = B[slug]
        when = f"Ends {human_date(exp)}." if po.get("expires") else f"Listed {human_date(po['listed'])}; confirm the terms at checkout."
        o = dict(brand=slug, type="code" if po.get("code") else "deal", code=po.get("code", ""),
                 value=po.get("value", "DEAL"), unit=po.get("unit", ""), title=po["title"],
                 detail=(po.get("detail", "").rstrip() + " " + when).strip(),
                 label="Brand code" if po.get("code") else "Featured deal",
                 holiday=bool(po.get("holiday")), expires=exp, real_exp=bool(po.get("expires")))
        if po.get("url"):
            # A non-Awin brand (e.g. Rakuten) gives its own tracking link in "link"
            o["link"] = po.get("link") or awin(po["mid"], b.get("aff", 3067297), ued=po["url"])
        rank[slug] = rank.get(slug, 0) + 1
        o["home"] = rank[slug] <= HOME_PER_BRAND
        fresh.append(o)
        PROMO_STATS["added"] += 1
    OFFERS[:0] = fresh                       # newest codes lead the board

def home_offers():
    """Homepage grid: one card per brand (its best offer), so the same or look-alike product photo never repeats.
    Extra codes for that brand stay on its store page and the Black Friday page."""
    seen, out = set(), []
    for o in OFFERS:
        if not o.get("home", True):
            continue
        pic = o.get("img") or B[o["brand"]]["img"]
        if pic in seen or o["brand"] in seen:   # one card per brand: no repeated or look-alike product photos
            continue
        seen.update({pic, o["brand"]})
        out.append(o)
    return out

def store_content_for(b):
    """Store-guide copy for brands added by the promo pipeline (hand-written brands use STORE_CONTENT)."""
    offers = [o for o in OFFERS if o["brand"] == b["slug"]]
    codes = [o for o in offers if o["type"] == "code"]
    n, name = len(codes), b["name"]
    lead = f"{n} {name} coupon code{'s' if n != 1 else ''}" if n else "Deals & Offers"
    items = "".join(f"<li><strong>{e(o['code'])}</strong>: {e(o['title'])}</li>" for o in codes)
    current = f"<ul>{items}</ul>" if items else "<p>No code is needed for the current offers. The discount applies on the merchant's site.</p>"
    body = (f"<h2>Current {e(name)} codes</h2>{current}"
            f"<h2>How to use a {e(name)} coupon code</h2>"
            f'<ol class="howto"><li><strong>Reveal the code.</strong> Tap <em>Show code</em> above. We copy it for you and open {e(name)} in a new tab.</li>'
            "<li><strong>Add the right product.</strong> Some codes apply only to the model named on the card.</li>"
            "<li><strong>Paste it at checkout</strong> in the promo or discount field and confirm the price drops before you pay.</li></ol>"
            '<div class="callout"><strong>Tip:</strong> Merchants can end or change codes early. If a code doesn\'t work, try another code on this page or <a href="/contact/">tell us</a> and we\'ll recheck it.</div>')
    current_q = ("Current codes: " + "; ".join(f"{o['code']} ({o['title']})" for o in codes) + ".") if codes else f"{name} currently has deals that don't need a code. See the offers above."
    return dict(
        title=(f"{name} Coupon Codes ({datetime.date.fromisoformat(TODAY):%B %Y}): {lead.replace(name + ' coupon code', 'Code')} | CouponDepots"
               if n else f"{name} Deals ({datetime.date.fromisoformat(TODAY):%B %Y}) | CouponDepots"),
        desc=f"Current {name} coupon codes and deals from {name}'s official affiliate program: {', '.join(o['code'] for o in codes[:4]) or 'latest offers'}. How to apply them and common questions.",
        h1=f"{name} Coupon Codes & Deals",
        intro=(b["short"] or b["tagline"]) + f" These offers come from {name}'s official affiliate program and are updated as {name} releases them.",
        body=body,
        faqs=[(f"Which {name} coupon codes work right now?", current_q),
              (f"Where do these {name} codes come from?", f"From {name}'s official affiliate program on Awin. We list them as {name} releases them and remove them when they end."),
              (f"Does {name} have Black Friday deals?", f'We add {name}\'s Black Friday and Cyber Monday codes here and on our <a href="/black-friday-deals/">Black Friday page</a> as soon as {name} releases them.'),
              ("Does CouponDepots earn from these links?", 'Yes. We may earn a commission when you buy through our sponsored link, at no extra cost to you. See our <a href="/disclosure/">affiliate disclosure</a>.')])

def U(id_, w=1200, h=None, q=80):
    if id_.startswith("http"):
        return id_
    if id_.startswith("local:"):
        name = id_[6:]
        if w == 1200 and h == 630:
            return f"{BASE}/img/{name}-og.jpg"
        ws = local_widths(name)
        best = next((x for x in ws if x >= w), ws[-1])
        return f"/img/{name}-{best}.webp"
    s = f"https://images.unsplash.com/photo-{id_}?auto=format&fit=crop&w={w}&q={q}"
    if h:
        s += f"&h={h}"
    return s

def img(id_, alt, w=800, h=500, lazy=True, cls="", sizes="(max-width: 700px) 100vw, 400px", hero=False, pos=None):
    load = 'loading="lazy" decoding="async"' if lazy else 'fetchpriority="high" decoding="async"'
    if id_.startswith("local:"):
        name = id_[6:]
        d = LOCAL_IMG[name]
        srcset = ", ".join(f"/img/{name}-{x}.webp {x}w" for x in local_widths(name))
        style = f' style="object-position:{d.get("pos", "50% 50%")}"'
        return (f'<img class="{cls}" src="{U(id_, w)}" srcset="{srcset}" sizes="{sizes}" '
                f'width="{d["w"]}" height="{d["h"]}" alt="{html.escape(alt)}"{style} {load}>')
    if id_.startswith("http"):  # merchant image URL, used until the optimized copy is saved
        return f'<img class="{cls}" src="{html.escape(id_)}" width="{w}" height="{h}" alt="{html.escape(alt)}" style="object-fit:cover" {load}>'
    widths = [640, 960, 1280, 1920, 2560] if hero else [480, 720, 960, 1280]
    ratio = h / w
    srcset = ", ".join(f"{html.escape(U(id_, x, int(x * ratio)))} {x}w" for x in widths)
    style = f' style="object-position:{pos}"' if pos else ""
    return (f'<img class="{cls}" src="{html.escape(U(id_, w, h))}" srcset="{srcset}" sizes="{sizes}" '
            f'width="{w}" height="{h}" alt="{html.escape(alt)}"{style} {load}>')

def e(s):
    return html.escape(s, quote=True)

def aff_a(brand, text, cls="btn btn-gold", extra=""):
    b = B[brand]
    return (f'<a class="{cls}" href="{e(b["link"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" '
            f'data-brand="{b["slug"]}" {extra}>{text}</a>')

# ---------------------------------------------------------------- layout
ICON_TICKET = '<svg viewBox="0 0 24 24" aria-hidden="true" width="26" height="26" fill="currentColor"><g transform="rotate(-14 12 12)"><path fill-rule="evenodd" d="M4 7.6A1.6 1.6 0 0 1 5.6 6h12.8A1.6 1.6 0 0 1 20 7.6v2.1a2.3 2.3 0 0 0 0 4.6v2.1a1.6 1.6 0 0 1-1.6 1.6H5.6A1.6 1.6 0 0 1 4 16.4v-2.1a2.3 2.3 0 0 0 0-4.6V7.6ZM15.1 7.4h.9v1.5h-.9ZM15.1 10.1h.9v1.5h-.9ZM15.1 12.8h.9v1.5h-.9ZM15.1 15.5h.9v1.1h-.9ZM8.5 8.9a1.05 1.05 0 1 0 0 2.1a1.05 1.05 0 1 0 0-2.1ZM11.3 13a1.05 1.05 0 1 0 0 2.1a1.05 1.05 0 1 0 0-2.1ZM11.6 8.7l.85.55-4.3 6.25-.85-.55Z"/></g></svg>'
ARROW = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M13.2 5.3 19.9 12l-6.7 6.7-1.4-1.4 4.3-4.3H4v-2h12.1l-4.3-4.3 1.4-1.4Z"/></svg>'

NAV = [("Coupons", "/#deals"), ("Black Friday", "/black-friday-deals/"), ("Stores", "/#stores"), ("Guides", "/blog/"), ("How we verify", "/how-we-verify/")]

def header(active=""):
    links = "".join(f'<a href="{h}"{" aria-current=\"page\"" if active == t else ""}>{t}</a>' for t, h in NAV)
    return f'''<div class="disclosure-bar">Some links are affiliate links. We may earn a commission at no extra cost to you. <a href="/disclosure/">Read our affiliate disclosure</a></div>
<header class="site-header">
  <div class="wrap nav-row">
    <a class="logo" href="/" aria-label="CouponDepots home"><span class="logo-mark">{ICON_TICKET}</span><span>Coupon<b>Depots</b></span></a>
    <nav class="main-nav" id="main-nav" aria-label="Main">{links}<a class="nav-cta" href="/contact/#partner">Partner with us</a></nav>
    <button class="nav-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="main-nav"><span></span><span></span></button>
  </div>
</header>
{cat_bar()}'''

# Footer store links name what shoppers search for, not the brand (e.g. "Furniture coupons").
# New brands from promos.json can set "topic"; otherwise "<category> coupons" is used.
FOOTER_TOPICS = {
    "monvane": "Furniture coupons", "simple-project": "Bathroom coupons", "everblog": "Smart home coupons",
    "zlike-hair": "Wig & hair coupons", "brkox": "LEGO display coupons", "fntcase": "Phone case coupons",
    "sirui": "Camera lens coupons", "alorair": "Crawl space dehumidifier coupons", "argendon": "Commercial dehumidifier coupons",
    "bedsure": "Bedding coupons", "thedryair": "Air scrubber & restoration coupons", "piscifun": "Fishing gear coupons",
    "outfitr": "Bike rack coupons", "plunge-chill": "Cold plunge coupons",
}

def topic_label(b):
    return b.get("topic") or FOOTER_TOPICS.get(b["slug"]) or f'{b["cat_label"]} coupons'

def footer():
    stores = "".join(f'<li><a href="{b["url"]}" title="{e(b["name"])} coupon codes">{e(topic_label(b))}</a></li>' for b in BRANDS)
    soc = "".join(f'<a class="social" href="{e(u)}" target="_blank" rel="noopener noreferrer" aria-label="GetServices.ai on {n}" title="GetServices.ai on {n}"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="{SOCIAL_ICONS[n]}"/></svg></a>' for n, u in SOCIAL)
    return f'''<footer class="site-footer">
  <div class="wrap footer-grid">
    <div class="footer-brand">
      <a class="logo logo-light" href="/"><span class="logo-mark">{ICON_TICKET}</span><span>Coupon<b>Depots</b></span></a>
      <p>Featured brand coupons and shopping guides from brands we work with directly through official affiliate networks.</p>
      <p class="small"><a href="mailto:{EMAIL}">{EMAIL}</a><br><a href="tel:{PHONE_TEL}">{PHONE}</a><br>Massachusetts, USA</p>
      <p class="socials-label">Follow <a href="https://getservices.ai/" target="_blank" rel="noopener">GetServices.ai</a>, the team behind CouponDepots</p><div class="socials" aria-label="GetServices.ai social profiles">{soc}</div>
    </div>
    <div><h3>Stores</h3><ul>{stores}</ul></div>
    <div><h3>Guides</h3><ul><li><a href="/black-friday-deals/">Black Friday deals</a></li><li><a href="/holiday-gift-guide/">Holiday gift guide</a></li><li><a href="/blog/">All shopping guides</a></li><li><a href="/blog/3-upgrades-save-money-2026/">Home &amp; beauty upgrades</a></li><li><a href="/blog/best-home-lifestyle-deals-may-2026/">Home &amp; lifestyle guide</a></li><li><a href="/blog/save-money-online-every-week/">Save money every week</a></li><li><a href="/blog/best-stores-online-coupons/">Best stores for coupons</a></li></ul></div>
    <div><h3>Company</h3><ul><li><a href="/about/">About</a></li><li><a href="/how-we-verify/">How we verify</a></li><li><a href="/contact/">Contact</a></li><li><a href="/contact/#submit">Submit a coupon</a></li><li><a href="/disclosure/">Affiliate disclosure</a></li><li><a href="/privacy/">Privacy</a></li><li><a href="/terms/">Terms</a></li></ul></div>
  </div>
  <div class="wrap footer-base"><span>&copy; <span data-year>2026</span> CouponDepots. All rights reserved.</span><span>Prices and promotions are set by merchants and can change. Always confirm at checkout.</span></div>
</footer>'''

ORG = {"@type": "Organization", "@id": f"{BASE}/#organization", "name": SITE, "url": f"{BASE}/",
       "logo": {"@type": "ImageObject", "url": f"{BASE}/assets/logo.png", "width": 512, "height": 512},
       "email": EMAIL, "telephone": "+1-313-729-1534",
       "address": {"@type": "PostalAddress", "addressRegion": "MA", "addressCountry": "US"},
       "sameAs": SAME_AS}
WEBSITE = {"@type": "WebSite", "@id": f"{BASE}/#website", "name": SITE, "url": f"{BASE}/",
           "publisher": {"@id": f"{BASE}/#organization"}, "inLanguage": "en-US",
           "potentialAction": {"@type": "SearchAction",
                               "target": {"@type": "EntryPoint", "urlTemplate": f"{BASE}/?q={{search_term_string}}#deals"},
                               "query-input": "required name=search_term_string"}}

def crumbs(items):
    return {"@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": i + 1, "name": n, "item": BASE + p} for i, (n, p) in enumerate(items)]}

def faq_schema(faqs):
    return {"@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": re.sub(r"<[^>]+>", "", a)}}
        for q, a in faqs]}

def faq_html(faqs, title="Frequently asked questions", eyebrow="Helpful answers"):
    items = "".join(f'<details class="faq"><summary>{e(q)}</summary><div class="faq-a"><p>{a}</p></div></details>' for q, a in faqs)
    return f'<section class="section" id="faq"><div class="wrap narrow"><p class="eyebrow">{eyebrow}</p><h2>{title}</h2><div class="faq-list">{items}</div></div></section>'

def clip(text, n=158):
    """Search results cut descriptions at about 160 characters. Help: https://developers.google.com/search/docs/appearance/snippet"""
    text = " ".join(text.split())
    return text if len(text) <= n else text[:n - 1].rsplit(" ", 1)[0].rstrip(",;:") + "…"

import hashlib
# Cache-busting: the ?v= on style.css/app.js is a fingerprint of the file, so browsers fetch the new file
# the moment it changes (no stale styles after a deploy). Help: https://web.dev/articles/http-cache
def _fp(rel):
    return hashlib.sha1(open(os.path.join(ROOT, "static", rel), "rb").read()).hexdigest()[:8]
ASSET_VER = {"css": _fp("assets/style.css"), "js": _fp("assets/app.js")}

def page(path, title, desc, body, schema=None, og_img="1483181957632-8bda974cbc91", active="", og_type="website", extra_head=""):
    canon = BASE + path
    graph = [ORG, WEBSITE] + (schema or [])
    ld = json.dumps({"@context": "https://schema.org", "@graph": graph}, ensure_ascii=False, separators=(",", ":"))
    ogimg = U(og_img, 1200, 630)
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(title)}</title>
<meta name="description" content="{e(clip(desc))}">
<link rel="canonical" href="{canon}">
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">
<meta name="google-site-verification" content="{GSV}">
<meta name="theme-color" content="#0b1020">
<meta property="og:site_name" content="{SITE}">
<meta property="og:type" content="{og_type}">
<meta property="og:title" content="{e(title)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:url" content="{canon}">
<meta property="og:image" content="{e(ogimg)}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{e(title)}">
<meta name="twitter:description" content="{e(desc)}">
<meta name="twitter:image" content="{e(ogimg)}">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/assets/logo.png">
<link rel="preconnect" href="https://images.unsplash.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap"></noscript>
<link rel="stylesheet" href="/assets/style.css?v={ASSET_VER['css']}">
<link rel="alternate" type="text/plain" href="/llms.txt" title="LLM summary">
{extra_head}<script type="application/ld+json">{ld}</script>
<script>
  /* Third-party scripts (Impact, Travelpayouts) load after the page is ready so they don't slow the first paint.
     Help: https://web.dev/articles/efficiently-load-third-party-javascript */
  (function () {{
    function add(src) {{ var s = document.createElement("script"); s.async = 1; s.src = src; s.setAttribute("data-cmp-ab", "2"); document.head.appendChild(s); }}
    function go() {{ add("{IMPACT}"); add("https://emrldtp.cc/NTg5NDYw.js?t=589460"); }}
    var idle = window.requestIdleCallback || function (f) {{ return setTimeout(f, 1500); }};
    if (document.readyState === "complete") idle(go); else window.addEventListener("load", function () {{ idle(go); }});
  }})();
</script>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
{header(active)}
<main id="main">
{body}
</main>
{footer()}
<script src="/assets/app.js?v={ASSET_VER['js']}" defer></script>
</body>
</html>
'''

def write(path, content):
    fp = os.path.join(OUT, path.lstrip("/"))
    if path.endswith("/"):
        fp = os.path.join(fp, "index.html")
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    with open(fp, "w", encoding="utf-8") as f:
        f.write(tag_clicks(path, content))

SITEMAP = []
def add_sm(path, lastmod=TODAY, prio="0.7"):
    SITEMAP.append((path, lastmod, prio))

# ---------------------------------------------------------------- components
def grid_cards(offers):
    """Coupon grid where each brand's photo appears once; its other offers show as compact cards."""
    seen, out = set(), []
    for o in offers:
        pic = o.get("img") or B[o["brand"]]["img"]
        out.append(offer_card(o, compact=pic in seen))
        seen.add(pic)
    return "".join(out)

def offer_card(o, compact=False):
    b = B[o["brand"]]
    adult = ' <span class="tag tag-adult">18+</span>' if b.get("adult") else ""
    if o["type"] == "code":
        cta = (f'<a class="btn btn-gold reveal" href="{e(o.get("link") or b["link"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" '
               f'data-code="{o["code"]}" aria-label="Show {b["name"]} code and open store"><span class="reveal-label">Show code</span>'
               f'<span class="reveal-peek" aria-hidden="true">{o["code"][-3:]}</span></a>')
        ctype = "code"
    elif o.get("link"):
        cta = (f'<a class="btn btn-gold" href="{e(o["link"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" '
               f'data-brand="{b["slug"]}">Get deal {ARROW}</a>')
        ctype = "deal"
    else:
        cta = aff_a(o["brand"], f'Get deal {ARROW}')
        ctype = "deal"
    search = f'{b["name"]} {b["cat_label"]} {o["title"]} {o.get("code","")}'.lower()
    oimg = o.get("img", b["img"])
    media = img(oimg, LOCAL_IMG[oimg[6:]]["alt"] if oimg.startswith("local:") else alt_for(b), 800, 450, cls="", sizes="(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 380px")
    unit_html = f'<span>{o["unit"]}</span>' if o["unit"] else ""
    badge = f'<span class="coupon-badge"><strong>{o["value"]}</strong>{unit_html}</span>'
    top = (f'<div class="coupon-mini">{badge}</div>' if compact else
           f'<a class="coupon-media" href="{b["url"]}" tabindex="-1" aria-hidden="true">{media}{badge}</a>')
    return f'''<article class="coupon{" coupon-compact" if compact else ""}" data-cat="{b["cat"]}" data-type="{ctype}" data-search="{e(search)}">
  {top}
  <div class="coupon-body">
    <div class="coupon-top"><a class="coupon-brand" href="{b["url"]}">{e(b["name"])}</a><span class="tag">{e(o["label"])}</span>{adult}</div>
    <h3>{e(o["title"])}</h3>
    <p>{e(o["detail"])}</p>
    <div class="coupon-actions">{cta}<a class="link-more" href="{o.get("url") or b["url"]}">{"Deal details" if o.get("url") else e(b["name"]) + " guide"}</a></div>
  </div>
</article>'''

def alt_for(b):
    if b.get("promo") and not b["img"].startswith("local:"):
        return f'{b["name"]}: {b["tagline"]}'
    if b["img"].startswith("local:"):
        return LOCAL_IMG[b["img"][6:]]["alt"]
    return b["tagline"]

def store_card(b):
    adult = '<span class="tag tag-adult">18+</span>' if b.get("adult") else ""
    n = sum(1 for o in OFFERS if o["brand"] == b["slug"])
    return f'''<a class="store-card" href="{b["url"]}">
  <div class="store-img">{img(b["img"], alt_for(b), 800, 500, sizes="(max-width: 600px) 100vw, (max-width: 1100px) 50vw, 380px")}</div>
  <div class="store-info"><div class="store-meta"><span>{e(b["cat_label"])}</span>{adult}</div>
  <h3>{e(b["name"])}</h3><p>{e(b["tagline"])}</p><span class="store-count">{n} offer{"s" if n != 1 else ""} {ARROW}</span></div>
</a>'''

# ---------------------------------------------------------------- AMAZON PICKS
# Amazon Associates. Help: https://affiliate-program.amazon.com/help/operating/agreement
# Rules this section follows:
#   - No prices, "% off" or star ratings here (Amazon only allows prices pulled live
#     from its Product Advertising API, which unlocks after 3 qualifying sales).
#   - No coupon codes for Amazon products.
#   - The exact disclosure sentence below must stay visible near these links.
# To add or swap a product: copy one dict in AMAZON_PICKS, set the ASIN (the 10-character
# code after /dp/ in the Amazon URL) and the image id (the part after /images/I/ in the
# product's main image URL, before the first dot), then run `python3 build.py`.
AMAZON_TAG = "get786-20"
AMAZON_UPDATED, AMAZON_UPDATED_HUMAN = "2026-10-29", "October 29, 2026"  # bump when you change AMAZON_PICKS
AMAZON_DISCLOSURE = "As an Amazon Associate I earn from qualifying purchases."
AMAZON_CATS = [("home", "Home & bath"), ("hair", "Hair & beauty"), ("gifts", "Cozy gifts"), ("office", "Home office")]
AMAZON_PICKS = [
    dict(asin="B0BQHYNMLN", photo="1721161249833-d7158f54ea77", img="81yut6-KmdL", cat="home", name="Simple Trending 3-Tier Over-the-Toilet Storage Rack",
         why="Turns the dead space above the toilet into three shelves plus a paper holder. Metal frame, no drilling into tile."),
    dict(asin="B00JG2DETM", photo="1569597967185-cd6120712154", img="61efKHI7IRL", cat="home", name="LUXE Bidet NEO 120 Bidet Attachment",
         why="Non-electric bidet that fits most standard toilets in minutes. A popular way to cut toilet-paper spending."),
    dict(asin="B07Q4MYZNC", photo="1652662700928-5a4685e87d64", img="71KM6FcBDWL", cat="home", name="FEELSO Filtered Shower Head for Hard Water",
         why="Multi-stage filter shower head aimed at hard water and chlorine. Swaps in without tools."),
    dict(asin="B01LSUQSB0", photo="1580618672591-eb180b1a973f", img="61SrWfdHa1L", cat="hair", name="REVLON One-Step Volumizer Hair Dryer & Styler",
         why="Dries and styles in one pass with a round, oval-barrel brush. One of the best-known hot-air brushes on Amazon."),
    dict(asin="B0725WFLMB", photo="1570786240066-c0d753711cfe", img="81yXFAw10nL", cat="hair", name="Bedsure Satin Pillowcases (Queen, Set of 2)",
         why="Smooth satin feel that helps reduce frizz and bedhead. An easy, low-cost hair-care upgrade."),
    dict(asin="B09S4PVZ81", photo="1579119159780-51419861f69f", img="41O0XIgrD8L", cat="hair", name="Kitsch Satin Heatless Curls Overnight Set",
         why="Satin rod and scrunchies for soft curls overnight, with no heat styling the next morning."),
    dict(asin="B0BZR6YBHK", photo="1674475760738-8c7af859f821", img="81qDj3mcqOL", cat="gifts", name="Bedsure Heated Throw Blanket with Preheat",
         why="Soft flannel electric throw with a fast preheat setting and auto shut-off. A favorite winter gift."),
    dict(asin="B0CTJGJL2T", photo="1668112037360-900ff60ef6f7", img="810vcJJDrkL", cat="gifts", name="GODONLIF Candle Warmer Lamp with Timer",
         why="Melts a jar candle from the top so you get the scent without an open flame. Includes a timer."),
    dict(asin="B09GRZXCB1", photo="1760914939520-fbd46a74dbd9", img="71QldrO3IEL", cat="gifts", name="Frameo 10.1\" Wi-Fi Digital Picture Frame",
         why="Family can send photos straight to the frame from the Frameo app. A thoughtful gift for parents and grandparents."),
    dict(asin="B0DB8F7GDN", photo="1510519138101-570d1dca3d66", img="81MeUftFm8L", cat="office", name="2-Tier Monitor Stand Riser with Drawer",
         why="Raises your screen toward eye level and adds a drawer and pen holders to clear the desk."),
    dict(asin="B0B5SW6381", photo="1688578735427-994ecdea3ea4", img="81NZbmjrfwL", cat="office", name="Memory Foam Office Chair Seat Cushion",
         why="Large memory-foam cushion for long desk days. Removable, washable cover."),
    dict(asin="B08923SXXP", photo="1519219788971-8d9797e0928e", img="61po0IyEmOL", cat="office", name="LED Desk Lamp with USB Ports",
         why="Touch-dimmable desk lamp with five light modes and a USB port to charge your phone."),
]
AMAZON_HELP = "https://affiliate-program.amazon.com/help/operating/agreement"
# Amazon-style theme: navy band, light-gray canvas, white cards, yellow buttons.
# Colors only. Amazon's logo/smile is not used. Help: https://affiliate-program.amazon.com/help/operating/trademarks
AMAZON_CSS = '''<style>.amz-theme{background:#eaeded;color:#0f1111}
.amz-band{background:#232f3e;color:#fff;padding:26px 0 22px;border-bottom:3px solid #ff9900}
.amz-band .eyebrow{color:#ff9900}.amz-band h2,.amz-band h1{color:#fff;margin:4px 0 0}.amz-band .muted,.amz-band p{color:#d5d9d9}
.amz-band a{color:#fff}.amz-band .link-more{color:#ffd814}
.amz-theme .amz-card{background:#fff;border:1px solid #d5d9d9;border-radius:8px;box-shadow:none}
.amz-theme .amz-card:hover{box-shadow:0 2px 10px rgba(15,17,17,.15)}
.amz-theme .amz-body h3{color:#0f1111}.amz-theme .amz-body p{color:#565959}
.amz-theme .tag{background:#fff3e0;color:#a52604;border:0}
.amz-theme .btn-gold{background:#ffd814;border:1px solid #fcd200;color:#0f1111;border-radius:999px;box-shadow:0 2px 5px rgba(213,217,217,.5);font-weight:600}
.amz-theme .btn-gold:hover{background:#f7ca00;border-color:#f2c200}
.amz-theme .amz-note{background:#fff;border:1px solid #d5d9d9;color:#565959}.amz-theme .amz-note a{color:#007185}
.amz-theme .amz-group{color:#0f1111;border-bottom:2px solid #ff9900;padding-bottom:6px;display:inline-block}
.amz-theme .amz-jump a{color:#007185}
.amz-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px}
.amz-card{display:flex;flex-direction:column;background:var(--card);border:1px solid var(--line);border-radius:var(--r);box-shadow:var(--shadow);overflow:hidden}
.amz-media{display:block;background:#f3f1ec;aspect-ratio:4/3}.amz-media img{width:100%;height:100%;object-fit:cover}
.amz-body{display:flex;flex-direction:column;flex:1;padding:16px 18px 18px}.amz-body h3{font-size:1.02rem;margin:8px 0 6px}
.amz-body p{font-size:.9rem;color:var(--muted);margin:0 0 14px}.amz-body .btn{margin-top:auto;width:100%}
.amz-note{margin-top:22px;padding:14px 16px;border:1px dashed var(--line);border-radius:var(--r-sm);background:var(--card);font-size:.88rem;color:var(--muted)}
.amz-note strong{color:var(--text)}.amz-head-cta{white-space:nowrap}
@media(max-width:1000px){.amz-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:520px){.amz-grid{grid-template-columns:1fr}}</style>'''

def amz_url(asin):
    return f"https://www.amazon.com/dp/{asin}?tag={AMAZON_TAG}"

def amz_img(img_id):
    # Not rendered: Amazon only allows its product images via its own tools
    # (Creators API), never copied or hotlinked. Cards are text-only.
    return f"https://m.media-amazon.com/images/I/{img_id}._AC_SL500_.jpg"

def amazon_card(p):
    cat = dict(AMAZON_CATS)[p["cat"]]
    # Real stock photo (Unsplash) for the category, not Amazon's own product image: Amazon images
    # are only allowed through its API (unlocks after 3 sales). Help: https://unsplash.com/license
    media = (f'<a class="amz-media" href="{amz_url(p["asin"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" tabindex="-1" aria-hidden="true">'
             f'{img(p["photo"], "Illustrative photo for " + p["name"], 600, 450, sizes="(max-width: 520px) 100vw, (max-width: 1000px) 50vw, 280px")}</a>') if p.get("photo") else ""
    return f'''<article class="amz-card" data-amz-cat="{p["cat"]}">
  {media}<div class="amz-body"><span class="tag">{e(cat)}</span>
    <h3>{e(p["name"])}</h3>
    <p>{e(p["why"])}</p>
    <a class="btn btn-gold" href="{amz_url(p["asin"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" aria-label="Check price for {e(p["name"])} on Amazon">Check price on Amazon {ARROW}</a>
  </div>
</article>'''

def amazon_note():
    return (f'<p class="amz-note"><strong>{AMAZON_DISCLOSURE}</strong> Prices and availability are shown on Amazon '
            f'and can change at any time, so we don\'t list them here. Photos are illustrative; see Amazon for the exact product. Clicking a product opens Amazon.com in a new tab. '
            f'<a href="/disclosure/">Affiliate disclosure</a> · <a href="{AMAZON_HELP}" target="_blank" rel="noopener noreferrer">Amazon Associates program terms</a></p>')


# TaztyCandy product carousel (30 real products, Awin 117075). Help: arrows/swipe browse the rail;
# regenerate from seo-controller affiliate-data/products/117075.json when products change.
TAZTY_CAROUSEL = '<section class="gsc" id="gsc-taztycandy" data-gsc aria-labelledby="gsc-taztycandy-h"><div class="gsc-head"><div><span class="gsc-eyebrow">Featured brand · TaztyCandy</span><h2 id="gsc-taztycandy-h">Swedish Candy Boxes &amp; Pick-and-Mix</h2><p class="gsc-sub">Authentic Swedish sweets, sour mixes and candy discovery boxes from TaztyCandy, shipped across the US.</p></div><div class="gsc-nav"><button type="button" class="gsc-btn gsc-prev" aria-label="Previous TaztyCandy products" aria-controls="gsc-taztycandy-rail">‹</button><button type="button" class="gsc-btn gsc-next" aria-label="Next TaztyCandy products" aria-controls="gsc-taztycandy-rail">›</button></div></div><div class="gsc-rail" id="gsc-taztycandy-rail" role="list" tabindex="0" aria-label="TaztyCandy products, scroll sideways"><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-1&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fswedish-candy-discovery-box-7-swedish-candy-favorites" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/Namnlosdesign_68.png?v=1791644350" alt="Swedish Candy Discovery Box – 7 Swedish Candy Favorites" width="250" height="250" loading="lazy" decoding="async"><b>Swedish Candy Discovery Box – 7 Swedish Candy Favorites</b><span class="gsc-price">$179.00<s>$229.00</s></span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-2&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Ftaste-of-sweden-box" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/Namnlosdesign_71.png?v=1791649493" alt="Taste of Sweden Box" width="250" height="250" loading="lazy" decoding="async"><b>Taste of Sweden Box</b><span class="gsc-price">$379.00<s>$548.00</s></span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-3&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fswedish-sour-candy-box" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/Namnlosdesign_70.png?v=1791648004" alt="Swedish Sour Candy Box" width="250" height="250" loading="lazy" decoding="async"><b>Swedish Sour Candy Box</b><span class="gsc-price">$299.00<s>$399.00</s></span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-4&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fbubs-swedish-candy-box-8-sweet-sour-candy-bags" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/Namnlosdesign_69.png?v=1791646919" alt="BUBS Swedish Candy Box – 8 Sweet &amp; Sour Candy Bags" width="250" height="250" loading="lazy" decoding="async"><b>BUBS Swedish Candy Box – 8 Sweet &amp; Sour Candy Bags</b><span class="gsc-price">$349.00<s>$449.00</s></span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-5&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fmaoam-happy-frutties-copy" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/Godispase_med_svart_rosett_2.png?v=1791446601" alt="MAOAM Happy Frutties Candy Bag 250g" width="250" height="250" loading="lazy" decoding="async"><b>MAOAM Happy Frutties Candy Bag 250g</b><span class="gsc-price">$25.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-6&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fswedish-candy-mix-300g" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/ChatGPT-bild25sep.202618_36_42_1_02ccab33-0426-456e-8ca9-bee49d251524.png?v=1790354801" alt="Swedish Candy Mix 300g" width="250" height="250" loading="lazy" decoding="async"><b>Swedish Candy Mix 300g</b><span class="gsc-price">$19.90</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-7&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fdeal-of-the-week-swedish-candy-mix-300g" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/ChatGPT-bild25sep.202618_36_42_1_02ccab33-0426-456e-8ca9-bee49d251524.png?v=1790354801" alt="Deal of the Week – Swedish Candy Mix 300g" width="250" height="250" loading="lazy" decoding="async"><b>Deal of the Week – Swedish Candy Mix 300g</b><span class="gsc-price">$19.90</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-8&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fmega-rhubarb-bites" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at20.00.31_1.jpg?v=1788200729" alt="Mega Rhubarb Bites" width="250" height="250" loading="lazy" decoding="async"><b>Mega Rhubarb Bites</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-9&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fsour-skulls" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at19.48.57_3.jpg?v=1788201072" alt="Sour Skulls" width="250" height="250" loading="lazy" decoding="async"><b>Sour Skulls</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-10&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fcoconut-dream" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at19.48.57_2.jpg?v=1788200248" alt="Coconut Dream" width="250" height="250" loading="lazy" decoding="async"><b>Coconut Dream</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-11&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fnotcreme-dubai-style" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at19.48.57_1.jpg?v=1788199959" alt="Nötcreme Dubai Style" width="250" height="250" loading="lazy" decoding="async"><b>Nötcreme Dubai Style</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-12&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fnotcreme-creamy-peanut" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at19.48.57.jpg?v=1788199768" alt="Nötcreme Creamy Peanut" width="250" height="250" loading="lazy" decoding="async"><b>Nötcreme Creamy Peanut</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-13&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Flicorice-sticks" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at19.30.17_1.jpg?v=1788198116" alt="Licorice Sticks" width="250" height="250" loading="lazy" decoding="async"><b>Licorice Sticks</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-14&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fmalaco-salt-herring" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at19.30.17.jpg?v=1788197488" alt="Malaco Salt Herring" width="250" height="250" loading="lazy" decoding="async"><b>Malaco Salt Herring</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-15&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fnotcreme-cookies-cream" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at19.16.09_1.jpg?v=1788197349" alt="Nötcreme Cookies &amp; Cream" width="250" height="250" loading="lazy" decoding="async"><b>Nötcreme Cookies &amp; Cream</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-16&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fnotcreme-banana-caramel" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-31at19.16.09.jpg?v=1788197043" alt="Nötcreme Banana Caramel" width="250" height="250" loading="lazy" decoding="async"><b>Nötcreme Banana Caramel</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-17&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Ftyrkisk-peber-hot-rings" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at22.30.09_4.jpg?v=1788196275" alt="Tyrkisk Peber Hot Rings" width="250" height="250" loading="lazy" decoding="async"><b>Tyrkisk Peber Hot Rings</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-18&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fchocolate-foam-mushrooms" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at22.30.09_2.jpg?v=1788195895" alt="Chocolate Foam Mushrooms" width="250" height="250" loading="lazy" decoding="async"><b>Chocolate Foam Mushrooms</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-19&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fmini-dolphin" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at22.30.09_1.jpg?v=1788195377" alt="Mini Dolphin" width="250" height="250" loading="lazy" decoding="async"><b>Mini Dolphin</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-20&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fstrawberry-foam-loaves" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at22.30.09.jpg?v=1788195088" alt="Strawberry Foam Loaves" width="250" height="250" loading="lazy" decoding="async"><b>Strawberry Foam Loaves</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-21&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fmini-chocolate-banana" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.46_1.jpg?v=1788194924" alt="Mini Chocolate Banana" width="250" height="250" loading="lazy" decoding="async"><b>Mini Chocolate Banana</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-22&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fmormor-lisas-coconut-ball" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.46.jpg?v=1788194432" alt="Mormor Lisas Coconut Ball" width="250" height="250" loading="lazy" decoding="async"><b>Mormor Lisas Coconut Ball</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-23&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fveggie-sour-pomegranate-cherry-skulls" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.45_2_0893c872-5e41-4093-a9d6-47f32c3e4499.jpg?v=1788194225" alt="Veggie Sour Pomegranate &amp; Cherry Skulls" width="250" height="250" loading="lazy" decoding="async"><b>Veggie Sour Pomegranate &amp; Cherry Skulls</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-24&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fbrown-licorice-twist" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.45_1_70e4ba3c-fc48-4ebe-afe2-49d4f50f8b08.jpg?v=1788193926" alt="Brown Licorice Twist" width="250" height="250" loading="lazy" decoding="async"><b>Brown Licorice Twist</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-25&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fnotcreme-passion-fruit-chocolate" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.45_6eb52ae3-6e25-4f57-8d0c-0bf26189aad7.jpg?v=1788193596" alt="Nötcreme Passion Fruit" width="250" height="250" loading="lazy" decoding="async"><b>Nötcreme Passion Fruit</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-26&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Ffazer-tutti-frutti-passion" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.45_2.jpg?v=1788124520" alt="Fazer Tutti Frutti Passion" width="250" height="250" loading="lazy" decoding="async"><b>Fazer Tutti Frutti Passion</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-27&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Frainbow-sour-belts" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.45_1.jpg?v=1788124172" alt="Rainbow Sour Belts" width="250" height="250" loading="lazy" decoding="async"><b>Rainbow Sour Belts</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-28&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fremix-duo" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.45.jpg?v=1788123991" alt="ReMix Duo" width="250" height="250" loading="lazy" decoding="async"><b>ReMix Duo</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-29&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fnotcreme-orange" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.15_4.jpg?v=1788123699" alt="Nötcreme Orange" width="250" height="250" loading="lazy" decoding="async"><b>Nötcreme Orange</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a><a class="gsc-card" role="listitem" href="https://www.awin1.com/cread.php?awinmid=117075&amp;awinaffid=3067297&amp;clickref=coupondepots-tazty-30&amp;ued=https%3A%2F%2Fwww.taztycandy.com%2Fproducts%2Fsour-monsters" target="_blank" rel="sponsored nofollow noopener"><img src="https://cdn.shopify.com/s/files/1/0914/9880/7641/files/WhatsAppImage2026-08-30at21.57.15_3.jpg?v=1788123394" alt="Sour Monsters" width="250" height="250" loading="lazy" decoding="async"><b>Sour Monsters</b><span class="gsc-price">$9.00</span><span class="gsc-go">View deal →</span></a></div><p class="gsc-note">Sponsored partner links: we may earn a commission at no extra cost to you. Use the arrows (or swipe) to browse all 30 picks; prices and stock change often, so check TaztyCandy for current details. <a href="/disclosure/">How we earn</a>.</p></section>\n<!-- gsc:assets (product carousels with left/right arrows; help: affiliate links open the retailer in a new tab) -->\n<style id="gsc-style">.gsc{margin:48px auto;max-width:1200px;padding:0 20px}.gsc-head{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin-bottom:14px}.gsc-eyebrow{display:block;font-size:.76rem;letter-spacing:.12em;text-transform:uppercase;opacity:.7;margin-bottom:4px}.gsc h2{margin:0 0 6px;line-height:1.2}.gsc-sub{margin:0;opacity:.78;max-width:68ch}.gsc-nav{display:flex;gap:8px;flex:0 0 auto}.gsc-btn{width:44px;height:44px;border-radius:50%;border:1px solid rgba(127,127,127,.4);background:#fff;color:#111;font-size:22px;line-height:1;cursor:pointer;display:grid;place-items:center;box-shadow:0 2px 10px rgba(0,0,0,.08);transition:opacity .2s,transform .2s}.gsc-btn:hover{transform:translateY(-1px)}.gsc-btn:focus-visible{outline:3px solid #2563eb;outline-offset:2px}.gsc-btn[disabled]{opacity:.35;cursor:default;transform:none}.gsc-rail{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;scroll-behavior:smooth;padding:4px 2px 12px;scrollbar-width:thin;overscroll-behavior-x:contain}.gsc-card{flex:0 0 clamp(190px,23%,250px);scroll-snap-align:start;display:flex;flex-direction:column;border:1px solid rgba(127,127,127,.25);border-radius:14px;overflow:hidden;background:rgba(255,255,255,.04);text-decoration:none;color:inherit;transition:border-color .2s,transform .2s}.gsc-card:hover{border-color:currentColor;transform:translateY(-2px)}.gsc-card img{width:100%;aspect-ratio:1/1;object-fit:contain;background:#fff;display:block}.gsc-card b{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;padding:12px 14px 4px;font-size:.95rem;line-height:1.35}.gsc-price{padding:2px 14px;font-weight:700;font-size:.95rem}.gsc-price s{opacity:.55;font-weight:400;margin-left:6px;font-size:.85rem}.gsc-go{margin-top:auto;padding:8px 14px 14px;font-size:.85rem;font-weight:700;opacity:.85}.gsc-note{font-size:.8rem;opacity:.68;margin-top:8px}.gsc-note a{color:inherit;text-decoration:underline}.gsc-feature>a{display:grid;grid-template-columns:1fr auto;gap:18px;align-items:center;padding:26px 28px;border-radius:18px;text-decoration:none;color:#fff;background:linear-gradient(120deg,#3a0d12,#8f1d24 55%,#c2262f)}.gsc-feature small{display:block;opacity:.85;font-size:.8rem;margin-bottom:6px;letter-spacing:.08em;text-transform:uppercase}.gsc-feature b{display:block;font-size:1.35rem;line-height:1.25}.gsc-feature span{display:block;opacity:.9;margin-top:8px;max-width:62ch}.gsc-feature i{font-style:normal;font-weight:700;background:#fff;color:#8f1d24;padding:12px 18px;border-radius:999px;white-space:nowrap}@media(max-width:640px){.gsc-card{flex-basis:72%}.gsc-head{flex-wrap:wrap}.gsc-feature>a{grid-template-columns:1fr}.gsc-feature i{justify-self:start}}@media(prefers-reduced-motion:reduce){.gsc-rail{scroll-behavior:auto}.gsc-card,.gsc-btn{transition:none}}</style>\n<script id="gsc-script">(function(){function init(sec){var r=sec.querySelector(\'.gsc-rail\'),p=sec.querySelector(\'.gsc-prev\'),n=sec.querySelector(\'.gsc-next\');if(!r||!p||!n)return;function upd(){var m=r.scrollWidth-r.clientWidth-2;p.disabled=r.scrollLeft<=2;n.disabled=r.scrollLeft>=m}function go(d){r.scrollBy({left:d*Math.max(r.clientWidth*.9,200),behavior:\'smooth\'})}p.addEventListener(\'click\',function(){go(-1)});n.addEventListener(\'click\',function(){go(1)});r.addEventListener(\'scroll\',function(){window.requestAnimationFrame(upd)},{passive:true});r.addEventListener(\'keydown\',function(e){if(e.key===\'ArrowRight\'){e.preventDefault();go(1)}if(e.key===\'ArrowLeft\'){e.preventDefault();go(-1)}});window.addEventListener(\'resize\',upd);upd()}function all(){document.querySelectorAll(\'section.gsc[data-gsc]\').forEach(init)}if(document.readyState===\'loading\')document.addEventListener(\'DOMContentLoaded\',all);else all()})();</script>\n<!-- /gsc:assets -->'


def tazty_section():
    return TAZTY_CAROUSEL

def amazon_section(limit=8):
    cards = "\n".join(amazon_card(p) for p in AMAZON_PICKS[:limit])
    return f'''{AMAZON_CSS}
<section class="amz-theme" id="amazon-picks">
  <div class="amz-band"><div class="wrap section-head" style="margin:0">
      <div><p class="eyebrow">Amazon picks</p><h2>Popular finds on Amazon</h2></div>
      <a class="link-more amz-head-cta" href="/amazon-deals/">See all {len(AMAZON_PICKS)} Amazon picks {ARROW}</a>
  </div></div>
  <div class="wrap" style="padding-top:28px;padding-bottom:48px">
    <div class="amz-grid">
{cards}
    </div>
    {amazon_note()}
  </div>
</section>'''

AMAZON_FAQ = [
    ("Why don't you show Amazon prices?", "Amazon prices change often, and Amazon only allows sites to show prices pulled live from its own systems. To avoid showing a wrong price, we send you to Amazon, where the current price, delivery date and any Amazon coupon are shown on the product page."),
    ("Are there coupon codes for these Amazon products?", "No. We don't publish codes for Amazon products. If Amazon has a clippable coupon or a Lightning Deal for an item, you'll see it on the product page after you click through."),
    ("Does CouponDepots earn money from these links?", f"Yes. {AMAZON_DISCLOSURE} It costs you nothing extra. See our <a href=\"/disclosure/\">affiliate disclosure</a>."),
    ("How are these products chosen?", "We pick well-reviewed, widely bought items that fit the same home, beauty and everyday categories as our featured brand coupons, and we review the list regularly."),
]

def build_amazon_page():
    groups = ""
    for k, label in AMAZON_CATS:
        items = [p for p in AMAZON_PICKS if p["cat"] == k]
        if not items:
            continue
        groups += f'''<h2 class="amz-group" id="{k}">{e(label)}</h2>
<div class="amz-grid">
{chr(10).join(amazon_card(p) for p in items)}
</div>
'''
    jump = " · ".join(f'<a href="#{k}">{e(l)}</a>' for k, l in AMAZON_CATS)
    body = f'''{AMAZON_CSS}<style>.amz-group{{margin:40px 0 16px}}.amz-jump{{font-size:.95rem}}</style>
<section class="amz-theme">
  <div class="amz-band"><div class="wrap">
    <p class="eyebrow">Amazon picks · Updated {AMAZON_UPDATED_HUMAN}</p>
    <h1>Amazon Deals &amp; Picks Worth a Look</h1>
    <p class="muted" style="margin:10px 0 0">Well-reviewed home, beauty, gift and home-office finds on Amazon. Click any product to see today's price, delivery date and any Amazon coupon on the product page.</p>
  </div></div>
  <div class="wrap" style="padding-top:24px;padding-bottom:48px">
    <p class="amz-jump">Jump to: {jump}</p>
    {amazon_note()}
{groups}
    <p class="center" style="margin-top:32px"><a class="link-more" href="/#deals">Browse our featured brand coupon codes {ARROW}</a></p>
  </div>
</section>
{faq_html(AMAZON_FAQ, title="Amazon picks: common questions")}
'''
    schema = [
        crumbs([("Home", "/"), ("Amazon picks", "/amazon-deals/")]),
        {"@type": "ItemList", "name": "CouponDepots Amazon picks", "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "name": p["name"], "url": amz_url(p["asin"])} for i, p in enumerate(AMAZON_PICKS)]},
        faq_schema(AMAZON_FAQ),
    ]
    write("/amazon-deals/", page("/amazon-deals/", "Amazon Deals & Picks: Home, Beauty, Gifts & Office | CouponDepots",
          "Well-reviewed Amazon finds for home and bath, hair and beauty, cozy gifts and the home office, picked by CouponDepots. Check today's price on Amazon.",
          body, schema))
    add_sm("/amazon-deals/", AMAZON_UPDATED, "0.8")


# ---------------------------------------------------------------- HOLIDAY + GROWTH PAGES
BF_DATE, CM_DATE = "2026-11-27", "2026-11-30"   # Black Friday / Cyber Monday 2026
BF_END = "2026-12-02"                            # holiday banners and store-page blocks hide after this
INDEXNOW_KEY = "c7d3e9a14b6f42d8a0e5b1f9c2d4a6e8"  # served at /<key>.txt. Help: https://www.indexnow.org/documentation

def holiday_on():
    return TODAY <= BF_END

def days_to(iso):
    return (datetime.date.fromisoformat(iso) - datetime.date.fromisoformat(TODAY)).days

def bf_banner():
    if not holiday_on():
        return ""
    d = days_to(BF_DATE)
    when = f"{d} day{'s' if d != 1 else ''} to Black Friday" if d > 0 else ("Black Friday is here" if d == 0 else "Cyber week deals are live")
    return (f'<div class="bf-strip"><div class="wrap"><strong>{when}.</strong> Early holiday codes are already live. '
            f'<a href="/black-friday-deals/">See Black Friday deals {ARROW}</a> · <a href="/holiday-gift-guide/">Gift guide</a></div></div>')

SIGNUP_CSS = '''<style>.signup{display:grid;grid-template-columns:1.2fr 1fr;gap:28px;align-items:center}
.signup form{display:flex;gap:10px;flex-wrap:wrap}.signup input[type=email]{flex:1;min-width:220px;padding:14px 16px;border-radius:999px;border:1px solid var(--line);font:inherit}
.signup .fine{grid-column:1/-1;margin:0}.bf-strip{background:#111;color:#f6d77b;font-size:.92rem;padding:10px 0;text-align:center}
.bf-strip a{color:#fff;text-decoration:underline}.bf-strip strong{color:#fff}
@media(max-width:760px){.signup{grid-template-columns:1fr}}</style>'''

def signup_html(source="home"):
    """Deal-alerts signup form, filled in on the page (never opens an email app).
    Posts to the Apps Script web app in promos.json config.signup_url (saves to a Google Sheet; see
    automation/README.md). Until that is set, signups are emailed to the site inbox through FormSubmit.
    Help: https://formsubmit.co/ajax-documentation"""
    url = PROMO_CONFIG.get("signup_url", "") or f"https://formsubmit.co/ajax/{EMAIL}"
    form = (f'<form class="signup-form" action="{e(url)}" method="post" data-signup>'
            f'<label class="sr-only" for="su-{source}">Email address</label>'
            f'<input id="su-{source}" type="email" name="email" required placeholder="you@example.com" autocomplete="email">'
            f'<input type="hidden" name="source" value="{e(source)}">'
            f'<input type="hidden" name="_subject" value="New CouponDepots deal-alert signup">'
            f'<input type="hidden" name="_template" value="table"><input type="hidden" name="_captcha" value="false">'
            f'<input type="text" name="_honey" tabindex="-1" autocomplete="off" aria-hidden="true" style="display:none">'
            f'<button class="btn btn-gold" type="submit">Get deal alerts</button>'
            f'<p class="signup-msg" role="status" aria-live="polite" hidden></p></form>')
    return f'''{SIGNUP_CSS}
<section class="section section-soft" id="deal-alerts">
  <div class="wrap signup">
    <div><p class="eyebrow">Free deal alerts</p><h2>New codes in your inbox, once a week</h2>
    <p class="muted">One short email with the newest codes from our featured brands, plus Black Friday and Cyber Monday deals the day they go live. No spam; unsubscribe any time.</p></div>
    {form}
    <p class="fine">We use your email only to send deal alerts. See our <a href="/privacy/">privacy policy</a>.</p>
  </div>
</section>'''

BF_FAQ = [
    ("When is Black Friday 2026?", "Black Friday is Friday, November 27, 2026, the day after Thanksgiving. Cyber Monday is November 30, 2026. Many stores start their sales earlier in November."),
    ("Can I use a coupon code on top of a Black Friday sale?", "Often, yes. Several of our featured brands say their codes can be applied on top of sale prices. Add the item to your cart, apply the code and check that the total drops before you pay."),
    ("Where do these Black Friday codes come from?", "From each brand's official affiliate program. We add new Black Friday and Cyber Monday codes as brands release them and remove them when they end."),
    ("How do I get Black Friday codes the day they go live?", 'Sign up for our free <a href="#deal-alerts">deal alerts</a>. We email the new codes as soon as they are listed.'),
]

def build_bf():
    hol = [o for o in OFFERS if o.get("holiday")]
    now = [o for o in OFFERS if not o.get("holiday") and o["type"] == "code"]
    d = days_to(BF_DATE)
    count = f"{d} days to go." if d > 0 else "Live now."
    early = (f'''<section class="section section-tight"><div class="wrap">
<div class="section-head"><div><p class="eyebrow">Early Black Friday</p><h2>Holiday deals already live</h2></div></div>
<div class="coupon-grid">{grid_cards(hol)}</div></div></section>''') if hol else ""
    body = f'''
<section class="page-hero"><div class="wrap narrow center">
  <p class="eyebrow">Black Friday {BF_DATE[:4]} · Updated {TODAY_HUMAN}</p>
  <h1>Black Friday &amp; Cyber Monday Coupons {BF_DATE[:4]}</h1>
  <p class="lead">Black Friday is <strong>{human_date(BF_DATE)}</strong> and Cyber Monday is <strong>{human_date(CM_DATE)}</strong>. {count} Every code below comes straight from the brand's official affiliate program, and we add new ones as brands release them.</p>
  <p><a class="btn btn-gold" href="#codes">See codes</a> <a class="btn btn-ghost-dark" href="#deal-alerts">Get alerts</a></p>
</div></section>
{early}
<section class="section section-tight" id="codes"><div class="wrap">
<div class="section-head"><div><p class="eyebrow">Use them now</p><h2>Coupon codes that work today</h2></div><p class="muted">Many brands let you stack these on top of holiday sale prices. Confirm the discount in your cart.</p></div>
<div class="coupon-grid">{grid_cards(now)}</div></div></section>
<section class="section section-soft"><div class="wrap">
<div class="section-head"><div><p class="eyebrow">Brands to watch</p><h2>Black Friday stores we track</h2></div><a class="link-more" href="/holiday-gift-guide/">Holiday gift guide {ARROW}</a></div>
<div class="store-grid">{"".join(store_card(b) for b in BRANDS)}</div></div></section>
{amazon_section(4)}
{signup_html("black-friday")}
<section class="section"><div class="wrap narrow prose">
<h2>How to get the best Black Friday price</h2>
<ol class="howto"><li><strong>Shortlist early.</strong> Add the items you want to your cart this week so you can compare prices when the sale starts.</li>
<li><strong>Stack a code.</strong> Apply one of the codes above on top of the sale price where the brand allows it.</li>
<li><strong>Check shipping cut-offs.</strong> For gifts, confirm the delivery date before you pay.</li>
<li><strong>Keep the receipt.</strong> Holiday return windows are often longer; check each store's policy.</li></ol>
</div></section>
{faq_html(BF_FAQ, "Black Friday questions")}
'''
    schema = [
        {"@type": "WebPage", "@id": f"{BASE}/black-friday-deals/#webpage", "url": f"{BASE}/black-friday-deals/",
         "name": f"Black Friday & Cyber Monday Coupons {BF_DATE[:4]}", "isPartOf": {"@id": f"{BASE}/#website"}, "dateModified": TODAY},
        crumbs([("Home", "/"), ("Black Friday deals", "/black-friday-deals/")]),
        {"@type": "ItemList", "name": "Black Friday coupon codes", "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "name": f"{B[o['brand']]['name']}: {o['title']}", "url": BASE + B[o["brand"]]["url"]}
            for i, o in enumerate(hol + now)]},
        faq_schema(BF_FAQ),
    ]
    write("/black-friday-deals/", page("/black-friday-deals/", f"Black Friday & Cyber Monday Coupons {BF_DATE[:4]} | CouponDepots",
          f"Black Friday {BF_DATE[:4]} is {human_date(BF_DATE)}. Early holiday coupon codes from SIRUI, AlorAir, Argendon, Monvane and more, updated daily from each brand's affiliate program.",
          body, schema, active="Black Friday"))
    add_sm("/black-friday-deals/", TODAY, "0.9")

GIFT_GROUPS = [("gifts", "Cozy gifts for anyone"), ("hair", "Self-care & beauty gifts"), ("home", "Gifts for the home"), ("office", "Gifts for the home office")]
GIFT_FAQ = [
    ("Why don't you show Amazon prices?", "Amazon only allows prices pulled live from its own systems, so we send you to Amazon, where today's price, delivery date and any Amazon coupon are shown."),
    ("How are these gifts chosen?", "We pick widely bought, well-reviewed items in the same everyday categories as our featured brand coupons, plus gifts from the brands we feature."),
    ("Does CouponDepots earn from these links?", f"Yes. {AMAZON_DISCLOSURE} It costs you nothing extra. See our <a href=\"/disclosure/\">affiliate disclosure</a>."),
]

def build_gifts():
    groups = ""
    for k, label in GIFT_GROUPS:
        items = [p for p in AMAZON_PICKS if p["cat"] == k]
        if items:
            groups += f'<h2 class="amz-group" id="{k}">{e(label)}</h2>\n<div class="amz-grid">{"".join(amazon_card(p) for p in items)}</div>\n'
    body = f'''{AMAZON_CSS}<style>.amz-group{{margin:40px 0 16px}}</style>
<section class="section"><div class="wrap">
  <p class="eyebrow">Holiday gift guide · Updated {TODAY_HUMAN}</p>
  <h1>Holiday Gift Ideas {TODAY[:4]}: Practical Gifts People Actually Use</h1>
  <p class="muted">Cozy, useful gifts for family, friends and coworkers, from popular Amazon finds to gifts from our featured brands with a coupon code attached.</p>
  {amazon_note()}
  {groups}
  <h2 class="amz-group">Gifts with a coupon code</h2>
  <p class="muted">These brands have live codes on CouponDepots, so the gift costs less.</p>
  <div class="store-grid">{"".join(store_card(b) for b in BRANDS if any(o["brand"] == b["slug"] and o["type"] == "code" for o in OFFERS))}</div>
  <p class="center" style="margin-top:32px"><a class="link-more" href="/black-friday-deals/">See all Black Friday deals {ARROW}</a></p>
</div></section>
{signup_html("gift-guide")}
{faq_html(GIFT_FAQ, "Gift guide questions")}
'''
    schema = [crumbs([("Home", "/"), ("Holiday gift guide", "/holiday-gift-guide/")]),
              {"@type": "ItemList", "name": "CouponDepots holiday gift ideas", "itemListElement": [
                  {"@type": "ListItem", "position": i + 1, "name": p["name"], "url": amz_url(p["asin"])} for i, p in enumerate(AMAZON_PICKS)]},
              faq_schema(GIFT_FAQ)]
    write("/holiday-gift-guide/", page("/holiday-gift-guide/", f"Holiday Gift Ideas {TODAY[:4]}: Cozy, Practical Gifts | CouponDepots",
          "Practical holiday gift ideas: cozy throws, candle warmers, digital photo frames, self-care and home-office gifts, plus gifts from brands with live coupon codes.",
          body, schema))
    add_sm("/holiday-gift-guide/", TODAY, "0.8")

def tag_clicks(path, content):
    """Adds an Awin clickref to every Awin link so Awin reports show which page sent the sale.
    Help: https://help.awin.com/s/article/What-is-clickref"""
    place = (path.strip("/").replace("/", "-") or "home").replace(".html", "")[:45]
    def add(m):
        u = m.group(1)
        return u + ("" if "clickref=" in u else f"&amp;clickref={place}") + '"'
    return re.sub(r'(href="https://www\.awin1\.com/cread\.php\?[^"]*)"', add, content)

# ---------------------------------------------------------------- DEALS (Groupon-style cards + one page per offer)
# Every offer gets its own page at /deal/<brand>-<title>/ with the deal, highlights, fine print and similar deals.
# Only real data is shown: the merchant's discount, code and end date. No invented prices, ratings or "bought" counts.
CAT_NAMES = {"home": "Home", "beauty": "Beauty & Hair", "tech": "Tech", "outdoor": "Outdoor", "travel": "Travel",
             "hobbies": "Hobbies", "fashion": "Fashion"}
CAT_ORDER = ["home", "beauty", "tech", "outdoor", "travel", "hobbies", "fashion"]

def present_cats():
    have = {B[o["brand"]]["cat"] for o in OFFERS}
    return [c for c in CAT_ORDER if c in have] + sorted(c for c in have if c not in CAT_ORDER)

def cat_bar():
    """Category bar under the header on every page (help: the links filter the homepage deal board)."""
    links = "".join(f'<a href="/?cat={c}#deals" data-cat-link="{c}">{e(CAT_NAMES.get(c, c.title()))}</a>' for c in present_cats())
    return (f'<nav class="cat-bar" aria-label="Deal categories"><div class="wrap cat-row">'
            f'<a href="/#deals" data-cat-link="all">All deals</a><a href="/?cat=code#deals" data-cat-link="code">Coupon codes</a>{links}'
            f'<a href="/things-to-do/">Things to do</a><a href="/black-friday-deals/" class="cat-hot">Black Friday</a><a href="/amazon-deals/">Amazon picks</a></div></nav>')

def assign_deal_urls():
    used = set()
    for o in OFFERS:
        b = B[o["brand"]]
        base = slugify(f'{b["name"]} {o["title"]}')[:72].strip("-")
        s, n = base, 2
        while s in used:
            s, n = f"{base}-{n}", n + 1
        used.add(s)
        o["url"] = f"/deal/{s}/"

def discount_text(o):
    v, u = o.get("value", ""), (o.get("unit") or "").upper()
    if v.upper() in ("NEW", "SHOP", "DEAL", ""):
        return "Featured deal"
    if u == "OFF":
        return f"{v} off"
    if u == "FROM":
        return f"From {v}"
    return f"{v} {o.get('unit', '')}".strip()

def ends_html(o, cls="deal-ends"):
    if o.get("real_exp") and o.get("expires"):
        d = days_to(o["expires"])
        left = "Ends today" if d <= 0 else ("Ends tomorrow" if d == 1 else f"{d} days left")
        return f'<span class="{cls}" data-ends="{o["expires"]}">{left} · {human_date(o["expires"])}</span>'
    return f'<span class="{cls} deal-online">Online deal</span>'

def deal_img(o, b, w=800, h=450, sizes="(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 380px", lazy=True):
    oimg = o.get("img", b["img"])
    alt = LOCAL_IMG[oimg[6:]]["alt"] if oimg.startswith("local:") else alt_for(b)
    return img(oimg, alt, w, h, lazy=lazy, sizes=sizes)

def deal_card(o, featured=False):
    b = B[o["brand"]]
    ctype = "code" if o["type"] == "code" else "deal"
    search = f'{b["name"]} {b["cat_label"]} {o["title"]} {o.get("code","")}'.lower()
    how = "Code" if ctype == "code" else "No code needed"
    sizes = "(max-width: 700px) 100vw, (max-width: 1100px) 100vw, 760px" if featured else "(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 380px"
    return f'''<article class="coupon deal{" deal-featured" if featured else ""}" data-cat="{b["cat"]}" data-type="{ctype}" data-search="{e(search)}">
  <a class="deal-media" href="{o["url"]}" tabindex="-1" aria-hidden="true">{deal_img(o, b, sizes=sizes)}<span class="deal-flag">{e(o["label"])}</span></a>
  <div class="deal-body">
    <div class="deal-meta"><a href="{b["url"]}">{e(b["name"])}</a><span>{e(b["cat_label"])}</span></div>
    <h3><a href="{o["url"]}">{e(o["title"])}</a></h3>
    <div class="deal-price"><strong>{e(discount_text(o))}</strong><span>{how}</span></div>
    <div class="deal-foot">{ends_html(o)}<a class="btn btn-deal" href="{o["url"]}">View deal</a></div>
  </div>
</article>'''

def ending_soon(limit=10, within=60):
    soon = sorted((o for o in OFFERS if o.get("real_exp") and o.get("expires") and 0 <= days_to(o["expires"]) <= within),
                  key=lambda o: o["expires"])[:limit]
    if len(soon) < 2:
        return ""
    tiles = "".join(f'''<a class="soon-tile" href="{o["url"]}"><strong>{e(discount_text(o))}</strong><b>{e(B[o["brand"]]["name"])}</b><span>{e(o["title"])}</span>{ends_html(o, "soon-ends")}</a>''' for o in soon)
    return f'''<section class="section section-tight" id="ending-soon"><div class="wrap">
  <div class="section-head"><div><p class="eyebrow">Last chance</p><h2>Ending soon</h2></div><p class="muted">Offers with an end date set by the merchant, soonest first. Times are US Eastern.</p></div>
  <div class="soon-rail" tabindex="0" aria-label="Offers ending soon, scroll sideways">{tiles}</div></div></section>'''

def store_tile(b):
    n = sum(1 for o in OFFERS if o["brand"] == b["slug"])
    return f'<a class="store-tile" href="{b["url"]}"><b>{e(b["name"])}</b><span>{e(b["cat_label"])}</span><em>{n} offer{"s" if n != 1 else ""} {ARROW}</em></a>'

def deal_cta(o, b):
    if o["type"] == "code":
        return (f'<a class="btn btn-gold btn-big reveal" href="{e(o.get("link") or b["link"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" '
                f'data-code="{o["code"]}" aria-label="Show {b["name"]} code and open store"><span class="reveal-label">Show code</span>'
                f'<span class="reveal-peek" aria-hidden="true">{o["code"][-3:]}</span></a>')
    return (f'<a class="btn btn-gold btn-big" href="{e(o.get("link") or b["link"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" '
            f'data-brand="{b["slug"]}">Get deal at {e(b["name"])} {ARROW}</a>')

def build_deal(o):
    b = B[o["brand"]]
    cat = CAT_NAMES.get(b["cat"], b["cat_label"])
    code = o["type"] == "code"
    if o.get("real_exp") and o.get("expires"):
        valid = f"Valid until {human_date(o['expires'])}, as set by {e(b['name'])}."
    else:
        valid = f"No end date was given by {e(b['name'])}. Offers can end without notice, so confirm at checkout."
    redeem = (f"Tap <em>Show code</em>. We copy <strong>{e(o['code'])}</strong> for you and open {e(b['name'])} in a new tab. Paste it in the promo or discount field at checkout."
              if code else f"No code needed. Tap <em>Get deal</em> and the price or discount shows on {e(b['name'])}'s site.")
    similar = [x for x in OFFERS if x is not o and x["brand"] != o["brand"] and B[x["brand"]]["cat"] == b["cat"]]
    seen = set(); sim = []
    for x in similar + [x for x in OFFERS if x["brand"] != o["brand"] and x not in similar]:
        if x["brand"] in seen:
            continue
        seen.add(x["brand"]); sim.append(x)
        if len(sim) == 3:
            break
    more = [x for x in OFFERS if x["brand"] == o["brand"] and x is not o]
    more_html = ("<h2>More from " + e(b["name"]) + "</h2><ul class=\"deal-more\">" +
                 "".join(f'<li><a href="{x["url"]}"><strong>{e(discount_text(x))}</strong> {e(x["title"])}</a></li>' for x in more[:6]) + "</ul>") if more else ""
    body = f'''
<section class="section section-tight deal-page"><div class="wrap">
  <nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><a href="/?cat={b["cat"]}#deals">{e(cat)} deals</a><span>/</span><a href="{b["url"]}">{e(b["name"])}</a><span>/</span><span aria-current="page">Deal</span></nav>
  <h1 class="deal-h1">{e(o["title"])}</h1>
  <p class="deal-sub"><a href="{b["url"]}">{e(b["name"])}</a> · {e(b["cat_label"])} · {ends_html(o, "deal-ends-inline")}</p>
  <div class="deal-layout">
    <div class="deal-main">
      <div class="deal-photo">{deal_img(o, b, 1200, 675, sizes="(max-width: 900px) 100vw, 760px", lazy=False)}</div>
      <div class="prose">
        <h2>The deal</h2>
        <p>{e(o["detail"])}</p>
        <h2>Highlights</h2>
        <ul class="deal-hl">
          <li><strong>Discount:</strong> {e(discount_text(o))}{f" with code {e(o['code'])}" if code else ""}</li>
          <li><strong>How to redeem:</strong> {redeem}</li>
          <li><strong>When:</strong> {valid}</li>
          <li><strong>Sold by:</strong> {e(b["name"])}. CouponDepots doesn't sell or ship anything; you buy on {e(b["name"])}'s own site.</li>
        </ul>
        <h2>Fine print</h2>
        <ul class="deal-fine">
          <li>Terms are set by {e(b["name"])} and can change or end early. Check that the discount shows in your cart before you pay.</li>
          <li>Source: {e(b["name"])}'s official affiliate program. <a href="/how-we-verify/">How we check offers</a>.</li>
          <li>Code not working? <a href="/contact/#broken">Tell us</a> and we'll recheck it.</li>
          <li>We may earn a commission when you buy, at no extra cost to you. <a href="/disclosure/">Affiliate disclosure</a>.</li>
        </ul>
        <h2>About {e(b["name"])}</h2>
        <p>{e(b.get("short") or b.get("tagline", ""))} <a href="{b["url"]}">See every {e(b["name"])} code and how-to guide</a>.</p>
        {more_html}
      </div>
    </div>
    <aside class="deal-buy" aria-label="Get this deal">
      <span class="tag">{e(o["label"])}</span>
      <p class="deal-big">{e(discount_text(o))}</p>
      <p class="deal-how">{"Brand code: reveal it, then paste at checkout." if code else "No code needed: the discount applies on the store's site."}</p>
      {deal_cta(o, b)}
      <p class="deal-when">{ends_html(o, "deal-ends-inline")}</p>
      <ul class="deal-trust"><li>Free to use, always</li><li>Opens {e(b["name"])} in a new tab</li><li><a href="/how-we-verify/">How we verify</a></li></ul>
    </aside>
  </div>
</div></section>
<section class="section section-soft"><div class="wrap">
  <div class="section-head"><div><p class="eyebrow">You may also like</p><h2>Similar deals</h2></div><a class="link-more" href="/#deals">All deals {ARROW}</a></div>
  <div class="coupon-grid">{"".join(deal_card(x) for x in sim)}</div>
</div></section>'''
    off = offer_schema(o, b)
    off["url"] = BASE + o["url"]
    schema = [{"@type": "WebPage", "@id": f"{BASE}{o['url']}#webpage", "url": BASE + o["url"], "name": f"{b['name']}: {o['title']}",
               "isPartOf": {"@id": f"{BASE}/#website"}, "dateModified": TODAY, "mainEntity": off},
              crumbs([("Home", "/"), (f"{cat} deals", f"/?cat={b['cat']}"), (b["name"], b["url"]), (o["title"], o["url"])])]
    title = f"{b['name']} Deal: {o['title']} | CouponDepots"
    desc = f"{discount_text(o)} at {b['name']}: {o['title']}. {o['detail']}"
    oimg = o.get("img", b["img"])
    write(o["url"], page(o["url"], title, desc, body, schema, og_img=oimg if not oimg.startswith("http") else "1483181957632-8bda974cbc91"))
    add_sm(o["url"], TODAY, "0.6")

# ---------------------------------------------------------------- THINGS TO DO (city picker)
# City passes, attraction tickets and local memberships, grouped by city. Boston is shown first.
# Partners: GetOut (Awin 124814, US only), Turbopass city passes (Awin 100613), Tiqets (Travelpayouts link),
# and our own ticktes.online city guides. City photos: Unsplash (US) and our ezpass.uk photos in /img/city-*.
# To add a city: copy one dict in CITIES. Help: https://help.awin.com/s/article/What-is-a-deep-link
TIQETS = "https://tiqets.tpo.mx/nbGdhefs"
def turbopass(path):
    return awin(100613, 3067297, ued="https://www.turbopass.com/en/" + path)
for _c, _alt in [("london", "Big Ben and the Houses of Parliament beside the Thames, London"), ("paris", "The Eiffel Tower over Paris rooftops"),
                 ("rome", "The Colosseum in Rome at sunrise"), ("amsterdam", "Canal houses reflected in an Amsterdam canal"),
                 ("athens", "The Parthenon on the Acropolis, Athens"), ("barcelona", "Sagrada Família basilica in Barcelona at sunset"),
                 ("berlin", "The Brandenburg Gate in Berlin at sunset"), ("dubai", "Burj Khalifa and the Dubai skyline reflected in the water"),
                 ("florence", "Florence Cathedral and Giotto's bell tower"), ("prague", "Charles Bridge and the Old Town towers, Prague"),
                 ("venice", "The Rialto Bridge over the Grand Canal, Venice"), ("vienna", "Schönbrunn Palace and its gardens, Vienna"),
                 ("york", "York Minster at sunset")]:
    LOCAL_IMG[f"city-{_c}"] = dict(name=f"city-{_c}", src="", w=800, h=700, pos="50% 50%", alt=_alt)

def _tiq(city):
    return dict(partner="Tiqets", title=f"{city} attraction tickets", blurb=f"Single-attraction tickets for {city}, including timed-entry and skip-the-line options where available. Good when you only plan one or two paid sights.",
                note="Price, dates and refunds are set by Tiqets.", link=TIQETS, cta="See ticket prices")
def _guide(slug, city):
    return dict(partner="ticktes.online", title=f"{city} city guide", blurb=f"Our sister site's guide: when a {city} city pass pays off, free things to do and what to book ahead.",
                note="Free guide, no booking needed.", link=f"https://ticktes.online/{slug}.html", cta="Read the guide", own=True)
def _tp(city, path, kind="city pass"):
    return dict(partner="Turbopass", title=f"{city} {kind}", blurb=f"One pass for many of {city}'s top attractions and tours, Some passes add public transport. Pick the number of days you need.",
                note="What's included and prices are shown on Turbopass.", link=turbopass(path), cta="See the pass")

CITIES = [
    dict(slug="boston", name="Boston", region="us", img="1565127803082-69dd82351360", alt="Boston skyline across the harbor on a clear day",
         intro="Harbor cruises, museums, the Freedom Trail and day trips across Massachusetts.",
         items=[dict(partner="GetOut", title="Massachusetts membership", blurb="12-month membership with entry to View Boston and 40+ other venues across Massachusetts. Best if you'll visit several local venues in a year.",
                     note="$69.95 per person for 12 months (price checked Nov 2, 2026 on getout.com; confirm on GetOut).",
                     link=awin(124814, 3067297, ued="https://www.getout.com/memberships/new-england"), cta="See the membership"),
                dict(partner="GetOut", title="Massachusetts getaways", blurb="Weekend trip ideas beyond the city, from the coast to the Berkshires.",
                     note="Dates, prices and terms are shown on GetOut.",
                     link="https://www.awin1.com/awclick.php?gid=603241&mid=124814&awinaffid=3067297&linkid=4781673&clickref=coupondepots-things-to-do", cta="Plan a getaway"),
                _tiq("Boston"), _guide("boston", "Boston")]),
    dict(slug="new-york", name="New York", region="us", img="1496588152823-86ff7695e68f", alt="Brooklyn Bridge with the Manhattan skyline",
         intro="Observation decks, Broadway, museums and harbor cruises.", items=[_tiq("New York"), _guide("new-york", "New York")]),
    dict(slug="chicago", name="Chicago", region="us", img="1494522855154-9297ac14b55f", alt="People at Cloud Gate in Millennium Park with Chicago skyscrapers",
         intro="Architecture cruises, skydecks and world-class museums.", items=[_tiq("Chicago"), _guide("chicago", "Chicago")]),
    dict(slug="las-vegas", name="Las Vegas", region="us", img="1772314323794-1480138dd3f9", alt="Las Vegas Strip with fountains at twilight",
         intro="Shows, observation wheels and day trips to the canyons.", items=[_tiq("Las Vegas"), _guide("las-vegas", "Las Vegas")]),
    dict(slug="los-angeles", name="Los Angeles", region="us", img="1575555201693-7cd442b8023f", alt="Palm trees silhouetted against the Los Angeles skyline at golden hour",
         intro="Studio tours, theme parks and the beach cities.", items=[_tiq("Los Angeles"), _guide("los-angeles", "Los Angeles")]),
    dict(slug="orlando", name="Orlando", region="us", img="1609184889233-eff6dd93def4", alt="Orlando city skyline across a lake on a sunny day",
         intro="Theme parks, water parks and family attractions.", items=[_tiq("Orlando"), _guide("orlando", "Orlando")]),
    dict(slug="london", name="London", region="world", img="local:city-london", intro="Royal palaces, the Tower, river cruises and big-name museums.",
         items=[_tp("London", "london/london-city-pass"), _tiq("London")]),
    dict(slug="paris", name="Paris", region="world", img="local:city-paris", intro="The Louvre, Seine cruises, Versailles and the Eiffel Tower.",
         items=[_tp("Paris", "paris/paris-flex-pass", "flex pass"), _tiq("Paris")]),
    dict(slug="rome", name="Rome", region="world", img="local:city-rome", intro="The Colosseum, the Vatican and ancient Rome in a few days.",
         items=[_tp("Rome", "rome/rome-city-pass"), _tiq("Rome")]),
    dict(slug="barcelona", name="Barcelona", region="world", img="local:city-barcelona", intro="Gaudí's Sagrada Família, Park Güell and the old town.",
         items=[_tp("Barcelona", "barcelona/barcelona-flex-pass", "flex pass"), _tiq("Barcelona")]),
    dict(slug="amsterdam", name="Amsterdam", region="world", img="local:city-amsterdam", intro="Canal cruises, the Rijksmuseum and Van Gogh.",
         items=[_tp("Amsterdam", "amsterdam/amsterdam-city-pass"), _tiq("Amsterdam")]),
    dict(slug="berlin", name="Berlin", region="world", img="local:city-berlin", intro="Museum Island, the Wall and the TV Tower.",
         items=[_tp("Berlin", "berlin/berlin-city-pass"), _tiq("Berlin")]),
    dict(slug="vienna", name="Vienna", region="world", img="local:city-vienna", intro="Imperial palaces, classical concerts and coffee houses.",
         items=[_tp("Vienna", "vienna/vienna-city-pass"), _tiq("Vienna")]),
    dict(slug="prague", name="Prague", region="world", img="local:city-prague", intro="The castle, Charles Bridge and the Old Town.",
         items=[_tp("Prague", "prague/prague-city-pass"), _tiq("Prague")]),
    dict(slug="venice", name="Venice", region="world", img="local:city-venice", intro="Doge's Palace, the Grand Canal and the islands.",
         items=[_tp("Venice", "venice/venice-flex-pass", "flex pass"), _tiq("Venice")]),
    dict(slug="florence", name="Florence", region="world", img="local:city-florence", intro="The Duomo, the Uffizi and Tuscan day trips.",
         items=[_tp("Florence", "florence/florence-city-pass"), _tiq("Florence")]),
    dict(slug="athens", name="Athens", region="world", img="local:city-athens", intro="The Acropolis, ancient sites and island ferries.",
         items=[_tp("Athens", "athens/athens-city-pass"), _tiq("Athens")]),
    dict(slug="york", name="York", region="world", img="local:city-york", intro="York Minster, the city walls and Viking history.",
         items=[_tp("York", "york/visit-york-pass", "visit pass")]),
    dict(slug="dubai", name="Dubai", region="world", img="local:city-dubai", intro="Burj Khalifa, desert safaris and theme parks.",
         items=[_tp("Dubai", "dubai/dubai-city-pass"), _tiq("Dubai")]),
]

TTD_FAQ = [
    ("Is a city pass worth it?", "Usually only if you'll visit three or more paid attractions in a short time. Add up the single ticket prices for what you actually plan to see and compare that with the pass price. Our <a href=\"https://ticktes.online/city-passes.html\">city pass guide</a> walks through it."),
    ("Who sells the passes and tickets?", "The partner shown on each card (GetOut, Turbopass or Tiqets) sells and delivers them, and sets the price, dates and refund rules. CouponDepots doesn't sell tickets."),
    ("Why is GetOut only shown for US cities?", "GetOut offers US experiences only, so it's listed for Boston and Massachusetts. Turbopass covers the Europe and Dubai passes."),
    ("Does CouponDepots earn from these links?", "Yes. Some links are sponsored: we may earn a commission when you buy, at no extra cost to you. See our <a href=\"/disclosure/\">affiliate disclosure</a>."),
]

def city_photo(c, w=800, h=700, sizes="(max-width: 800px) 100vw, 420px", lazy=True):
    if c["img"].startswith("local:"):
        return img(c["img"], LOCAL_IMG[c["img"][6:]]["alt"], w, h, lazy=lazy, sizes=sizes)
    return img(c["img"], c["alt"], w, h, lazy=lazy, sizes=sizes)

def exp_card(it):
    rel = 'rel="noopener"' if it.get("own") else 'rel="sponsored nofollow noopener noreferrer"'
    tag = "Free guide" if it.get("own") else "Sponsored"
    return f'''<div class="exp-card"><div class="exp-top"><b>{e(it["partner"])}</b><span class="tag">{tag}</span></div>
  <h4>{e(it["title"])}</h4><p>{e(it["blurb"])}</p><p class="fine">{e(it["note"])}</p>
  <a class="btn btn-deal" href="{e(it["link"])}" target="_blank" {rel}>{e(it["cta"])} {ARROW}</a></div>'''

def city_block(c, first=False):
    return f'''<section class="city-block" id="city-{c["slug"]}" data-city="{c["slug"]}" aria-labelledby="h-{c["slug"]}">
  <div class="city-photo">{city_photo(c, lazy=not first)}</div>
  <div class="city-info"><p class="eyebrow">{"United States" if c["region"] == "us" else "Europe & Dubai"}</p>
    <h2 id="h-{c["slug"]}">Things to do in {e(c["name"])}</h2><p>{e(c["intro"])}</p>
    <div class="exp-grid">{"".join(exp_card(it) for it in c["items"])}</div></div>
</section>'''

def city_picker():
    def opts(region):
        return "".join(f'<a class="chip" href="/things-to-do/?city={c["slug"]}" data-city-pick="{c["slug"]}">{e(c["name"])}</a>' for c in CITIES if c["region"] == region)
    return f'''<div class="city-picker" role="navigation" aria-label="Choose a city">
  <div><span class="picker-label">United States</span><div class="filters">{opts("us")}</div></div>
  <div><span class="picker-label">Europe &amp; Dubai</span><div class="filters">{opts("world")}</div></div>
  <p class="fine">Pick a city to see its passes, tickets and local experiences. <a href="#ttd-help">How to choose</a></p></div>'''

def ttd_teaser():
    picks = [c for c in CITIES if c["slug"] in ("boston", "new-york", "london", "paris")]
    tiles = "".join(f'<a class="city-tile" href="/things-to-do/?city={c["slug"]}">{city_photo(c, 800, 700, sizes="(max-width: 700px) 50vw, 280px")}<span><b>{e(c["name"])}</b>{len(c["items"])} ways to save</span></a>' for c in picks)
    return f'''<section class="section section-tight" id="things-to-do"><div class="wrap">
  <div class="section-head"><div><p class="eyebrow">Things to do</p><h2>City passes, tickets &amp; experiences</h2></div><a class="link-more" href="/things-to-do/">All {len(CITIES)} cities {ARROW}</a></div>
  <div class="city-tiles">{tiles}</div></div></section>'''

def build_things_to_do():
    travel = [o for o in OFFERS if B[o["brand"]]["cat"] == "travel"]
    seen, trip = set(), []
    for o in travel:
        if o["brand"] not in seen:
            seen.add(o["brand"]); trip.append(o)
    trip_html = (f'''<section class="section section-soft"><div class="wrap"><div class="section-head"><div><p class="eyebrow">Plan the trip</p><h2>Flights, stays &amp; travel documents</h2></div><a class="link-more" href="/?cat=travel#deals">All travel deals {ARROW}</a></div>
  <div class="coupon-grid">{"".join(deal_card(o) for o in trip[:6])}</div></div></section>''') if trip else ""
    blocks = "".join(city_block(c, i == 0) for i, c in enumerate(CITIES))
    body = f'''
<section class="page-hero"><div class="wrap"><nav class="crumbs crumbs-dark" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><span aria-current="page">Things to do</span></nav>
<p class="eyebrow">City passes · Tickets · Local experiences</p><h1>Things to do</h1>
<p class="lead">Save on attractions in {len(CITIES)} cities, starting with Boston. Compare a city pass, single tickets and local memberships, then book with the partner.</p></div></section>
<section class="section section-tight"><div class="wrap">{city_picker()}<div class="city-list">{blocks}</div>
<p class="empty" id="city-empty" hidden>That city isn't listed yet. <a href="/contact/#submit">Suggest a deal</a></p></div></section>
<section class="section section-tight" id="ttd-help"><div class="wrap narrow prose"><h2>How to choose</h2>
<ol class="howto"><li><strong>List what you'll actually visit.</strong> Write down the paid attractions you plan to see.</li>
<li><strong>Add up single tickets.</strong> If it's one or two places, single tickets (Tiqets) are usually cheaper.</li>
<li><strong>Compare with a pass.</strong> Three or more paid sights in a few days is where a city pass (Turbopass) tends to pay off.</li>
<li><strong>Locals and repeat visits:</strong> a 12-month membership (GetOut) can beat one-off tickets.</li></ol>
<p class="fine">Prices and what's included change often, so always check the partner's page before you buy. <a href="/how-we-verify/">How we check offers</a> · <a href="/disclosure/">How we earn</a></p></div></section>
{trip_html}
{faq_html(TTD_FAQ)}'''
    schema = [{"@type": "WebPage", "@id": f"{BASE}/things-to-do/#webpage", "url": f"{BASE}/things-to-do/", "name": "Things to do: city passes, tickets & experiences",
               "isPartOf": {"@id": f"{BASE}/#website"}, "dateModified": TODAY},
              {"@type": "ItemList", "name": "Cities", "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": f"Things to do in {c['name']}", "url": f"{BASE}/things-to-do/?city={c['slug']}"} for i, c in enumerate(CITIES)]},
              crumbs([("Home", "/"), ("Things to do", "/things-to-do/")]), faq_schema(TTD_FAQ)]
    write("/things-to-do/", page("/things-to-do/", "Things to Do: City Passes & Attraction Tickets (Boston, NYC, London, Paris) | CouponDepots",
                                 f"Save on things to do in {len(CITIES)} cities: GetOut Massachusetts membership for Boston, Turbopass city passes for London, Paris, Rome and more, and Tiqets attraction tickets.",
                                 body, schema, og_img="1565127803082-69dd82351360", active="Things to do"))
    add_sm("/things-to-do/", TODAY, "0.8")

# ---------------------------------------------------------------- HOME
HOME_FAQ = [
    ("What is CouponDepots?", "CouponDepots is a free coupon and shopping-guide site. Every offer on this page comes from a featured brand available through an official affiliate network such as Awin, so codes and deals are sourced from the merchant, not scraped from other coupon sites."),
    ("Are the coupon codes on CouponDepots verified?", "Codes are supplied by the merchant through its affiliate program and labeled \"Brand code\". Prices marked \"verified\" were checked against the merchant's own site on the date shown. Merchants can change terms at any time, so always confirm the discount in your cart before paying."),
    ("How do I use a coupon code?", "Click <em>Show code</em>. The code is revealed and copied to your clipboard, and the store opens in a new tab. Add items to your cart and paste the code in the promo or discount field at checkout."),
    ("Which Monvane coupon codes work right now?", "Monvane's brand codes are <strong>MONAFF10</strong> (10% off for new customers, no minimum, one use per customer, stackable with spend-based discounts) and <strong>AFF5OFF</strong> (5% off, no minimum, unlimited use)."),
    ("Does CouponDepots earn money from these links?", "Yes. Some links are affiliate links, so we may earn a commission when you buy, at no extra cost to you. It never changes the price you pay. See our <a href=\"/disclosure/\">affiliate disclosure</a>."),
    ("Can my brand be listed on CouponDepots?", "Yes. We're adding new vendors regularly. <a href=\"/contact/#partner\">Contact our partnerships team</a> with your affiliate network details."),
]

def hero_preload():
    """Preload the homepage hero so it is the first image the browser fetches (faster LCP on phones).
    Help: https://web.dev/articles/optimize-lcp"""
    hid = "1483181957632-8bda974cbc91"
    srcset = ", ".join(f"{html.escape(U(hid, x, int(x * 1067 / 1600)))} {x}w" for x in [640, 960, 1280, 1920, 2560])
    return f'<link rel="preload" as="image" imagesrcset="{srcset}" imagesizes="(min-width: 900px) 64vw, 100vw" fetchpriority="high">\n'

def build_home():
    cat_names = {"home": "Home", "beauty": "Beauty & Hair", "hobbies": "Hobbies", "tech": "Tech", "fashion": "Fashion", "outdoor": "Outdoor", "travel": "Travel"}
    present = []
    for o in home_offers():
        c = B[o["brand"]]["cat"]
        if c not in present:
            present.append(c)
    chips = [("all", "All deals"), ("code", "Coupon codes")] + [(c, CAT_NAMES.get(c, cat_names.get(c, c.title()))) for c in present]
    chip_html = "".join(f'<button class="chip{" is-active" if k == "all" else ""}" data-filter="{k}" aria-pressed="{"true" if k == "all" else "false"}">{t}</button>' for k, t in chips)
    cards = "\n".join(deal_card(o, featured=(i == 0)) for i, o in enumerate(home_offers()))
    stores = "\n".join(store_tile(b) for b in BRANDS)
    codes = sum(1 for o in OFFERS if o["type"] == "code")
    body = f'''
<section class="hero">
  <style>.hero{{background:#0b1020}}@media(min-width:900px){{.hero-right{{left:36%}}.hero-right img{{-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 22%);mask-image:linear-gradient(90deg,transparent 0,#000 22%)}}}}</style>
  <div class="hero-media hero-right">{img("1483181957632-8bda974cbc91", "Stylish shopper in sunglasses carrying shopping bags", 1600, 1067, lazy=False, cls="hero-img", pos="50% 30%", sizes="(min-width: 900px) 64vw, 100vw", hero=True)}</div>
  <div class="wrap hero-inner">
    <p class="eyebrow eyebrow-light">Featured brand coupons · Updated {TODAY_HUMAN}</p>
    <h1>Save More on <em>Everything</em> You Love</h1>
    <p class="hero-sub">Every coupon and deal, on one page. Sourced straight from our featured brands, clearly labeled and free to use.</p>
    <form class="hero-search" role="search" action="/#deals" onsubmit="return false">
      <label class="sr-only" for="q">Search coupons and stores</label>
      <input id="q" name="q" type="search" placeholder="Search stores, codes or products… e.g. Monvane" autocomplete="off">
      <button class="btn btn-gold" type="submit">Search</button>
    </form>
    <ul class="hero-stats">
      <li><strong>{len(BRANDS)}</strong> featured brands</li>
      <li><strong>{len(OFFERS)}</strong> live offers</li>
      <li><strong>{codes}</strong> brand codes</li>
      <li><strong>$0</strong> to use, always</li>
    </ul>
  </div>
</section>
{bf_banner()}
<div class="partner-bar"><div class="wrap partner-row brand-row"><span>Featured brands</span>
<div class="marquee" role="region" aria-label="Featured brands"><div class="marquee-track">{"".join(f'<a href="{b["url"]}">{e(b["name"])}</a>' for b in BRANDS)}<span class="marquee-copy" aria-hidden="true">{"".join(f'<a href="{b["url"]}" tabindex="-1">{e(b["name"])}</a>' for b in BRANDS)}</span></div></div></div></div>

{ending_soon()}

<section class="section section-deals" id="deals">
  <div class="wrap">
    <div class="section-head">
      <div><p class="eyebrow">All coupons &amp; deals</p><h2>Today's featured deals</h2></div>
      <p class="muted">Codes are supplied by merchants through official affiliate programs. Confirm the discount in your cart before you pay.</p>
    </div>
    <div class="filters" role="toolbar" aria-label="Filter offers">{chip_html}</div>
    <div class="coupon-grid" id="coupon-grid">
{cards}
    </div>
    <p class="empty" id="empty" hidden>No offers match that search. <button class="linklike" data-reset>Show all offers</button></p>
  </div>
</section>

{ttd_teaser()}

{amazon_section()}

{tazty_section()}

<section class="section" id="stores">
  <div class="wrap">
    <div class="section-head"><div><p class="eyebrow">Featured brands</p><h2>Shop by store</h2></div><p class="muted">Each store has its own guide with current codes, how-to steps and answers to common questions.</p></div>
    <div class="store-tiles">
{stores}
    </div>
  </div>
</section>

<section class="section section-dark" id="new-vendors">
  <div class="wrap partner-band">
    <div><p class="eyebrow eyebrow-light">Coming soon</p><h2>New vendors are joining CouponDepots</h2>
    <p>We're adding new brands every month. Want your store in front of deal-ready shoppers? Partner with us through Awin, Impact, CJ or ShareASale.</p></div>
    <div class="partner-actions"><a class="btn btn-gold" href="/contact/#partner">Become a partner</a><a class="btn btn-ghost" href="/contact/#submit">Submit a coupon</a></div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head"><div><p class="eyebrow">How it works</p><h2>Save in three steps</h2></div></div>
    <ol class="steps">
      <li><span>01</span><h3>Pick an offer</h3><p>Browse every featured brand coupon and deal above, or search by store or product.</p></li>
      <li><span>02</span><h3>Reveal &amp; copy</h3><p>Tap <em>Show code</em>. We copy it for you and open the store in a new tab.</p></li>
      <li><span>03</span><h3>Paste at checkout</h3><p>Apply the code in the store's promo field and confirm the discount before paying.</p></li>
    </ol>
    <p class="center"><a class="link-more" href="/how-we-verify/">How we source and check offers {ARROW}</a></p>
  </div>
</section>

<section class="section section-soft">
  <div class="wrap">
    <div class="section-head"><div><p class="eyebrow">Shopping guides</p><h2>Research before you buy</h2></div><a class="link-more" href="/blog/">All guides {ARROW}</a></div>
    <div class="post-grid">{"".join(post_card(p) for p in POSTS[:3])}</div>
  </div>
</section>

{signup_html("home")}

{faq_html(HOME_FAQ)}
'''
    schema = [
        {"@type": "WebPage", "@id": f"{BASE}/#webpage", "url": f"{BASE}/", "name": "CouponDepots: Save More Every Day",
         "isPartOf": {"@id": f"{BASE}/#website"}, "about": {"@id": f"{BASE}/#organization"},
         "datePublished": "2026-08-31", "dateModified": TODAY,
         "primaryImageOfPage": {"@type": "ImageObject", "url": U("1483181957632-8bda974cbc91", 1200, 630)}},
        {"@type": "ItemList", "name": "CouponDepots featured brands", "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "name": f"{b['name']} coupons", "url": BASE + b["url"]} for i, b in enumerate(BRANDS)]},
        faq_schema(HOME_FAQ),
    ]
    write("/", page("/", "CouponDepots: Featured Brand Coupons & Deals, Updated Daily",
                    f"Every CouponDepots coupon and deal on one page: {', '.join(b['name'] for b in BRANDS[:6])} and more. New codes added daily. Free to use.",
                    body, schema, active="Coupons", extra_head=hero_preload()))
    add_sm("/", TODAY, "1.0")

# ---------------------------------------------------------------- STORE PAGES
STORE_CONTENT = {
"monvane": dict(
    title="Monvane Coupon Code: 10% Off with MONAFF10 | CouponDepots",
    desc="Monvane coupon codes: MONAFF10 for 10% off your first order and AFF5OFF for 5% off, no minimum spend. Modular boneless sofas from $139.",
    h1="Monvane Coupon Code & Promo Codes",
    intro="Monvane makes modular boneless sofas designed to adapt to everyday living, with deep seating, high-resilience foam, and recyclable materials.",
    body='''<h2>Featured Monvane product</h2>
<p><strong>Oversized Sofa Bed, from $139.</strong> A versatile 3-in-1 sofa, lounger and sleeper, ideal for apartments and small spaces.</p>
<h2>How to apply a Monvane coupon</h2>
<ol class="howto"><li><strong>Visit Monvane.</strong> Open Monvane through the sponsored link on this page to browse current furniture options.</li>
<li><strong>Check the current promotion details.</strong> Review the offer terms shown by Monvane before adding an item to your cart.</li>
<li><strong>Enter your code.</strong> Paste MONAFF10 (new customers) or AFF5OFF at checkout exactly as shown and confirm the discount before completing your order.</li></ol>
<h2>Why choose a Monvane modular sofa</h2>
<p>Modular seating can be rearranged as your room, routine, or household changes. Instead of committing to one fixed sofa silhouette, you can build a compact chaise, an L-shape, a conversation layout or a longer lounge setup, then reconfigure later.</p>
<p>Explore the product page for current material, comfort, delivery, and warranty information before purchase. Measure your wall length and walkway clearance first. Our <a href="/blog/best-home-lifestyle-deals-may-2026/">home &amp; lifestyle guide</a> has a full modular-sofa planning checklist.</p>''',
    faqs=[("Does CouponDepots have a working Monvane coupon code?", "Yes. MONAFF10 gives new customers 10% off with no minimum spend (one use per customer, combinable with spend-based discounts). AFF5OFF gives 5% off with no minimum and unlimited use."),
          ("Can I combine Monvane codes?", "MONAFF10 can be combined with Monvane's spend-based discounts. Checkout normally accepts one promo code at a time, so new customers will usually save most with MONAFF10."),
          ("Where can I find current Monvane offers?", "On this page and on Monvane's official site. Review the terms shown at checkout before you pay."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission when you buy through our sponsored link, at no extra cost to you.")]),
"simple-project": dict(
    title="Simple Project Coupon Code: 10% Off EARLY10 | CouponDepots",
    desc="Simple Project US Black Friday early bird code EARLY10: 10% off sitewide on macerating toilets, tall toilets, ADA vanities, mirror cabinets and shower pans, valid through Nov 16.",
    h1="Simple Project US Coupon Code & Black Friday Deals",
    intro="Simple Project US sells bathroom upgrades, including SNFLEX macerating toilets for basements and rooms where standard drainage is difficult, tall toilets, ADA vanities, lighted mirror cabinets and shower pans.",
    body='''<h2>Current Simple Project US code</h2>
<p>Use <strong>EARLY10</strong> for <strong>10% off sitewide</strong> during the Black Friday Early Bird Sale, valid through November 16, 2026. Confirm the discount in your cart before you pay.</p>
<h2>What to check before buying a macerating toilet</h2>
<ul><li>Your existing plumbing layout and local code requirements. Consider a qualified installer.</li>
<li>Rough-in dimensions, electrical needs, pump capacity, noise expectations and what's in the box.</li>
<li>The complete delivered price, shipping for your address, and return conditions before installation.</li></ul>
<h2>How to use the code</h2>
<ol class="howto"><li><strong>Reveal the code.</strong> Tap <em>Show code</em> above; we copy it and open Simple Project US.</li>
<li><strong>Add your bathroom upgrade</strong> to the cart.</li>
<li><strong>Paste EARLY10 at checkout</strong> and confirm the 10% comes off before paying.</li></ol>
<p>Read the full comparison in our <a href="/blog/3-upgrades-save-money-2026/">home &amp; beauty upgrades guide</a>.</p>''',
    faqs=[("Which Simple Project US coupon code works right now?", "EARLY10 gives 10% off sitewide during the Black Friday Early Bird Sale, valid through November 16, 2026."),
          ("What is a macerating toilet?", "A macerating (upflush) toilet breaks down waste and pumps it through a smaller discharge pipe, which can suit basements and rooms where gravity drainage is difficult."),
          ("Will there be more Simple Project Black Friday deals?", 'We add new Simple Project US codes here and on our <a href="/black-friday-deals/">Black Friday page</a> as soon as they are released.'),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission when you buy through our sponsored link, at no extra cost to you.")]),
"everblog": dict(
    title="Everblog FridgeCal Coupons & Current Offers | CouponDepots",
    desc="Shop Everblog FridgeCal, the smart family calendar display for your fridge. See current Everblog offers, how to apply a code and what to check before buying.",
    h1="Everblog FridgeCal Guide & Current Offers",
    intro="Everblog offers FridgeCal, a smart family display designed for kitchen planning and household organization, with shared calendars, reminders and household planning in one place.",
    body='''<div class="callout"><strong>Offer status:</strong> We don't currently have an Everblog coupon code, product price, bundle price or sale terms confirmed by official merchant evidence. Review the Everblog site for current availability, eligibility and checkout terms.</div>
<h2>Why explore Everblog FridgeCal?</h2>
<div class="feature-grid"><div><h3>Household planning</h3><p>Review Everblog's current tools for coordinating a busy household.</p></div>
<div><h3>Calendar connectivity</h3><p>Check current calendar connection options and setup requirements directly with the merchant.</p></div>
<div><h3>Kitchen organization</h3><p>Explore product information for planning meals and home routines.</p></div>
<div><h3>Product accessories</h3><p>Review compatible accessories and included features on the official product pages.</p></div></div>
<h2>How to apply an Everblog coupon</h2>
<ol class="howto"><li><strong>Visit Everblog.</strong> Use the sponsored merchant link to explore current products.</li>
<li><strong>Review eligibility.</strong> Confirm product details, pricing, and any active promotion requirements before checkout.</li>
<li><strong>Apply a confirmed code.</strong> If Everblog publishes an eligible code, enter it exactly as directed at checkout.</li></ol>
<p>Planning tips for mounting, compatibility and family routines are in our <a href="/blog/best-home-lifestyle-deals-may-2026/">home &amp; lifestyle guide</a>.</p>''',
    faqs=[("Does CouponDepots have a verified Everblog coupon code?", "Not right now. We only publish Everblog codes when supported by official merchant evidence. Check the Everblog site for current promotions."),
          ("What is FridgeCal?", "FridgeCal is Everblog's smart family calendar display that attaches to a refrigerator for shared scheduling, reminders and kitchen organization."),
          ("Can FridgeCal connect to calendars?", "Everblog positions FridgeCal around shared calendars. Check the official product page for the calendar services currently supported and setup requirements."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission when you buy through our sponsored link, at no extra cost to you.")]),
"zlike-hair": dict(
    title="Zlike Hair Coupons & Shopping Guide: Glueless Wigs | CouponDepots",
    desc="Shop Zlike Hair glueless lace wigs, 300% density styles, Body Wave and Water Wave textures. Wig-buying checklist, coupon guidance and FAQs.",
    h1="Zlike Hair: Styles & Shopping Guide",
    intro="Explore Zlike Hair product categories and coupon guidance. Zlike Hair is a hair brand whose catalog is associated with wigs, extensions, and style-focused hair options.",
    body='''<div class="callout"><strong>Offer status:</strong> Promotional offers and coupon codes are not currently listed for Zlike Hair. Check the brand's official site for current promotion terms before shopping.</div>
<h2>About Zlike Hair</h2>
<p>Shoppers often compare construction, texture, length, cap fit, color, and maintenance needs before choosing a piece. Product names and availability can change, so it is useful to review the current listing details directly with the brand before making a purchase.</p>
<p>For shoppers researching a fuller look, 300% Density is a term that may appear in product descriptions. Density is one of several details to weigh alongside cap size, lace area, hairline customization, and the amount of styling desired. Glueless Lace Wigs may appeal to people looking for an installation approach that does not rely on adhesive, but the right choice depends on fit, routine, and the care instructions for the specific product.</p>
<p>Style research can also help narrow the search. Butterfly Haircuts are known for layered movement, while Body Wave and Water Wave describe different texture looks. Consider how each texture may respond to daily styling, washing, detangling, and humidity.</p>
<h2>Popular product categories to explore</h2>
<div class="feature-grid"><div><h3>Glueless lace wigs</h3><p>Explore cap construction, lace details, and fit guidance.</p></div>
<div><h3>300% density styles</h3><p>Compare fullness, length, and daily styling needs.</p></div>
<div><h3>Body Wave textures</h3><p>Review texture care and styling inspiration.</p></div>
<div><h3>Water Wave textures</h3><p>Consider curl definition and maintenance guidance.</p></div>
<div><h3>Layered haircut looks</h3><p>Browse styles inspired by Butterfly Haircuts.</p></div>
<div><h3>Hair care essentials</h3><p>Check brand guidance for washing, storage, and upkeep.</p></div></div>
<h2>How to apply a coupon</h2>
<ol class="howto"><li><strong>Find a current offer</strong> on the brand's official channels.</li>
<li><strong>Review the terms:</strong> eligibility, exclusions, dates and minimum-purchase requirements.</li>
<li><strong>Apply at checkout</strong> only when the terms match your order.</li></ol>
<p>More on density and textures in our <a href="/blog/3-upgrades-save-money-2026/">home &amp; beauty upgrades guide</a>.</p>''',
    faqs=[("Are there active Zlike Hair coupon codes on this page?", "Not currently. We don't list Zlike Hair codes until they're confirmed. Check Zlike Hair's official site for live promotions."),
          ("Where should I verify a Zlike Hair offer?", "On Zlike Hair's official website and in your cart at checkout, where the final terms and price are shown."),
          ("What should I compare before choosing a wig?", "Cap size and construction, lace area, density, texture, length, color, care requirements and the current return policy."),
          ("What does glueless mean for a wig?", "A glueless wig is designed to be worn without adhesive, typically using adjustable straps, combs, an elastic band or pre-cut lace. Fit varies by item.")]),
"brkox": dict(
    title="BRKOX Coupons & Deals: LEGO Display Cases | CouponDepots",
    desc="Shop BRKOX display cases and light kits for LEGO builds through CouponDepots. How to choose the right case size, plus current offer status and FAQs.",
    h1="Shop BRKOX through CouponDepots",
    intro="Visit BRKOX through our sponsored link. BRKOX offers display options for LEGO builds, cases that keep models visible while reducing everyday dust exposure.",
    body='''<div class="callout"><strong>Offer status:</strong> We do not list a coupon code, discount amount, product availability, or offer expiration here because none has been confirmed for publication. See current offers directly on BRKOX.</div>
<h2>About this merchant link</h2>
<p>CouponDepots shares affiliate links when a merchant makes them available through an affiliate network. This page lists the BRKOX merchant destination confirmed for CouponDepots.</p>
<h2>How to choose a display case</h2>
<ul><li><strong>Measure the model and the shelf.</strong> Note the assembled width, depth and height, then add clearance so fragile pieces don't catch.</li>
<li><strong>Check materials and assembly.</strong> Review panel thickness, assembly steps and cleaning guidance; clear acrylic needs careful handling.</li>
<li><strong>Plan any light kit.</strong> Confirm compatibility with your exact set, wire routing, power source and whether disassembly is required.</li></ul>
<h2>How to use this link</h2>
<ol class="howto"><li><strong>Select Visit BRKOX.</strong> Use the sponsored button on this page to open the merchant's website.</li>
<li><strong>Review the merchant's current offers.</strong> See the latest products, pricing, shipping, and promotions directly on BRKOX.</li>
<li><strong>Complete your purchase with the merchant.</strong> Any purchase is completed securely on the merchant's own website.</li></ol>''',
    faqs=[("Does CouponDepots have a BRKOX coupon code?", "Not right now. No BRKOX code has been confirmed for publication. Check BRKOX's site for current promotions."),
          ("What does BRKOX sell?", "BRKOX offers display cases and light kits designed for LEGO builds."),
          ("How do I pick the right display case size?", "Measure the assembled model's width, depth and height, add clearance, and check the case fits your shelf or cabinet."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission from qualifying purchases made through this sponsored link. It does not change the price you pay.")]),
"fntcase": dict(
    title="FNTCASE Coupons: iPhone 17 & Samsung Cases | CouponDepots",
    desc="Shop FNTCASE phone cases for iPhone 17, Samsung, Pixel and Motorola through CouponDepots. Current offer status, how to pick a case, and FAQs.",
    h1="FNTCASE Phone Case Deals & Shopping Guide",
    intro="FNTCASE makes protective phone cases for iPhone, Samsung, Google Pixel and Motorola, from rugged kickstand and belt-clip holsters to slim MagSafe and clear cases.",
    body='''<div class="callout"><strong>Offer status:</strong> We don't have an FNTCASE coupon code confirmed for publication yet. Prices on FNTCASE's site started at $18.99 for iPhone 17 cases when we checked in October 2026. Confirm current pricing and shipping on FNTCASE before you buy.</div>
<h2>Popular FNTCASE styles</h2>
<div class="feature-grid"><div><h3>Rugged holster cases</h3><p>Military-grade drop protection with a built-in kickstand, screen protector and rotating belt clip.</p></div>
<div><h3>MagSafe ring-stand cases</h3><p>Matte translucent cases with a 360° metal ring stand and MagSafe magnets for chargers and mounts.</p></div>
<div><h3>Clear cases</h3><p>Anti-yellowing clear cases that show off your phone's color and support wireless charging.</p></div>
<div><h3>Samsung, Pixel and Motorola</h3><p>Cases for the latest Galaxy models, including the Z Fold series, plus Pixel and Motorola phones.</p></div></div>
<h2>How to pick the right case</h2>
<ul><li><strong>Match the exact model.</strong> An iPhone 17 case won't fit the 17 Pro or Pro Max; check the model name on the product page.</li>
<li><strong>Choose your protection level.</strong> Rugged holsters suit work and outdoor use; slim and clear cases suit everyday carry.</li>
<li><strong>Check MagSafe and charging.</strong> If you use MagSafe chargers or car mounts, pick a case with built-in magnets.</li></ul>
<h2>How to use this link</h2>
<ol class="howto"><li><strong>Select Visit FNTCASE.</strong> Use the sponsored button on this page to open the merchant's website.</li>
<li><strong>Find your phone model.</strong> Browse FNTCASE's collections for your exact phone.</li>
<li><strong>Complete your purchase with the merchant.</strong> Review the price, shipping and returns, then check out on FNTCASE's own site.</li></ol>''',
    faqs=[("Does CouponDepots have an FNTCASE coupon code?", "Not yet. No FNTCASE code has been confirmed for publication. We'll add one here as soon as FNTCASE provides it."),
          ("Which phones does FNTCASE make cases for?", "FNTCASE covers iPhone, Samsung Galaxy (including the Z Fold series), Google Pixel, Motorola and some OnePlus models."),
          ("Does FNTCASE offer free shipping?", "FNTCASE lists free shipping on its site. Check the current terms for your address at checkout."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission from qualifying purchases made through this sponsored link. It does not change the price you pay.")]),
}

ANSWER_CSS = '<style>.answer{margin:0 0 22px;padding:14px 18px;border-left:4px solid var(--gold,#b8913a);background:var(--card);border-radius:var(--r-sm,8px);font-size:1.02rem}.answer strong{color:var(--text)}</style>'

def answer_box(b, offers):
    """One-sentence answer at the top of each store page. AI assistants and Google quote the first clear answer.
    Help: https://developers.google.com/search/docs/appearance/featured-snippets"""
    codes = [o for o in offers if o["type"] == "code"]
    if codes:
        o = codes[0]
        more = f" {len(codes) - 1} more {b['name']} code{'s' if len(codes) > 2 else ''} below." if len(codes) > 1 else ""
        txt = (f"<strong>Best {e(b['name'])} code today: {e(o['code'])}</strong> ({e(o['value'])} {e(o['unit'])}: {e(o['title'])}). "
               f"Checked {TODAY_HUMAN}.{more}")
    elif offers:
        o = offers[0]
        txt = f"<strong>Best {e(b['name'])} deal today:</strong> {e(o['title'])}. No code needed. Checked {TODAY_HUMAN}."
    else:
        return ""
    return f'{ANSWER_CSS}<p class="answer">{txt}</p>'

def offer_schema(o, b):
    d = {"@type": "Offer", "name": f"{b['name']}: {o['title']}", "description": o["detail"], "url": BASE + b["url"],
         "seller": {"@type": "Organization", "name": b["name"]}, "availability": "https://schema.org/InStock"}
    if o.get("expires"):
        d["validThrough"] = o["expires"]
    if o["type"] == "code":
        d["description"] = f"Code {o['code']}. " + o["detail"]
    return d

def build_store(b):
    c = STORE_CONTENT.get(b["slug"]) or store_content_for(b)
    offers = [o for o in OFFERS if o["brand"] == b["slug"]]
    bf = (f'''<section class="section section-tight"><div class="wrap"><div class="callout"><strong>Black Friday {e(b["name"])}:</strong> Black Friday is {human_date(BF_DATE)}. We add {e(b["name"])}'s Black Friday and Cyber Monday codes here as soon as they're released. <a href="/black-friday-deals/">See all Black Friday deals</a> or <a href="#deal-alerts">get alerts</a>.</div></div></section>''') if holiday_on() else ""
    adult = '<span class="tag tag-adult">18+</span>' if b.get("adult") else ""
    others = [x for x in BRANDS if x["slug"] != b["slug"]][:3]
    body = f'''
<section class="store-hero">
  <div class="store-hero-media">{img(b["img"], alt_for(b), 1600, 700, lazy=False, cls="hero-img", sizes="100vw", hero=True)}</div>
  <div class="wrap store-hero-inner">
    <nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><a href="/#stores">Stores</a><span>/</span><span aria-current="page">{e(b["name"])}</span></nav>
    <p class="eyebrow eyebrow-light">{e(b["cat_label"])} · Sponsored merchant {adult}</p>
    <h1>{e(c["h1"])}</h1>
    <p class="hero-sub">{e(c["intro"])}</p>
    <div class="hero-actions">{aff_a(b["slug"], f"Visit {e(b['name'])} {ARROW}")}<span class="updated">Updated {TODAY_HUMAN}</span></div>
  </div>
</section>
<section class="section section-tight">
  <div class="wrap">
    {answer_box(b, offers)}
    <div class="section-head"><div><p class="eyebrow">{e(b["name"])} coupons</p><h2>Current {e(b["name"])} offers</h2></div></div>
    <div class="coupon-grid coupon-grid-2">{grid_cards(offers)}</div>
    <p class="fine">We may earn a commission when you use our sponsored {e(b["name"])} link, at no extra cost to you. <a href="/disclosure/">Affiliate disclosure</a>.</p>
  </div>
</section>
<section class="section section-tight">
  <div class="wrap content-grid">
    <article class="prose">{c["body"]}</article>
    <aside class="side">
      <div class="side-card"><p class="eyebrow">Quick facts</p><dl><dt>Store</dt><dd>{e(b["name"])}</dd><dt>Category</dt><dd>{e(b["cat_label"])}</dd><dt>Offers</dt><dd>{len(offers)}</dd><dt>Network</dt><dd>Awin</dd><dt>Last checked</dt><dd>{TODAY_HUMAN}</dd></dl>{aff_a(b["slug"], f"Shop {e(b['name'])}", "btn btn-dark btn-block")}</div>
    </aside>
  </div>
</section>
{bf}
{faq_html(c["faqs"], f"{b['name']} coupon questions")}
{signup_html("store-" + b["slug"])}
<section class="section section-soft"><div class="wrap"><div class="section-head"><div><p class="eyebrow">Keep saving</p><h2>More featured brands</h2></div><a class="link-more" href="/#deals">All coupons {ARROW}</a></div>
<div class="store-grid store-grid-3">{"".join(store_card(x) for x in others)}</div></div></section>
'''
    schema = [
        {"@type": "WebPage", "@id": f"{BASE}{b['url']}#webpage", "url": BASE + b["url"], "name": c["title"],
         "description": c["desc"], "isPartOf": {"@id": f"{BASE}/#website"}, "dateModified": TODAY,
         "about": {"@type": "Brand", "name": b["name"]},
         "primaryImageOfPage": {"@type": "ImageObject", "url": U(b["img"], 1200, 630)}},
        crumbs([("Home", "/"), ("Stores", "/#stores"), (b["name"], b["url"])]),
        faq_schema(c["faqs"]),
    ]
    if offers:
        schema.append({"@type": "OfferCatalog", "name": f"{b['name']} coupon codes and deals", "url": BASE + b["url"],
                       "itemListElement": [offer_schema(o, b) for o in offers]})
    write(b["url"], page(b["url"], c["title"], c["desc"], body, schema, og_img=b["img"], active="Stores"))
    add_sm(b["url"], TODAY, "0.8")

# ---------------------------------------------------------------- BLOG
POSTS = []
def load_posts():
    d = os.path.join(ROOT, "content", "posts")
    for fn in sorted(os.listdir(d)):
        raw = open(os.path.join(d, fn), encoding="utf-8").read()
        _, fm, md = raw.split("---", 2)
        meta = {}
        for line in fm.strip().splitlines():
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip()
        meta["slug"] = fn[:-3]
        meta["md"] = md.strip()
        meta["url"] = f"/blog/{meta['slug']}/"
        POSTS.append(meta)
    POSTS.sort(key=lambda p: p["date"], reverse=True)

def human_date(d):
    return datetime.date.fromisoformat(d).strftime("%B %-d, %Y")

def post_card(p):
    return f'''<a class="post-card" href="{p["url"]}"><div class="post-img">{img(p["image"], p["title"], 640, 400)}</div>
<div class="post-info"><p class="post-meta">{e(p["category"])} · {human_date(p["date"])}</p><h3>{e(p["title"])}</h3><p>{e(p["excerpt"])}</p></div></a>'''

def render_md(md):
    def cta(m):
        slug, text = m.group(1), m.group(2)
        b = B[slug]
        return (f'<div class="cta-box"><div><strong>{e(b["name"])}</strong><span>{e(b["tagline"])}</span></div>'
                f'{aff_a(slug, e(text) + " " + ARROW)}</div>')
    md = re.sub(r"\{\{CTA:([\w-]+):(.+?)\}\}", cta, md)
    if "{{LIVECODES}}" in md:  # live list of brands that have codes right now (updates on every build)
        rows = []
        for b in BRANDS:
            codes = [o for o in OFFERS if o["brand"] == b["slug"] and o["type"] == "code"]
            if codes:
                rows.append(f"- [{b['name']} coupon codes]({b['url']}): {len(codes)} code{'s' if len(codes) != 1 else ''}, including **{codes[0]['code']}** ({codes[0]['title']})")
        md = md.replace("{{LIVECODES}}", "\n".join(rows[:10]) or "- [See all coupons](/#deals)")
    md = re.sub(r"\{\{LINK:([\w-]+):(.+?)\}\}", lambda m: aff_a(m.group(1), e(m.group(2)), "inline-aff"), md)
    h = markdown.markdown(md, extensions=["extra", "sane_lists"])
    h = h.replace("<table>", '<table>')
    return h

def extract_faq(md):
    m = re.search(r"^## (Frequently asked questions|People also ask)\s*$(.*?)(?=^## |\Z)", md, re.S | re.M)
    if not m:
        return []
    out = []
    for q, a in re.findall(r"^### (.+?)\s*\n+(.+?)(?=\n+### |\Z)", m.group(2), re.S | re.M):
        out.append((q.strip(), markdown.markdown(a.strip())[3:-4]))
    return out

def toc(md):
    hs = re.findall(r"^## (.+)$", md, re.M)
    return hs

def slugify(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")

def build_post(p):
    body_html = render_md(p["md"])
    heads = toc(p["md"])
    for h_ in heads:
        rendered = markdown.markdown("## " + h_)[4:-5]
        body_html = body_html.replace(f"<h2>{rendered}</h2>", f'<h2 id="{slugify(h_)}">{rendered}</h2>', 1)
    toc_html = "".join(f'<li><a href="#{slugify(h_)}">{e(re.sub(r"[*_]", "", h_))}</a></li>' for h_ in heads)
    faqs = extract_faq(p["md"])
    words = len(re.findall(r"\w+", p["md"]))
    mins = max(1, round(words / 230))
    brands = [s.strip() for s in p.get("brands", "").split(",") if s.strip()]
    related = "".join(store_card(B[s]) for s in brands)
    rel_html = f'<section class="section section-soft"><div class="wrap"><div class="section-head"><div><p class="eyebrow">Stores in this guide</p><h2>Shop the brands</h2></div></div><div class="store-grid store-grid-3">{related}</div></div></section>' if related else ""
    more = "".join(post_card(x) for x in POSTS if x["slug"] != p["slug"])[:]
    body = f'''
<article>
<header class="post-hero">
  <div class="post-hero-media">{img(p["image"], p["title"], 1600, 700, lazy=False, cls="hero-img", sizes="100vw", hero=True)}</div>
  <div class="wrap narrow post-hero-inner">
    <nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><a href="/blog/">Guides</a><span>/</span><span aria-current="page">{e(p["category"])}</span></nav>
    <p class="eyebrow eyebrow-light">{e(p["category"])}</p>
    <h1>{e(p["title"])}</h1>
    <p class="post-byline">By CouponDepots Editorial Team · Published {human_date(p["date"])} · Updated {TODAY_HUMAN} · {mins} min read</p>
  </div>
</header>
<div class="wrap content-grid post-layout">
  <div class="prose">
    <p class="summary"><strong>Summary:</strong> {e(p["excerpt"])}</p>
    {body_html}
  </div>
  <aside class="side"><div class="side-card sticky"><p class="eyebrow">In this guide</p><ol class="toc">{toc_html}</ol><a class="btn btn-dark btn-block" href="/#deals">See all coupons</a></div></aside>
</div>
</article>
{rel_html}
<section class="section"><div class="wrap"><div class="section-head"><div><p class="eyebrow">Keep reading</p><h2>More shopping guides</h2></div></div><div class="post-grid">{more}</div></div></section>
'''
    schema = [
        {"@type": "BlogPosting", "@id": f"{BASE}{p['url']}#article", "headline": p["title"], "description": p["description"],
         "image": U(p["image"], 1200, 630), "datePublished": p["date"], "dateModified": TODAY,
         "author": {"@type": "Organization", "name": "CouponDepots Editorial Team", "url": f"{BASE}/about/"},
         "publisher": {"@id": f"{BASE}/#organization"}, "mainEntityOfPage": BASE + p["url"],
         "articleSection": p["category"], "wordCount": words, "inLanguage": "en-US"},
        crumbs([("Home", "/"), ("Guides", "/blog/"), (p["title"], p["url"])]),
    ]
    if faqs:
        schema.append(faq_schema(faqs))
    write(p["url"], page(p["url"], p["seo_title"], p["description"], body, schema, og_img=p["image"], active="Guides", og_type="article"))
    add_sm(p["url"], TODAY, "0.7")

ARTICLES_JSON = os.environ.get("ARTICLES_JSON", os.path.join(ROOT, "articles", "posts.json"))

def daily_guides():
    """Daily buying guides written by the seo-controller blog bot into the repo's articles/ folder."""
    try:
        posts = json.load(open(ARTICLES_JSON, encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return sorted([x for x in posts if x.get("file") and x.get("title")], key=lambda x: x.get("date", ""), reverse=True)

def daily_guides_html():
    items = daily_guides()
    if not items:
        return ""
    li = "".join(f'<li><a href="/articles/{e(x["file"])}"><strong>{e(x["title"])}</strong></a>'
                 f'<span class="muted"> · {human_date(x["date"]) if x.get("date") else ""}</span><br><span class="small">{e(x.get("description", ""))}</span></li>'
                 for x in items[:24])
    return f'''<section class="section section-soft"><div class="wrap narrow"><div class="section-head"><div><p class="eyebrow">New every day</p><h2>Daily buying guides</h2></div><a class="link-more" href="/articles/">All daily guides {ARROW}</a></div>
<ul class="guide-list" style="list-style:none;padding:0;display:grid;gap:14px">{li}</ul></div></section>'''

def build_blog_index():
    body = f'''
<section class="page-hero"><div class="wrap narrow"><p class="eyebrow">Shopping guides</p><h1>CouponDepots Shopping Guides</h1><p class="lead">Evidence-based buying guides, savings systems and store breakdowns. We only state prices and codes we can verify.</p></div></section>
<section class="section section-tight"><div class="wrap"><div class="post-grid">{"".join(post_card(p) for p in POSTS)}</div></div></section>
{daily_guides_html()}'''
    schema = [{"@type": "CollectionPage", "@id": f"{BASE}/blog/#webpage", "url": f"{BASE}/blog/", "name": "The CouponDepots Blog",
               "isPartOf": {"@id": f"{BASE}/#website"}, "hasPart": [{"@type": "BlogPosting", "headline": p["title"], "url": BASE + p["url"]} for p in POSTS]
                          + [{"@type": "BlogPosting", "headline": x["title"], "url": f"{BASE}/articles/{x['file']}"} for x in daily_guides()]},
              crumbs([("Home", "/"), ("Guides", "/blog/")])]
    write("/blog/", page("/blog/", "Shopping Guides & Savings Tips | CouponDepots Blog",
                         "Shopping guides, savings tips and store breakdowns from CouponDepots: home upgrades, modular sofas, wigs, LEGO display cases and how to save every week.",
                         body, schema, og_img="1556742049-0cfed4f6a45d", active="Guides"))
    add_sm("/blog/", TODAY, "0.8")

# ---------------------------------------------------------------- INFO PAGES
def simple_page(path, title, desc, h1, lead, inner, eyebrow="", faqs=None, img_id=None, active=""):
    faq_block = faq_html(faqs) if faqs else ""
    body = f'''
<section class="page-hero"><div class="wrap narrow"><nav class="crumbs crumbs-dark" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><span aria-current="page">{e(h1)}</span></nav>{f'<p class="eyebrow">{eyebrow}</p>' if eyebrow else ''}<h1>{e(h1)}</h1><p class="lead">{lead}</p></div></section>
<section class="section section-tight"><div class="wrap narrow prose">{inner}</div></section>
{faq_block}'''
    schema = [{"@type": "WebPage", "@id": f"{BASE}{path}#webpage", "url": BASE + path, "name": title, "description": desc,
               "isPartOf": {"@id": f"{BASE}/#website"}, "dateModified": TODAY},
              crumbs([("Home", "/"), (h1, path)])]
    if faqs:
        schema.append(faq_schema(faqs))
    write(path, page(path, title, desc, body, schema, og_img=img_id or "1483181957632-8bda974cbc91", active=active))
    add_sm(path, TODAY, "0.5")

VERIFY_FAQ = [
    ("What does a \"Brand code\" label mean?", "The code was supplied by the merchant through its affiliate program for CouponDepots shoppers. We publish the merchant's stated terms with it."),
    ("What does \"No code needed\" mean?", "The discount applies automatically on the merchant's site, for example a sale price shown in the cart. You don't need to enter anything at checkout."),
    ("What happens when a coupon stops working?", "Tell us via the contact page or email. We review reports and remove or update broken offers as soon as we confirm the problem."),
    ("Does CouponDepots earn money from these deals?", "Yes. Some links are affiliate links. We may earn a commission when you buy, at no extra cost to you. Commission never decides whether an offer is accurate. See our <a href=\"/disclosure/\">affiliate disclosure</a>."),
    ("Can I submit a deal I found?", "Yes. Use the <a href=\"/contact/#submit\">submit a coupon</a> form. We check every submission against the merchant before publishing it."),
]

def build_info():
    simple_page("/how-we-verify/", "How We Verify Coupons | CouponDepots",
        "How CouponDepots sources, labels and checks coupons: official affiliate networks, merchant-supplied codes, price checks against the merchant's site, and fast removal of broken offers.",
        "How We Verify Coupons",
        "Every offer on CouponDepots is sourced from the merchant or its official affiliate network and clearly labeled, so you know exactly what you're getting.",
        f'''<div class="verify-steps">
<div><span>01</span><h3>Source confirmation</h3><p>Offers come from the retailer's own website, its official newsletter, or a verified affiliate network such as Awin, Impact, CJ or ShareASale. We never copy codes from other coupon aggregators.</p></div>
<div><span>02</span><h3>Evidence check</h3><p>Before publishing, we compare the code, price or promotion against the merchant's own site and terms. If we can't confirm an offer, we don't list a code, and the store page says so.</p></div>
<div><span>03</span><h3>Clear labels</h3><p>Every card says what it is: <strong>Brand code</strong>, <strong>No code needed</strong>, <strong>Featured product</strong> or <strong>Featured deal</strong>. Verified prices show the month they were checked.</p></div>
<div><span>04</span><h3>Ongoing review</h3><p>We re-check listed offers on a regular schedule and act on shopper reports. Expired or broken offers are removed or corrected once confirmed.</p></div>
</div>
<h2>Why we don't list codes we can't confirm</h2>
<p>Many coupon sites pad their pages with expired or invented codes. That wastes your time at checkout. CouponDepots would rather show fewer, real offers and link you straight to the merchant than promise savings that don't exist.</p>
<p>Spotted a problem? <a href="/contact/">Let us know</a> and we'll look into it.</p>''',
        eyebrow="Our process", faqs=VERIFY_FAQ, img_id="1472851294608-062f824d29cc", active="How we verify")

    simple_page("/about/", "About CouponDepots | Featured Brand Coupons & Shopping Guides",
        "CouponDepots is a free coupon and shopping-guide site based in Massachusetts, featuring brand codes and evidence-based buying guides from brands we work with directly.",
        "About CouponDepots",
        "We're on a mission to make saving money effortless, with real offers from real featured brands and nothing padded.",
        f'''<h2>Our mission</h2>
<p>CouponDepots was built with one goal in mind: make saving money effortless. We work directly with brands through official affiliate networks to bring you working coupon codes, verified deals and honest shopping guides, all on one page.</p>
<h2>Why shoppers trust us</h2>
<div class="feature-grid"><div><h3>Sourced from merchants</h3><p>Codes come from brands and their affiliate programs, not scraped from other coupon sites.</p></div>
<div><h3>Clearly labeled</h3><p>Every offer says what it is and when it was checked. If we can't confirm a code, we say so.</p></div>
<div><h3>Free forever</h3><p>CouponDepots is completely free. No subscriptions, no hidden fees, just savings.</p></div>
<div><h3>Growing every month</h3><p>New featured brands join regularly. <a href="/contact/#partner">Want yours listed?</a></p></div></div>
<h2>Built by shoppers, for shoppers</h2>
<p>We're a small Massachusetts-based team of deal hunters and editors. We write guides that help you compare products before you buy, and we disclose every sponsored relationship.</p>
<p><a class="btn btn-gold" href="/#deals">Browse all coupons</a></p>''',
        eyebrow="Who we are", img_id="1556742049-0cfed4f6a45d")

    simple_page("/disclosure/", "Affiliate Disclosure | CouponDepots",
        "How CouponDepots earns revenue through affiliate programs like Awin, Impact, CJ and ShareASale, and how we keep our listings independent. FTC-compliant disclosure.",
        "Affiliate Disclosure",
        "We believe in full transparency about how CouponDepots works and how we earn revenue.",
        '''<div class="callout"><strong>The short version:</strong> CouponDepots earns commissions from affiliate programs when you click certain links and make purchases. This never costs you anything extra. Our goal is to save you money.</div>
<h2>How we earn revenue</h2>
<p>CouponDepots participates in affiliate marketing programs, which may include:</p>
<ul><li>Awin</li><li>Impact.com</li><li>Commission Junction (CJ Affiliate)</li><li>ShareASale</li><li>Amazon Associates</li><li>Individual retailer affiliate programs</li></ul>
<p><strong>Amazon Associates:</strong> CouponDepots is a participant in the Amazon Services LLC Associates Program. As an Amazon Associate I earn from qualifying purchases. Amazon product links (tracking ID get786-20) are marked "Check price on Amazon" and open Amazon.com, where the current price is shown. See our <a href="/amazon-deals/">Amazon picks</a>.</p>
<p>When you click a link on CouponDepots and subsequently make a purchase, we may receive a commission from the retailer. The commission is paid by the retailer, not by you. You pay the same price (or less, with our coupons) as you would going directly to the store.</p>
<h2>Our editorial independence</h2>
<p>Affiliate relationships do not decide whether an offer is accurate. We only publish codes and prices we can support with merchant evidence, and we label sponsored links clearly. We will never promote a deal solely because it pays a higher commission.</p>
<h2>Link tracking</h2>
<p>Outbound merchant links on CouponDepots go through the merchant's affiliate network (for example awin1.com) so the merchant can attribute your visit. These redirects are instant and do not affect the price you pay. Sponsored links are marked with <code>rel="sponsored"</code>.</p>
<h2>FTC compliance</h2>
<p>In accordance with the Federal Trade Commission's guidelines on endorsements and testimonials (16 CFR Part 255), CouponDepots discloses its material connections to advertisers and affiliate networks on this page and on relevant pages throughout the site.</p>
<p class="fine">Last updated: October 19, 2026</p>
<p>Questions about this disclosure? <a href="/contact/">Get in touch</a>.</p>''', eyebrow="Transparency")

    simple_page("/contact/", "Contact CouponDepots | Partnerships & Support",
        "Contact CouponDepots: report a broken coupon, submit a deal, or partner with us. Email admin@coupondepots.info or call (313) 729-1534, Mon–Fri 9 AM–6 PM ET.",
        "Contact Us",
        "Have a question, found a broken coupon, or want to partner with us? We'd love to hear from you.",
        f'''<div class="contact-grid">
<div class="contact-card"><h3>Email us</h3><p><a href="mailto:{EMAIL}">{EMAIL}</a></p><p class="fine">We typically respond within 24 hours.</p></div>
<div class="contact-card"><h3>Call us</h3><p><a href="tel:{PHONE_TEL}">{PHONE}</a></p><p class="fine">Monday–Friday, 9 AM–6 PM ET. Closed on major US holidays.</p></div>
<div class="contact-card"><h3>Based in</h3><p>Massachusetts, USA</p><p class="fine">Serving deal hunters nationwide.</p></div>
</div>
<h2 id="partner">Add your store</h2>
<p>Want your brand featured on CouponDepots? We're onboarding new vendors now. Email <a href="mailto:{EMAIL}?subject=Partnership%20inquiry">{EMAIL}</a> with your brand name, affiliate network (Awin, Impact, CJ, ShareASale) and program ID, and any exclusive codes for our shoppers.</p>
<h2 id="submit">Submit a coupon</h2>
<p>Found a deal we're missing? Send the store, the code or deal, and where you found it. We check every submission against the merchant before publishing.</p>
<form class="contact-form" id="contact-form" action="https://formsubmit.co/ajax/{EMAIL}" method="post" data-contact novalidate>
<input type="hidden" name="_subject" value="CouponDepots contact form">
<input type="hidden" name="_template" value="table"><input type="hidden" name="_captcha" value="false">
<input type="text" name="_honey" tabindex="-1" autocomplete="off" aria-hidden="true" style="display:none">
<label>Topic<select name="topic" id="cf-topic"><option value="Submit a coupon">Submit a coupon</option><option value="Broken or expired coupon">Broken or expired coupon</option><option value="Add your store / partnership">Add your store / partnership</option><option value="Report an issue">Report an issue</option><option value="General inquiry">General inquiry</option></select></label>
<label>Your name<input name="name" autocomplete="name" required></label>
<label>Your email<input name="email" type="email" autocomplete="email" required><span class="fine">We only use it to reply to you. See our <a href="/privacy/">privacy notice</a>.</span></label>
<div class="cf-coupon" data-for="Submit a coupon|Broken or expired coupon">
<label>Store<input name="store" placeholder="e.g. Monvane or monvane.com" data-req><span class="fine">The brand or website the code is for.</span></label>
<label>Code or deal<input name="code" placeholder="e.g. SAVE15, or &quot;20% off sitewide, no code&quot;" data-req><span class="fine">The exact code, or describe the deal if no code is needed.</span></label>
</div>
<div class="cf-coupon" data-for="Submit a coupon">
<label>Where you found it<input name="source" type="url" placeholder="https://" data-req><span class="fine">A link to the merchant page, email or post that shows the offer.</span></label>
<label>Expires (optional)<input name="expires" type="date"><span class="fine">Leave blank if you don't know.</span></label>
</div>
<label>Message<textarea name="message" rows="5" id="cf-message" placeholder="Anything else we should know, like terms or minimum spend."></textarea></label>
<button class="btn btn-gold" type="submit">Send message</button>
<p class="fine cf-msg" role="status" hidden></p>
<p class="fine">Your message is delivered to our team through <a href="https://formsubmit.co/" rel="nofollow noopener" target="_blank">FormSubmit</a>. We check every coupon against the merchant before publishing (<a href="/how-we-verify/">how we verify</a>). Prefer email? Write to <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
</form>''', eyebrow="Get in touch", img_id="1556742049-0cfed4f6a45d")

    simple_page("/privacy/", "Privacy Notice | CouponDepots",
        "How CouponDepots collects, uses and shares information when you visit coupondepots.info, including cookies, affiliate tracking and your choices.",
        "Privacy Notice",
        "This notice explains how CouponDepots (\"we\" or \"us\") collects, uses and shares information when you use coupondepots.info.",
        f'''<h2>Information you provide</h2>
<p>If you contact us by email, phone or the contact form, we receive the information you choose to send, such as your name, email address and message, and use it to respond to you. Contact form messages are delivered to us through FormSubmit (formsubmit.co).</p>
<h2>Information collected automatically</h2>
<p>Like most websites, our hosting and analytics providers may collect device and usage information such as IP address, browser type, pages viewed and referring pages. We use it to keep the site secure and understand which content is useful.</p>
<h2>Cookies and affiliate tracking</h2>
<p>When you click a sponsored link, the affiliate network (for example Awin or Impact) and the merchant may set cookies to attribute your purchase to CouponDepots. Those cookies are governed by their privacy policies. Most browsers let you manage or block cookies in settings; see <a href="https://www.allaboutcookies.org" target="_blank" rel="noopener noreferrer">allaboutcookies.org</a>.</p>
<h2>How we use information</h2>
<ul><li>To operate, maintain and improve the site;</li><li>To respond to your messages and partnership inquiries;</li><li>To send deal-alert emails you sign up for (unsubscribe any time with the link in each email). Signups are delivered to our inbox through FormSubmit, a form-delivery service;</li><li>To measure affiliate performance;</li><li>To detect and prevent fraud and abuse; and</li><li>To comply with legal obligations.</li></ul>
<h2>How we share information</h2>
<p>We don't sell your personal information. We share it only with service providers who help run the site (hosting, analytics, affiliate networks), when required by law, or with your consent.</p>
<h2>Third-party sites</h2>
<p>Our pages link to merchants we don't own or operate. Their privacy practices apply once you leave CouponDepots. Please review their policies before sharing information.</p>
<h2>Children's privacy</h2>
<p>CouponDepots is not directed to children under 13, and we don't knowingly collect their personal information.</p>
<h2>International visitors</h2>
<p>The site is operated from the United States and intended for US shoppers. Information may be processed in the United States.</p>
<h2>Changes and contact</h2>
<p>We'll post any changes on this page. Questions: <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
<p class="fine">Last updated: October 19, 2026</p>''', eyebrow="Legal")

    simple_page("/terms/", "Terms of Use | CouponDepots",
        "Terms of use for coupondepots.info: use of the site, accuracy of offers, affiliate links, third-party merchants, and governing law (Massachusetts).",
        "Terms of Use",
        "CouponDepots (\"we\", \"us\" or \"our\") owns and operates coupondepots.info. By using the site, you agree to these terms.",
        f'''<h2>Use of the site</h2>
<p>We grant you a limited, revocable right to access and use the site for personal, non-commercial purposes. We may change, suspend or discontinue any part of the site at any time without notice.</p>
<h2>Offers and accuracy</h2>
<p>Coupons, prices and promotions are set by merchants and can change or end without notice. We work to keep listings accurate, but we don't guarantee that any offer will be available or applied. Always confirm the final price at the merchant's checkout.</p>
<h2>Affiliate links and third-party merchants</h2>
<p>Some links are affiliate links. Purchases are made with the merchant, not with CouponDepots, and are governed by the merchant's terms, shipping, return and privacy policies. We are not responsible for merchant products, services or content.</p>
<h2>Content standards</h2>
<p>If you submit a coupon or message, you confirm it's accurate and lawful and that you have the right to share it, and you grant us permission to review, edit and publish it. Don't submit content that is unlawful, misleading, infringing, abusive or spam.</p>
<h2>Intellectual property</h2>
<p>Site design, text and graphics are owned by CouponDepots or its licensors. Merchant names and logos belong to their respective owners.</p>
<h2>Disclaimer and limitation of liability</h2>
<p>The site is provided "as is" without warranties of any kind. To the fullest extent permitted by law, CouponDepots is not liable for any indirect or consequential damages arising from use of the site or reliance on any offer.</p>
<h2>Governing law</h2>
<p>These terms are governed by the laws of the Commonwealth of Massachusetts, without regard to conflict-of-law rules.</p>
<h2>Changes and contact</h2>
<p>We may update these terms; changes take effect when posted. Questions: <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
<p class="fine">Last updated: October 19, 2026</p>''', eyebrow="Legal")

# ---------------------------------------------------------------- REDIRECTS (old Airo URLs)
def redirect(old, new):
    target = new if new.startswith("http") else BASE + new
    is_ext = new.startswith("http")
    rel = ' rel="sponsored nofollow"' if is_ext else ""
    canon = "" if is_ext else f'<link rel="canonical" href="{target}">'
    html_ = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Redirecting… | CouponDepots</title>
{canon}<meta name="robots" content="noindex, follow"><meta http-equiv="refresh" content="0; url={e(new)}">
<script>location.replace({json.dumps(new)} + (location.hash||""))</script></head>
<body><p>This page has moved. <a href="{e(new)}"{rel}>Continue to the new page</a>.</p></body></html>'''
    write(old if old.endswith("/") else old + "/", html_)
    REDIRECTS.append((old, new))

REDIRECTS = []
def build_redirects():
    m = {
        "/stores": "/#stores", "/deals": "/#deals", "/store/": "/#stores",
        "/stores/brkox": B["brkox"]["url"], "/coupons/zlike-hair": B["zlike-hair"]["url"],
        "/monvane-coupon-code/": B["monvane"]["url"], "/everblog-coupon-code/": B["everblog"]["url"],
        "/store/best-home-lifestyle-deals-may-2026/": "/blog/best-home-lifestyle-deals-may-2026/",
        "/store/touredge-coupon-code/": "/#stores",
        "/coupons/fashion": "/?cat=fashion#deals", "/coupons/beauty": "/?cat=beauty#deals",
        "/coupons/sports": "/#deals", "/coupons/travel": "/#deals", "/coupons/food-&-dining": "/#deals",
        "/coupons/home": "/?cat=home#deals", "/coupons/electronics": "/#deals",
        "/furniture-coupons/": "/?cat=home#deals", "/home-decor-coupons/": "/?cat=home#deals",
        "/submit-coupon": "/contact/#submit", "/lp/save-more": "/#deals",
        "/go/brkox": B["brkox"]["link"], "/go/monvane": B["monvane"]["link"], "/go/zlike-hair": B["zlike-hair"]["link"],
        "/go/simple-project": B["simple-project"]["link"], "/go/everblog": B["everblog"]["link"],
        "/go/yeloly": "/#deals", "/store/yeloly-coupon-code/": "/#stores",  # Yeloly removed Nov 2026
    }
    for old, new in m.items():
        redirect(old, new)

# ---------------------------------------------------------------- 404, robots, sitemap, llms
def build_404():
    body = f'''<section class="page-hero"><div class="wrap narrow center"><p class="eyebrow">Error 404</p><h1>This page has expired, like an old coupon</h1>
<p class="lead">The page you're looking for doesn't exist or has moved. All of our live offers are on one page.</p>
<p><a class="btn btn-gold" href="/#deals">See all coupons</a> <a class="btn btn-ghost-dark" href="/blog/">Read our guides</a></p></div></section>
<section class="section section-tight"><div class="wrap"><div class="store-grid">{"".join(store_card(b) for b in BRANDS)}</div></div></section>'''
    out = page("/404.html", "Page not found | CouponDepots", "This page could not be found. Browse all CouponDepots featured brand coupons and deals.", body)
    out = out.replace('<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">', '<meta name="robots" content="noindex, follow">')
    out = re.sub(r'<link rel="canonical"[^>]+>\n', "", out)
    with open(os.path.join(OUT, "404.html"), "w", encoding="utf-8") as f:
        f.write(out)

def build_robots():
    bots = ["GPTBot", "OAI-SearchBot", "ChatGPT-User", "ClaudeBot", "Claude-SearchBot", "PerplexityBot", "Google-Extended", "Applebot-Extended", "Bingbot", "Googlebot"]
    txt = "# CouponDepots robots.txt\nUser-agent: *\nAllow: /\nDisallow: /go/\n\n"
    txt += "".join(f"User-agent: {b}\nAllow: /\nDisallow: /go/\n\n" for b in bots)
    txt += f"Sitemap: {BASE}/sitemap.xml\n"
    open(os.path.join(OUT, "robots.txt"), "w").write(txt)

def build_sitemap():
    rows = "".join(f"  <url>\n    <loc>{BASE}{p}</loc>\n    <lastmod>{lm}</lastmod>\n    <priority>{pr}</priority>\n  </url>\n" for p, lm, pr in SITEMAP)
    xml = f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n{rows}</urlset>\n'
    open(os.path.join(OUT, "sitemap.xml"), "w").write(xml)

def build_llms():
    L = [f"# {SITE}", "",
         "> CouponDepots (coupondepots.info) is a free US coupon and shopping-guide site. Every offer comes from a featured brand available on CouponDepots through an official affiliate network (mainly Awin). All live coupons and deals are on the homepage; each featured brand has a store guide page.", "",
         f"Last updated: {TODAY}. Contact: {EMAIL}, {PHONE}. Based in Massachusetts, USA.", "",
         "## Current coupon codes and deals"]
    for o in OFFERS:
        b = B[o["brand"]]
        code = f" Code: {o['code']}." if o["type"] == "code" else " No code needed." if o["label"] == "No code needed" else ""
        L.append(f"- {b['name']}: {o['title']}.{code} {o['detail']} Guide: {BASE}{b['url']}")
    L += ["", "## Featured brand store guides"]
    for b in BRANDS:
        L.append(f"- [{b['name']} coupons]({BASE}{b['url']}): {b['short']}{' Adults 18+ only.' if b.get('adult') else ''}")
    L += ["", f"## Amazon picks ({BASE}/amazon-deals/)",
          f"- {AMAZON_DISCLOSURE} Prices are not listed on CouponDepots; they are shown live on Amazon."]
    for p in AMAZON_PICKS:
        L.append(f"- {p['name']} ({dict(AMAZON_CATS)[p['cat']]}): {p['why']} {amz_url(p['asin'])}")
    L += ["", "## Holiday pages",
          f"- [Black Friday & Cyber Monday coupons]({BASE}/black-friday-deals/): Black Friday {BF_DATE[:4]} is {human_date(BF_DATE)}; early holiday codes and every live code.",
          f"- [Holiday gift guide]({BASE}/holiday-gift-guide/): practical gift ideas and gifts from brands with live codes."]
    L += ["", "## Shopping guides"]
    for p in POSTS:
        L.append(f"- [{p['title']}]({BASE}{p['url']}): {p['description']}")
    L += ["", "## About and policies",
          f"- [Home: all coupons]({BASE}/)",
          f"- [How we verify coupons]({BASE}/how-we-verify/): Offers are sourced from merchants or official affiliate networks, checked against the merchant's site, and clearly labeled (Brand code, No code needed, Featured product, Featured deal). Codes that can't be confirmed are not listed.",
          f"- [About]({BASE}/about/)", f"- [Affiliate disclosure]({BASE}/disclosure/)", f"- [Contact / partner with us]({BASE}/contact/)",
          f"- [Privacy]({BASE}/privacy/)", f"- [Terms]({BASE}/terms/)", "",
          "## Notes for AI assistants",
          "- Prices and codes are set by merchants and can change; recommend users confirm the discount in their cart.",
          "- Links to merchants are sponsored affiliate links; CouponDepots may earn a commission at no extra cost to the shopper.",
          "- Monvane codes: MONAFF10 (10% off, new customers, one use) and AFF5OFF (5% off, unlimited)."]
    open(os.path.join(OUT, "llms.txt"), "w").write("\n".join(L) + "\n")

# ---------------------------------------------------------------- main
def main():
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)
    shutil.copytree(os.path.join(ROOT, "static"), OUT, dirs_exist_ok=True)
    load_promos()
    load_posts()
    assign_deal_urls()
    build_home()
    for o in OFFERS:
        build_deal(o)
    for b in BRANDS:
        build_store(b)
    build_blog_index()
    for p in POSTS:
        build_post(p)
    build_info()
    build_amazon_page()
    build_bf()
    build_things_to_do()
    build_gifts()
    build_redirects()
    build_404()
    build_robots()
    build_sitemap()
    build_llms()
    open(os.path.join(OUT, "CNAME"), "w").write("coupondepots.info\n")
    open(os.path.join(OUT, ".nojekyll"), "w").write("")
    open(os.path.join(OUT, f"{INDEXNOW_KEY}.txt"), "w").write(INDEXNOW_KEY)
    print(f"Built {len(SITEMAP)} indexable pages + {len(REDIRECTS)} redirects into {OUT}")
    print(f"Promos: {PROMO_STATS['added']} live offers from promos.json, {PROMO_STATS['expired']} expired and hidden")

if __name__ == "__main__":
    main()
