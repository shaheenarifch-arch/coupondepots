#!/usr/bin/env python3
"""CouponDepots static site generator.

Run:  python3 build.py   ->  writes the full site into ./site
Add a vendor: append a dict to BRANDS (and its offers) and rebuild.
"""
import html, json, os, re, shutil, datetime
import markdown

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "site")
BASE = "https://coupondepots.info"
TODAY = "2026-10-19"
TODAY_HUMAN = "October 19, 2026"
SITE = "CouponDepots"
EMAIL = "admin@coupondepots.info"
PHONE = "(313) 729-1534"
PHONE_TEL = "+13137291534"
GSV = "f5EBxMKiRzq4QLfrGuWn0_knSgEWnAcJ2Pe1cTImSNU"
IMPACT = "https://utt.impactcdn.com/P-A7726983-53fa-48ae-8dc4-a8dc062c5b021.js"
SOCIAL = [
    ("LinkedIn", "https://www.linkedin.com/company/coupondepots"),
    ("Facebook", "https://www.facebook.com/coupondepots"),
    ("Instagram", "https://www.instagram.com/coupondepots"),
    ("X / Twitter", "https://twitter.com/coupondepots"),
]
SAME_AS = ["https://www.facebook.com/1358114907379644"] + [u for _, u in SOCIAL]

def awin(mid, aff, campaign=None):
    u = f"https://www.awin1.com/cread.php?awinmid={mid}&awinaffid={aff}"
    if campaign:
        u += "&campaign=" + campaign
    return u

# ---------------------------------------------------------------- vendors
# Affiliate links copied exactly from the live coupondepots.info pages.
BRANDS = [
    dict(slug="monvane", name="Monvane", cat="home", cat_label="Home & Furniture",
         img="local:monvane", link=awin(127859, 3067297),
         tagline="Modular boneless sofas built for everyday living",
         short="Modular boneless sofas with deep seating, high-resilience foam and recyclable materials."),
    dict(slug="simple-project", name="Simple Project US", cat="home", cat_label="Home Improvement",
         img="local:simple-project", link=awin(99013, 3067297),
         tagline="Macerating toilets and bathroom upgrades",
         short="Bathroom upgrades including the SNFLEX macerating toilet, with free shipping, 30-day returns and a 1-year warranty."),
    dict(slug="everblog", name="Everblog", cat="home", cat_label="Smart Home & Kitchen",
         img="local:everblog", link=awin(128579, 3075433),
         tagline="FridgeCal smart family calendar display",
         short="FridgeCal, a smart family display for kitchen planning, shared calendars and household organization."),
    dict(slug="zlike-hair", name="Zlike Hair", cat="beauty", cat_label="Beauty & Hair",
         img="local:zlike-hair", link=awin(102013, 3067297),
         tagline="Glueless lace wigs, extensions and textures",
         short="Wigs, extensions and style-focused hair, including glueless lace wigs and 300% density styles."),
    dict(slug="brkox", name="BRKOX", cat="hobbies", cat_label="Hobbies & Collectibles",
         img="local:brkox", link=awin(129093, 3067297, "BRKOX+US+Affiliate+Push"),
         tagline="Display cases and light kits for LEGO builds",
         short="Display cases and light kits that keep LEGO builds visible and protected from everyday dust."),
    dict(slug="yeloly", name="Yeloly", cat="fashion", cat_label="Lifestyle Apparel · 18+",
         img="1441986300917-64674bd600d8", link=awin(119761, 3075433), adult=True,
         tagline="Intimate apparel and adult lifestyle (18+)",
         short="Intimate apparel and adult lifestyle products for shoppers 18 and over."),
]
B = {b["slug"]: b for b in BRANDS}
for b in BRANDS:
    b["url"] = f"/store/{b['slug']}-coupon-code/"

# Offers shown on the one-page coupon board (home). type: code | deal
OFFERS = [
    dict(brand="monvane", type="code", code="MONAFF10", value="10%", unit="OFF",
         title="10% off for new customers",
         detail="No minimum spend. Can be combined with spend-based discounts. One use per customer.",
         label="Partner code"),
    dict(brand="monvane", type="code", code="AFF5OFF", value="5%", unit="OFF",
         title="5% off sitewide, unlimited use", img="local:monvane-u",
         detail="No minimum spend. Use it as often as you like.", label="Partner code"),
    dict(brand="simple-project", type="deal", value="41%", unit="OFF",
         title="SNFLEX macerating toilet: $659 (was $1,179)",
         detail="No code needed, discount auto-applies. Free shipping, 30-day returns, 1-year warranty. Price verified Sept 2026; confirm in cart.",
         label="No code needed"),
    dict(brand="monvane", type="deal", value="$139", unit="FROM",
         title="Oversized Sofa Bed: 3-in-1 sofa, lounger & sleeper", img="local:monvane-room",
         detail="Ideal for apartments and small spaces. Stack it with code MONAFF10 if you're a new customer.",
         label="Featured product"),
    dict(brand="everblog", type="deal", value="NEW", unit="",
         title="FridgeCal smart family calendar",
         detail="Shared calendars, reminders and kitchen planning in one fridge display. Check current pricing on Everblog.",
         label="Partner deal"),
    dict(brand="zlike-hair", type="deal", value="SHOP", unit="",
         title="Glueless lace wigs & 300% density styles",
         detail="Body Wave, Water Wave and layered looks. Check Zlike Hair for current promotions.",
         label="Partner deal"),
    dict(brand="brkox", type="deal", value="SHOP", unit="",
         title="LEGO display cases & light kits",
         detail="Dust protection and lighting for your favorite builds. See current BRKOX offers.",
         label="Partner deal"),
    dict(brand="yeloly", type="deal", value="18+", unit="",
         title="Intimate apparel & adult lifestyle",
         detail="Discreet shopping for adults. Check Yeloly for current offers and shipping terms.",
         label="Partner deal"),
]

# Merchant images: downloaded from each brand's own Shopify CDN by the GitHub
# Action (fetch_images.py) and served from /img/ as WebP. Keep in sync with images.json.
LOCAL_IMG = json.load(open(os.path.join(ROOT, "images.json"), encoding="utf-8"))
LOCAL_IMG = {d["name"]: d for d in LOCAL_IMG}
LOCAL_STEPS = [480, 800, 1200, 1600, 2000]

def local_widths(name):
    d = LOCAL_IMG[name]
    ws = [x for x in LOCAL_STEPS if x < d["w"]]
    return ws + [min(d["w"], 2000)]

def U(id_, w=1200, h=None, q=80):
    if id_.startswith("local:"):
        name = id_[6:]
        if w == 1200 and h == 630:
            return f"{BASE}/img/{name}-og.jpg"
        ws = local_widths(name)
        best = next((x for x in ws if x >= w), ws[-1])
        return f"/img/{name}-{best}.webp"
    s = f"https://images.unsplash.com/photo-{id_}?auto=format&fit=crop&w={w}&q={q}"
    if h:
        s += f"&h={h}"
    return s

def img(id_, alt, w=800, h=500, lazy=True, cls="", sizes="(max-width: 700px) 100vw, 400px", hero=False, pos=None):
    load = 'loading="lazy" decoding="async"' if lazy else 'fetchpriority="high" decoding="async"'
    if id_.startswith("local:"):
        name = id_[6:]
        d = LOCAL_IMG[name]
        srcset = ", ".join(f"/img/{name}-{x}.webp {x}w" for x in local_widths(name))
        style = f' style="object-position:{d.get("pos", "50% 50%")}"'
        return (f'<img class="{cls}" src="{U(id_, w)}" srcset="{srcset}" sizes="{sizes}" '
                f'width="{d["w"]}" height="{d["h"]}" alt="{html.escape(alt)}"{style} {load}>')
    widths = [640, 960, 1280, 1920, 2560] if hero else [480, 720, 960, 1280]
    ratio = h / w
    srcset = ", ".join(f"{html.escape(U(id_, x, int(x * ratio)))} {x}w" for x in widths)
    return (f'<img class="{cls}" src="{html.escape(U(id_, w, h))}" srcset="{srcset}" sizes="{sizes}" '
            f'width="{w}" height="{h}" alt="{html.escape(alt)}" {load}>')

def e(s):
    return html.escape(s, quote=True)

def aff_a(brand, text, cls="btn btn-gold", extra=""):
    b = B[brand]
    return (f'<a class="{cls}" href="{e(b["link"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" '
            f'data-brand="{b["slug"]}" {extra}>{text}</a>')

# ---------------------------------------------------------------- layout
ICON_TICKET = '<svg viewBox="0 0 24 24" aria-hidden="true" width="22" height="22"><path fill="currentColor" d="M3 7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2.2a2.8 2.8 0 0 0 0 5.6V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2.2a2.8 2.8 0 0 0 0-5.6V7Zm11 .5v1.6h1.6V7.5H14Zm0 3.7v1.6h1.6v-1.6H14Zm0 3.7v1.6h1.6v-1.6H14Z"/></svg>'
ARROW = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M13.2 5.3 19.9 12l-6.7 6.7-1.4-1.4 4.3-4.3H4v-2h12.1l-4.3-4.3 1.4-1.4Z"/></svg>'

NAV = [("Coupons", "/#deals"), ("Stores", "/#stores"), ("Guides", "/blog/"), ("How we verify", "/how-we-verify/")]

def header(active=""):
    links = "".join(f'<a href="{h}"{" aria-current=\"page\"" if active == t else ""}>{t}</a>' for t, h in NAV)
    return f'''<div class="disclosure-bar">Some links are affiliate links. We may earn a commission at no extra cost to you. <a href="/disclosure/">Learn more</a></div>
<header class="site-header">
  <div class="wrap nav-row">
    <a class="logo" href="/" aria-label="CouponDepots home"><span class="logo-mark">{ICON_TICKET}</span><span>Coupon<b>Depots</b></span></a>
    <nav class="main-nav" id="main-nav" aria-label="Main">{links}<a class="nav-cta" href="/contact/#partner">Partner with us</a></nav>
    <button class="nav-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="main-nav"><span></span><span></span></button>
  </div>
</header>'''

def footer():
    stores = "".join(f'<li><a href="{b["url"]}">{e(b["name"])} coupons</a></li>' for b in BRANDS)
    soc = "".join(f'<a href="{u}" target="_blank" rel="noopener noreferrer">{n}</a>' for n, u in SOCIAL)
    return f'''<footer class="site-footer">
  <div class="wrap footer-grid">
    <div class="footer-brand">
      <a class="logo logo-light" href="/"><span class="logo-mark">{ICON_TICKET}</span><span>Coupon<b>Depots</b></span></a>
      <p>Partner coupons and shopping guides from brands we work with directly through official affiliate networks.</p>
      <p class="small"><a href="mailto:{EMAIL}">{EMAIL}</a><br><a href="tel:{PHONE_TEL}">{PHONE}</a><br>Massachusetts, USA</p>
      <div class="socials">{soc}</div>
    </div>
    <div><h3>Stores</h3><ul>{stores}</ul></div>
    <div><h3>Guides</h3><ul><li><a href="/blog/">All shopping guides</a></li><li><a href="/blog/3-upgrades-save-money-2026/">Home &amp; beauty upgrades</a></li><li><a href="/blog/best-home-lifestyle-deals-may-2026/">Home &amp; lifestyle guide</a></li><li><a href="/blog/save-money-online-every-week/">Save money every week</a></li><li><a href="/blog/best-stores-online-coupons/">Best stores for coupons</a></li></ul></div>
    <div><h3>Company</h3><ul><li><a href="/about/">About</a></li><li><a href="/how-we-verify/">How we verify</a></li><li><a href="/contact/">Contact</a></li><li><a href="/contact/#submit">Submit a coupon</a></li><li><a href="/disclosure/">Affiliate disclosure</a></li><li><a href="/privacy/">Privacy</a></li><li><a href="/terms/">Terms</a></li></ul></div>
  </div>
  <div class="wrap footer-base"><span>&copy; <span data-year>2026</span> CouponDepots. All rights reserved.</span><span>Prices and promotions are set by merchants and can change. Always confirm at checkout.</span></div>
</footer>'''

ORG = {"@type": "Organization", "@id": f"{BASE}/#organization", "name": SITE, "url": f"{BASE}/",
       "logo": {"@type": "ImageObject", "url": f"{BASE}/assets/logo.png", "width": 512, "height": 512},
       "email": EMAIL, "telephone": "+1-313-729-1534",
       "address": {"@type": "PostalAddress", "addressRegion": "MA", "addressCountry": "US"},
       "sameAs": SAME_AS}
WEBSITE = {"@type": "WebSite", "@id": f"{BASE}/#website", "name": SITE, "url": f"{BASE}/",
           "publisher": {"@id": f"{BASE}/#organization"}, "inLanguage": "en-US",
           "potentialAction": {"@type": "SearchAction",
                               "target": {"@type": "EntryPoint", "urlTemplate": f"{BASE}/?q={{search_term_string}}#deals"},
                               "query-input": "required name=search_term_string"}}

def crumbs(items):
    return {"@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": i + 1, "name": n, "item": BASE + p} for i, (n, p) in enumerate(items)]}

def faq_schema(faqs):
    return {"@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": re.sub(r"<[^>]+>", "", a)}}
        for q, a in faqs]}

def faq_html(faqs, title="Frequently asked questions", eyebrow="Helpful answers"):
    items = "".join(f'<details class="faq"><summary>{e(q)}</summary><div class="faq-a"><p>{a}</p></div></details>' for q, a in faqs)
    return f'<section class="section" id="faq"><div class="wrap narrow"><p class="eyebrow">{eyebrow}</p><h2>{title}</h2><div class="faq-list">{items}</div></div></section>'

def page(path, title, desc, body, schema=None, og_img="1483985988355-763728e1935b", active="", og_type="website", extra_head=""):
    canon = BASE + path
    graph = [ORG, WEBSITE] + (schema or [])
    ld = json.dumps({"@context": "https://schema.org", "@graph": graph}, ensure_ascii=False, separators=(",", ":"))
    ogimg = U(og_img, 1200, 630)
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(title)}</title>
<meta name="description" content="{e(desc)}">
<link rel="canonical" href="{canon}">
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">
<meta name="google-site-verification" content="{GSV}">
<meta name="theme-color" content="#0b1020">
<meta property="og:site_name" content="{SITE}">
<meta property="og:type" content="{og_type}">
<meta property="og:title" content="{e(title)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:url" content="{canon}">
<meta property="og:image" content="{e(ogimg)}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{e(title)}">
<meta name="twitter:description" content="{e(desc)}">
<meta name="twitter:image" content="{e(ogimg)}">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/assets/logo.png">
<link rel="preconnect" href="https://images.unsplash.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap"></noscript>
<link rel="stylesheet" href="/assets/style.css?v=4">
<link rel="alternate" type="text/plain" href="/llms.txt" title="LLM summary">
{extra_head}<script type="application/ld+json">{ld}</script>
<script async src="{IMPACT}"></script>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
{header(active)}
<main id="main">
{body}
</main>
{footer()}
<script src="/assets/app.js?v=4" defer></script>
</body>
</html>
'''

def write(path, content):
    fp = os.path.join(OUT, path.lstrip("/"))
    if path.endswith("/"):
        fp = os.path.join(fp, "index.html")
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    with open(fp, "w", encoding="utf-8") as f:
        f.write(content)

SITEMAP = []
def add_sm(path, lastmod=TODAY, prio="0.7"):
    SITEMAP.append((path, lastmod, prio))

# ---------------------------------------------------------------- components
def offer_card(o):
    b = B[o["brand"]]
    adult = ' <span class="tag tag-adult">18+</span>' if b.get("adult") else ""
    if o["type"] == "code":
        cta = (f'<a class="btn btn-gold reveal" href="{e(b["link"])}" target="_blank" rel="sponsored nofollow noopener noreferrer" '
               f'data-code="{o["code"]}" aria-label="Show {b["name"]} code and open store"><span class="reveal-label">Show code</span>'
               f'<span class="reveal-peek" aria-hidden="true">{o["code"][-3:]}</span></a>')
        ctype = "code"
    else:
        cta = aff_a(o["brand"], f'Get deal {ARROW}')
        ctype = "deal"
    search = f'{b["name"]} {b["cat_label"]} {o["title"]} {o.get("code","")}'.lower()
    oimg = o.get("img", b["img"])
    media = img(oimg, LOCAL_IMG[oimg[6:]]["alt"] if oimg.startswith("local:") else alt_for(b), 800, 450, cls="", sizes="(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 380px")
    return f'''<article class="coupon" data-cat="{b["cat"]}" data-type="{ctype}" data-search="{e(search)}">
  <a class="coupon-media" href="{b["url"]}" tabindex="-1" aria-hidden="true">{media}<span class="coupon-badge"><strong>{o["value"]}</strong>{f'<span>{o["unit"]}</span>' if o["unit"] else ""}</span></a>
  <div class="coupon-body">
    <div class="coupon-top"><a class="coupon-brand" href="{b["url"]}">{e(b["name"])}</a><span class="tag">{e(o["label"])}</span>{adult}</div>
    <h3>{e(o["title"])}</h3>
    <p>{e(o["detail"])}</p>
    <div class="coupon-actions">{cta}<a class="link-more" href="{b["url"]}">{e(b["name"])} guide</a></div>
  </div>
</article>'''

def alt_for(b):
    if b["img"].startswith("local:"):
        return LOCAL_IMG[b["img"][6:]]["alt"]
    return b["tagline"]

def store_card(b):
    adult = '<span class="tag tag-adult">18+</span>' if b.get("adult") else ""
    n = sum(1 for o in OFFERS if o["brand"] == b["slug"])
    return f'''<a class="store-card" href="{b["url"]}">
  <div class="store-img">{img(b["img"], alt_for(b), 800, 500, sizes="(max-width: 600px) 100vw, (max-width: 1100px) 50vw, 380px")}</div>
  <div class="store-info"><div class="store-meta"><span>{e(b["cat_label"])}</span>{adult}</div>
  <h3>{e(b["name"])}</h3><p>{e(b["tagline"])}</p><span class="store-count">{n} offer{"s" if n != 1 else ""} {ARROW}</span></div>
</a>'''

# ---------------------------------------------------------------- HOME
HOME_FAQ = [
    ("What is CouponDepots?", "CouponDepots is a free coupon and shopping-guide site. Every offer on this page comes from a brand we partner with through an official affiliate network such as Awin, so codes and deals are sourced from the merchant, not scraped from other coupon sites."),
    ("Are the coupon codes on CouponDepots verified?", "Codes are supplied by the merchant through its affiliate program and labeled \"Partner code\". Prices marked \"verified\" were checked against the merchant's own site on the date shown. Merchants can change terms at any time, so always confirm the discount in your cart before paying."),
    ("How do I use a coupon code?", "Click <em>Show code</em>. The code is revealed and copied to your clipboard, and the store opens in a new tab. Add items to your cart and paste the code in the promo or discount field at checkout."),
    ("Which Monvane coupon codes work right now?", "Monvane's partner codes are <strong>MONAFF10</strong> (10% off for new customers, no minimum, one use per customer, stackable with spend-based discounts) and <strong>AFF5OFF</strong> (5% off, no minimum, unlimited use)."),
    ("Does CouponDepots earn money from these links?", "Yes. Some links are affiliate links, so we may earn a commission when you buy, at no extra cost to you. It never changes the price you pay. See our <a href=\"/disclosure/\">affiliate disclosure</a>."),
    ("Can my brand be listed on CouponDepots?", "Yes. We're adding new vendors regularly. <a href=\"/contact/#partner\">Contact our partnerships team</a> with your affiliate network details."),
]

def build_home():
    chips = [("all", "All offers"), ("code", "Codes"), ("home", "Home"), ("beauty", "Beauty & Hair"), ("hobbies", "Hobbies"), ("fashion", "Fashion 18+")]
    chip_html = "".join(f'<button class="chip{" is-active" if k == "all" else ""}" data-filter="{k}" aria-pressed="{"true" if k == "all" else "false"}">{t}</button>' for k, t in chips)
    cards = "\n".join(offer_card(o) for o in OFFERS)
    stores = "\n".join(store_card(b) for b in BRANDS)
    codes = sum(1 for o in OFFERS if o["type"] == "code")
    body = f'''
<section class="hero">
  <div class="hero-media">{img("1483985988355-763728e1935b", "Shopper carrying shopping bags", 1600, 900, lazy=False, cls="hero-img", sizes="100vw", hero=True)}</div>
  <div class="wrap hero-inner">
    <p class="eyebrow eyebrow-light">Partner coupons · Updated {TODAY_HUMAN}</p>
    <h1>Save More on <em>Everything</em> You Love</h1>
    <p class="hero-sub">Every coupon and deal, on one page. Sourced straight from the brands we partner with, clearly labeled and free to use.</p>
    <form class="hero-search" role="search" action="/#deals" onsubmit="return false">
      <label class="sr-only" for="q">Search coupons and stores</label>
      <input id="q" name="q" type="search" placeholder="Search stores, codes or products… e.g. Monvane" autocomplete="off">
      <button class="btn btn-gold" type="submit">Search</button>
    </form>
    <ul class="hero-stats">
      <li><strong>{len(BRANDS)}</strong> partner brands</li>
      <li><strong>{len(OFFERS)}</strong> live offers</li>
      <li><strong>{codes}</strong> partner codes</li>
      <li><strong>$0</strong> to use, always</li>
    </ul>
  </div>
</section>
<div class="partner-bar"><div class="wrap partner-row"><span>Featured partners</span>{"".join(f'<a href="{b["url"]}">{e(b["name"])}</a>' for b in BRANDS)}</div></div>

<section class="section section-deals" id="deals">
  <div class="wrap">
    <div class="section-head">
      <div><p class="eyebrow">All coupons &amp; deals</p><h2>Today's partner offers</h2></div>
      <p class="muted">Codes are supplied by merchants through official affiliate programs. Confirm the discount in your cart before you pay.</p>
    </div>
    <div class="filters" role="toolbar" aria-label="Filter offers">{chip_html}</div>
    <div class="coupon-grid" id="coupon-grid">
{cards}
    </div>
    <p class="empty" id="empty" hidden>No offers match that search. <button class="linklike" data-reset>Show all offers</button></p>
  </div>
</section>

<section class="section" id="stores">
  <div class="wrap">
    <div class="section-head"><div><p class="eyebrow">Partner stores</p><h2>Shop by store</h2></div><p class="muted">Each store has its own guide with current codes, how-to steps and answers to common questions.</p></div>
    <div class="store-grid">
{stores}
    </div>
  </div>
</section>

<section class="section section-dark" id="new-vendors">
  <div class="wrap partner-band">
    <div><p class="eyebrow eyebrow-light">Coming soon</p><h2>New vendors are joining CouponDepots</h2>
    <p>We're adding new brands every month. Want your store in front of deal-ready shoppers? Partner with us through Awin, Impact, CJ or ShareASale.</p></div>
    <div class="partner-actions"><a class="btn btn-gold" href="/contact/#partner">Become a partner</a><a class="btn btn-ghost" href="/contact/#submit">Submit a coupon</a></div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head"><div><p class="eyebrow">How it works</p><h2>Save in three steps</h2></div></div>
    <ol class="steps">
      <li><span>01</span><h3>Pick an offer</h3><p>Browse every partner coupon and deal above, or search by store or product.</p></li>
      <li><span>02</span><h3>Reveal &amp; copy</h3><p>Tap <em>Show code</em>. We copy it for you and open the store in a new tab.</p></li>
      <li><span>03</span><h3>Paste at checkout</h3><p>Apply the code in the store's promo field and confirm the discount before paying.</p></li>
    </ol>
    <p class="center"><a class="link-more" href="/how-we-verify/">How we source and check offers {ARROW}</a></p>
  </div>
</section>

<section class="section section-soft">
  <div class="wrap">
    <div class="section-head"><div><p class="eyebrow">Shopping guides</p><h2>Research before you buy</h2></div><a class="link-more" href="/blog/">All guides {ARROW}</a></div>
    <div class="post-grid">{"".join(post_card(p) for p in POSTS[:3])}</div>
  </div>
</section>

{faq_html(HOME_FAQ)}
'''
    schema = [
        {"@type": "WebPage", "@id": f"{BASE}/#webpage", "url": f"{BASE}/", "name": "CouponDepots: Save More Every Day",
         "isPartOf": {"@id": f"{BASE}/#website"}, "about": {"@id": f"{BASE}/#organization"},
         "datePublished": "2026-08-31", "dateModified": TODAY,
         "primaryImageOfPage": {"@type": "ImageObject", "url": U("1483985988355-763728e1935b", 1200, 630)}},
        {"@type": "ItemList", "name": "CouponDepots partner stores", "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "name": f"{b['name']} coupons", "url": BASE + b["url"]} for i, b in enumerate(BRANDS)]},
        faq_schema(HOME_FAQ),
    ]
    write("/", page("/", "CouponDepots: Save More Every Day | Partner Coupons & Deals",
                    "Every CouponDepots coupon and deal on one page: Monvane codes MONAFF10 & AFF5OFF, Simple Project US, Everblog FridgeCal, Zlike Hair, BRKOX and more. Free to use.",
                    body, schema, active="Coupons"))
    add_sm("/", TODAY, "1.0")

# ---------------------------------------------------------------- STORE PAGES
STORE_CONTENT = {
"monvane": dict(
    title="Monvane Coupon Code: 10% Off with MONAFF10 | CouponDepots",
    desc="Monvane coupon codes: MONAFF10 for 10% off your first order and AFF5OFF for 5% off, no minimum spend. Modular boneless sofas from $139.",
    h1="Monvane Coupon Code & Promo Codes",
    intro="Monvane makes modular boneless sofas designed to adapt to everyday living, with deep seating, high-resilience foam, and recyclable materials.",
    body='''<h2>Featured Monvane product</h2>
<p><strong>Oversized Sofa Bed, from $139.</strong> A versatile 3-in-1 sofa, lounger and sleeper, ideal for apartments and small spaces.</p>
<h2>How to apply a Monvane coupon</h2>
<ol class="howto"><li><strong>Visit Monvane.</strong> Open Monvane through the sponsored link on this page to browse current furniture options.</li>
<li><strong>Check the current promotion details.</strong> Review the offer terms shown by Monvane before adding an item to your cart.</li>
<li><strong>Enter your code.</strong> Paste MONAFF10 (new customers) or AFF5OFF at checkout exactly as shown and confirm the discount before completing your order.</li></ol>
<h2>Why choose a Monvane modular sofa</h2>
<p>Modular seating can be rearranged as your room, routine, or household changes. Instead of committing to one fixed sofa silhouette, you can build a compact chaise, an L-shape, a conversation layout or a longer lounge setup, then reconfigure later.</p>
<p>Explore the product page for current material, comfort, delivery, and warranty information before purchase. Measure your wall length and walkway clearance first. Our <a href="/blog/best-home-lifestyle-deals-may-2026/">home &amp; lifestyle guide</a> has a full modular-sofa planning checklist.</p>''',
    faqs=[("Does CouponDepots have a working Monvane coupon code?", "Yes. MONAFF10 gives new customers 10% off with no minimum spend (one use per customer, combinable with spend-based discounts). AFF5OFF gives 5% off with no minimum and unlimited use."),
          ("Can I combine Monvane codes?", "MONAFF10 can be combined with Monvane's spend-based discounts. Checkout normally accepts one promo code at a time, so new customers will usually save most with MONAFF10."),
          ("Where can I find current Monvane offers?", "On this page and on Monvane's official site. Review the terms shown at checkout before you pay."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission when you buy through our sponsored link, at no extra cost to you.")]),
"simple-project": dict(
    title="Simple Project US Deals: SNFLEX Toilet $659, No Code | CouponDepots",
    desc="Simple Project US deal: SNFLEX macerating toilet listed at $659 (was $1,179), no code needed, with free shipping, 30-day returns and a 1-year warranty.",
    h1="Simple Project US Deals & Shopping Guide",
    intro="Simple Project US sells bathroom upgrades including the SNFLEX macerating toilet, an upflush option for basements and rooms where standard drainage is difficult.",
    body='''<h2>The verified SNFLEX offer</h2>
<p>Simple Project US listed the SNFLEX Macerating Toilet at <strong>$659, down from $1,179</strong>, a <strong>41% reduction</strong> from the displayed regular price, marked <strong>No Code Needed: Discount Auto-Applies</strong>. Official homepage evidence also supported free shipping, a 30-day return policy, and a one-year warranty. Price verified September 2026; confirm the final cart total before paying.</p>
<h2>What to check before buying a macerating toilet</h2>
<ul><li>Your existing plumbing layout and local code requirements. Consider a qualified installer.</li>
<li>Rough-in dimensions, electrical needs, pump capacity, noise expectations and what's in the box.</li>
<li>The complete delivered price, free-shipping eligibility for your address, and return conditions before installation.</li></ul>
<h2>How to get the deal</h2>
<ol class="howto"><li><strong>Open Simple Project US</strong> through the sponsored link on this page.</li>
<li><strong>Add the SNFLEX toilet</strong> (or the product you need) to your cart.</li>
<li><strong>Confirm the price auto-applied</strong>. No code is needed. Review shipping, returns and warranty, then check out.</li></ol>
<p>Read the full comparison in our <a href="/blog/3-upgrades-save-money-2026/">home &amp; beauty upgrades guide</a>.</p>''',
    faqs=[("Does the SNFLEX discount need a coupon code?", "No. The listed SNFLEX sale price is marked as discount auto-applies. Check that the cart shows the price before checkout."),
          ("Does Simple Project US offer free shipping?", "Official homepage evidence listed free shipping for the covered offer. Review checkout terms for your order and delivery location."),
          ("What is a macerating toilet?", "A macerating (upflush) toilet breaks down waste and pumps it through a smaller discharge pipe, which can suit basements and rooms where gravity drainage is difficult."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission when you buy through our sponsored link, at no extra cost to you.")]),
"everblog": dict(
    title="Everblog FridgeCal Coupons & Current Offers | CouponDepots",
    desc="Shop Everblog FridgeCal, the smart family calendar display for your fridge. See current Everblog offers, how to apply a code and what to check before buying.",
    h1="Everblog FridgeCal Guide & Current Offers",
    intro="Everblog offers FridgeCal, a smart family display designed for kitchen planning and household organization, with shared calendars, reminders and household planning in one place.",
    body='''<div class="callout"><strong>Offer status:</strong> We don't currently have an Everblog coupon code, product price, bundle price or sale terms confirmed by official merchant evidence. Review the Everblog site for current availability, eligibility and checkout terms.</div>
<h2>Why explore Everblog FridgeCal?</h2>
<div class="feature-grid"><div><h3>Household planning</h3><p>Review Everblog's current tools for coordinating a busy household.</p></div>
<div><h3>Calendar connectivity</h3><p>Check current calendar connection options and setup requirements directly with the merchant.</p></div>
<div><h3>Kitchen organization</h3><p>Explore product information for planning meals and home routines.</p></div>
<div><h3>Product accessories</h3><p>Review compatible accessories and included features on the official product pages.</p></div></div>
<h2>How to apply an Everblog coupon</h2>
<ol class="howto"><li><strong>Visit Everblog.</strong> Use the sponsored merchant link to explore current products.</li>
<li><strong>Review eligibility.</strong> Confirm product details, pricing, and any active promotion requirements before checkout.</li>
<li><strong>Apply a confirmed code.</strong> If Everblog publishes an eligible code, enter it exactly as directed at checkout.</li></ol>
<p>Planning tips for mounting, compatibility and family routines are in our <a href="/blog/best-home-lifestyle-deals-may-2026/">home &amp; lifestyle guide</a>.</p>''',
    faqs=[("Does CouponDepots have a verified Everblog coupon code?", "Not right now. We only publish Everblog codes when supported by official merchant evidence. Check the Everblog site for current promotions."),
          ("What is FridgeCal?", "FridgeCal is Everblog's smart family calendar display that attaches to a refrigerator for shared scheduling, reminders and kitchen organization."),
          ("Can FridgeCal connect to calendars?", "Everblog positions FridgeCal around shared calendars. Check the official product page for the calendar services currently supported and setup requirements."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission when you buy through our sponsored link, at no extra cost to you.")]),
"zlike-hair": dict(
    title="Zlike Hair Coupons & Shopping Guide: Glueless Wigs | CouponDepots",
    desc="Shop Zlike Hair glueless lace wigs, 300% density styles, Body Wave and Water Wave textures. Wig-buying checklist, coupon guidance and FAQs.",
    h1="Zlike Hair: Styles & Shopping Guide",
    intro="Explore Zlike Hair product categories and coupon guidance. Zlike Hair is a hair brand whose catalog is associated with wigs, extensions, and style-focused hair options.",
    body='''<div class="callout"><strong>Offer status:</strong> Promotional offers and coupon codes are not currently listed for Zlike Hair. Check the brand's official site for current promotion terms before shopping.</div>
<h2>About Zlike Hair</h2>
<p>Shoppers often compare construction, texture, length, cap fit, color, and maintenance needs before choosing a piece. Product names and availability can change, so it is useful to review the current listing details directly with the brand before making a purchase.</p>
<p>For shoppers researching a fuller look, 300% Density is a term that may appear in product descriptions. Density is one of several details to weigh alongside cap size, lace area, hairline customization, and the amount of styling desired. Glueless Lace Wigs may appeal to people looking for an installation approach that does not rely on adhesive, but the right choice depends on fit, routine, and the care instructions for the specific product.</p>
<p>Style research can also help narrow the search. Butterfly Haircuts are known for layered movement, while Body Wave and Water Wave describe different texture looks. Consider how each texture may respond to daily styling, washing, detangling, and humidity.</p>
<h2>Popular product categories to explore</h2>
<div class="feature-grid"><div><h3>Glueless lace wigs</h3><p>Explore cap construction, lace details, and fit guidance.</p></div>
<div><h3>300% density styles</h3><p>Compare fullness, length, and daily styling needs.</p></div>
<div><h3>Body Wave textures</h3><p>Review texture care and styling inspiration.</p></div>
<div><h3>Water Wave textures</h3><p>Consider curl definition and maintenance guidance.</p></div>
<div><h3>Layered haircut looks</h3><p>Browse styles inspired by Butterfly Haircuts.</p></div>
<div><h3>Hair care essentials</h3><p>Check brand guidance for washing, storage, and upkeep.</p></div></div>
<h2>How to apply a coupon</h2>
<ol class="howto"><li><strong>Find a current offer</strong> on the brand's official channels.</li>
<li><strong>Review the terms:</strong> eligibility, exclusions, dates and minimum-purchase requirements.</li>
<li><strong>Apply at checkout</strong> only when the terms match your order.</li></ol>
<p>More on density and textures in our <a href="/blog/3-upgrades-save-money-2026/">home &amp; beauty upgrades guide</a>.</p>''',
    faqs=[("Are there active Zlike Hair coupon codes on this page?", "Not currently. We don't list Zlike Hair codes until they're confirmed. Check Zlike Hair's official site for live promotions."),
          ("Where should I verify a Zlike Hair offer?", "On Zlike Hair's official website and in your cart at checkout, where the final terms and price are shown."),
          ("What should I compare before choosing a wig?", "Cap size and construction, lace area, density, texture, length, color, care requirements and the current return policy."),
          ("What does glueless mean for a wig?", "A glueless wig is designed to be worn without adhesive, typically using adjustable straps, combs, an elastic band or pre-cut lace. Fit varies by item.")]),
"brkox": dict(
    title="BRKOX Coupons & Deals: LEGO Display Cases | CouponDepots",
    desc="Shop BRKOX display cases and light kits for LEGO builds through CouponDepots. How to choose the right case size, plus current offer status and FAQs.",
    h1="Shop BRKOX through CouponDepots",
    intro="Visit BRKOX through our sponsored partner link. BRKOX offers display options for LEGO builds, cases that keep models visible while reducing everyday dust exposure.",
    body='''<div class="callout"><strong>Offer status:</strong> We do not list a coupon code, discount amount, product availability, or offer expiration here because none has been confirmed for publication. See current offers directly on BRKOX.</div>
<h2>About this merchant link</h2>
<p>CouponDepots shares partner links when a merchant makes them available through an affiliate network. This page lists the BRKOX merchant destination confirmed for CouponDepots.</p>
<h2>How to choose a display case</h2>
<ul><li><strong>Measure the model and the shelf.</strong> Note the assembled width, depth and height, then add clearance so fragile pieces don't catch.</li>
<li><strong>Check materials and assembly.</strong> Review panel thickness, assembly steps and cleaning guidance; clear acrylic needs careful handling.</li>
<li><strong>Plan any light kit.</strong> Confirm compatibility with your exact set, wire routing, power source and whether disassembly is required.</li></ul>
<h2>How to use this link</h2>
<ol class="howto"><li><strong>Select Visit BRKOX.</strong> Use the sponsored button on this page to open the merchant's website.</li>
<li><strong>Review the merchant's current offers.</strong> See the latest products, pricing, shipping, and promotions directly on BRKOX.</li>
<li><strong>Complete your purchase with the merchant.</strong> Any purchase is completed securely on the merchant's own website.</li></ol>''',
    faqs=[("Does CouponDepots have a BRKOX coupon code?", "Not right now. No BRKOX code has been confirmed for publication. Check BRKOX's site for current promotions."),
          ("What does BRKOX sell?", "BRKOX offers display cases and light kits designed for LEGO builds."),
          ("How do I pick the right display case size?", "Measure the assembled model's width, depth and height, add clearance, and check the case fits your shelf or cabinet."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission from qualifying purchases made through this sponsored link. It does not change the price you pay.")]),
"yeloly": dict(
    title="Yeloly Coupons & Shopping Guide (18+) | CouponDepots",
    desc="Yeloly shopping guide for adults: intimate apparel and adult lifestyle products. Current offer status, how to use a promo code and discreet-shopping tips.",
    h1="Yeloly Shopping Guide & Current Offers",
    intro="Yeloly is an intimate apparel and adult lifestyle merchant. Visit the official Yeloly site through CouponDepots to review current products, eligibility details, and any offers available directly from the merchant.",
    body='''<div class="callout callout-warn"><strong>18+ only.</strong> This page and the merchant it links to are intended for adults.</div>
<div class="callout"><strong>Offer status:</strong> We do not currently have a Yeloly coupon code or free-shipping threshold confirmed by official merchant evidence. Check the merchant site for current availability, exclusions, and terms.</div>
<h2>Shopping considerations</h2>
<div class="feature-grid"><div><h3>Check current offers</h3><p>Review the official Yeloly site for any active promotion details and eligibility requirements.</p></div>
<div><h3>Review delivery terms</h3><p>Confirm shipping availability, costs, and any thresholds directly with Yeloly before checkout.</p></div>
<div><h3>Read product information</h3><p>Review product descriptions, sizing information, and care guidance on the merchant site.</p></div></div>
<h2>How to use a Yeloly promo code</h2>
<ol class="howto"><li><strong>Start at the merchant site.</strong> Visit Yeloly using the sponsored link on this page.</li>
<li><strong>Add eligible items.</strong> Choose items and continue to checkout when you are ready.</li>
<li><strong>Apply a confirmed code.</strong> If Yeloly provides an eligible code, enter it exactly as instructed at checkout.</li></ol>''',
    faqs=[("Does CouponDepots have a verified Yeloly coupon code?", "Not currently. We only publish Yeloly codes when supported by official merchant evidence."),
          ("Does Yeloly offer free shipping?", "We haven't confirmed a free-shipping threshold. Check delivery options and costs on Yeloly's checkout page."),
          ("Is this page intended for adults?", "Yes. Yeloly sells intimate apparel and adult lifestyle products, and this page is intended for shoppers 18 and over."),
          ("Does CouponDepots earn from this link?", "Yes. We may earn a commission when you buy through our sponsored link, at no extra cost to you.")]),
}

def build_store(b):
    c = STORE_CONTENT[b["slug"]]
    offers = [o for o in OFFERS if o["brand"] == b["slug"]]
    adult = '<span class="tag tag-adult">18+</span>' if b.get("adult") else ""
    others = [x for x in BRANDS if x["slug"] != b["slug"]][:3]
    body = f'''
<section class="store-hero">
  <div class="store-hero-media">{img(b["img"], alt_for(b), 1600, 700, lazy=False, cls="hero-img", sizes="100vw", hero=True)}</div>
  <div class="wrap store-hero-inner">
    <nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><a href="/#stores">Stores</a><span>/</span><span aria-current="page">{e(b["name"])}</span></nav>
    <p class="eyebrow eyebrow-light">{e(b["cat_label"])} · Sponsored merchant {adult}</p>
    <h1>{e(c["h1"])}</h1>
    <p class="hero-sub">{e(c["intro"])}</p>
    <div class="hero-actions">{aff_a(b["slug"], f"Visit {e(b['name'])} {ARROW}")}<span class="updated">Updated {TODAY_HUMAN}</span></div>
  </div>
</section>
<section class="section section-tight">
  <div class="wrap">
    <div class="section-head"><div><p class="eyebrow">{e(b["name"])} coupons</p><h2>Current {e(b["name"])} offers</h2></div></div>
    <div class="coupon-grid coupon-grid-2">{"".join(offer_card(o) for o in offers)}</div>
    <p class="fine">We may earn a commission when you use our sponsored {e(b["name"])} link, at no extra cost to you. <a href="/disclosure/">Affiliate disclosure</a>.</p>
  </div>
</section>
<section class="section section-tight">
  <div class="wrap content-grid">
    <article class="prose">{c["body"]}</article>
    <aside class="side">
      <div class="side-card"><p class="eyebrow">Quick facts</p><dl><dt>Store</dt><dd>{e(b["name"])}</dd><dt>Category</dt><dd>{e(b["cat_label"])}</dd><dt>Offers</dt><dd>{len(offers)}</dd><dt>Network</dt><dd>Awin</dd><dt>Last checked</dt><dd>{TODAY_HUMAN}</dd></dl>{aff_a(b["slug"], f"Shop {e(b['name'])}", "btn btn-dark btn-block")}</div>
    </aside>
  </div>
</section>
{faq_html(c["faqs"], f"{b['name']} coupon questions")}
<section class="section section-soft"><div class="wrap"><div class="section-head"><div><p class="eyebrow">Keep saving</p><h2>More partner stores</h2></div><a class="link-more" href="/#deals">All coupons {ARROW}</a></div>
<div class="store-grid store-grid-3">{"".join(store_card(x) for x in others)}</div></div></section>
'''
    schema = [
        {"@type": "WebPage", "@id": f"{BASE}{b['url']}#webpage", "url": BASE + b["url"], "name": c["title"],
         "description": c["desc"], "isPartOf": {"@id": f"{BASE}/#website"}, "dateModified": TODAY,
         "about": {"@type": "Brand", "name": b["name"]},
         "primaryImageOfPage": {"@type": "ImageObject", "url": U(b["img"], 1200, 630)}},
        crumbs([("Home", "/"), ("Stores", "/#stores"), (b["name"], b["url"])]),
        faq_schema(c["faqs"]),
    ]
    write(b["url"], page(b["url"], c["title"], c["desc"], body, schema, og_img=b["img"], active="Stores"))
    add_sm(b["url"], TODAY, "0.8")

# ---------------------------------------------------------------- BLOG
POSTS = []
def load_posts():
    d = os.path.join(ROOT, "content", "posts")
    for fn in sorted(os.listdir(d)):
        raw = open(os.path.join(d, fn), encoding="utf-8").read()
        _, fm, md = raw.split("---", 2)
        meta = {}
        for line in fm.strip().splitlines():
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip()
        meta["slug"] = fn[:-3]
        meta["md"] = md.strip()
        meta["url"] = f"/blog/{meta['slug']}/"
        POSTS.append(meta)
    POSTS.sort(key=lambda p: p["date"], reverse=True)

def human_date(d):
    return datetime.date.fromisoformat(d).strftime("%B %-d, %Y")

def post_card(p):
    return f'''<a class="post-card" href="{p["url"]}"><div class="post-img">{img(p["image"], p["title"], 640, 400)}</div>
<div class="post-info"><p class="post-meta">{e(p["category"])} · {human_date(p["date"])}</p><h3>{e(p["title"])}</h3><p>{e(p["excerpt"])}</p></div></a>'''

def render_md(md):
    def cta(m):
        slug, text = m.group(1), m.group(2)
        b = B[slug]
        return (f'<div class="cta-box"><div><strong>{e(b["name"])}</strong><span>{e(b["tagline"])}</span></div>'
                f'{aff_a(slug, e(text) + " " + ARROW)}</div>')
    md = re.sub(r"\{\{CTA:([\w-]+):(.+?)\}\}", cta, md)
    md = re.sub(r"\{\{LINK:([\w-]+):(.+?)\}\}", lambda m: aff_a(m.group(1), e(m.group(2)), "inline-aff"), md)
    h = markdown.markdown(md, extensions=["extra", "sane_lists"])
    h = h.replace("<table>", '<table>')
    return h

def extract_faq(md):
    m = re.search(r"^## (Frequently asked questions|People also ask)\s*$(.*?)(?=^## |\Z)", md, re.S | re.M)
    if not m:
        return []
    out = []
    for q, a in re.findall(r"^### (.+?)\s*\n+(.+?)(?=\n+### |\Z)", m.group(2), re.S | re.M):
        out.append((q.strip(), markdown.markdown(a.strip())[3:-4]))
    return out

def toc(md):
    hs = re.findall(r"^## (.+)$", md, re.M)
    return hs

def slugify(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")

def build_post(p):
    body_html = render_md(p["md"])
    heads = toc(p["md"])
    for h_ in heads:
        rendered = markdown.markdown("## " + h_)[4:-5]
        body_html = body_html.replace(f"<h2>{rendered}</h2>", f'<h2 id="{slugify(h_)}">{rendered}</h2>', 1)
    toc_html = "".join(f'<li><a href="#{slugify(h_)}">{e(re.sub(r"[*_]", "", h_))}</a></li>' for h_ in heads)
    faqs = extract_faq(p["md"])
    words = len(re.findall(r"\w+", p["md"]))
    mins = max(1, round(words / 230))
    brands = [s.strip() for s in p.get("brands", "").split(",") if s.strip()]
    related = "".join(store_card(B[s]) for s in brands)
    rel_html = f'<section class="section section-soft"><div class="wrap"><div class="section-head"><div><p class="eyebrow">Stores in this guide</p><h2>Shop the brands</h2></div></div><div class="store-grid store-grid-3">{related}</div></div></section>' if related else ""
    more = "".join(post_card(x) for x in POSTS if x["slug"] != p["slug"])[:]
    body = f'''
<article>
<header class="post-hero">
  <div class="post-hero-media">{img(p["image"], p["title"], 1600, 700, lazy=False, cls="hero-img", sizes="100vw", hero=True)}</div>
  <div class="wrap narrow post-hero-inner">
    <nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><a href="/blog/">Guides</a><span>/</span><span aria-current="page">{e(p["category"])}</span></nav>
    <p class="eyebrow eyebrow-light">{e(p["category"])}</p>
    <h1>{e(p["title"])}</h1>
    <p class="post-byline">By CouponDepots Editorial Team · Published {human_date(p["date"])} · Updated {TODAY_HUMAN} · {mins} min read</p>
  </div>
</header>
<div class="wrap content-grid post-layout">
  <div class="prose">
    <p class="summary"><strong>Summary:</strong> {e(p["excerpt"])}</p>
    {body_html}
  </div>
  <aside class="side"><div class="side-card sticky"><p class="eyebrow">In this guide</p><ol class="toc">{toc_html}</ol><a class="btn btn-dark btn-block" href="/#deals">See all coupons</a></div></aside>
</div>
</article>
{rel_html}
<section class="section"><div class="wrap"><div class="section-head"><div><p class="eyebrow">Keep reading</p><h2>More shopping guides</h2></div></div><div class="post-grid">{more}</div></div></section>
'''
    schema = [
        {"@type": "BlogPosting", "@id": f"{BASE}{p['url']}#article", "headline": p["title"], "description": p["description"],
         "image": U(p["image"], 1200, 630), "datePublished": p["date"], "dateModified": TODAY,
         "author": {"@type": "Organization", "name": "CouponDepots Editorial Team", "url": f"{BASE}/about/"},
         "publisher": {"@id": f"{BASE}/#organization"}, "mainEntityOfPage": BASE + p["url"],
         "articleSection": p["category"], "wordCount": words, "inLanguage": "en-US"},
        crumbs([("Home", "/"), ("Guides", "/blog/"), (p["title"], p["url"])]),
    ]
    if faqs:
        schema.append(faq_schema(faqs))
    write(p["url"], page(p["url"], p["seo_title"], p["description"], body, schema, og_img=p["image"], active="Guides", og_type="article"))
    add_sm(p["url"], TODAY, "0.7")

def build_blog_index():
    body = f'''
<section class="page-hero"><div class="wrap narrow"><p class="eyebrow">Shopping guides</p><h1>The CouponDepots Blog</h1><p class="lead">Evidence-based buying guides, savings systems and store breakdowns. We only state prices and codes we can verify.</p></div></section>
<section class="section section-tight"><div class="wrap"><div class="post-grid">{"".join(post_card(p) for p in POSTS)}</div></div></section>'''
    schema = [{"@type": "CollectionPage", "@id": f"{BASE}/blog/#webpage", "url": f"{BASE}/blog/", "name": "The CouponDepots Blog",
               "isPartOf": {"@id": f"{BASE}/#website"}, "hasPart": [{"@type": "BlogPosting", "headline": p["title"], "url": BASE + p["url"]} for p in POSTS]},
              crumbs([("Home", "/"), ("Guides", "/blog/")])]
    write("/blog/", page("/blog/", "Shopping Guides & Savings Tips | CouponDepots Blog",
                         "Shopping guides, savings tips and store breakdowns from CouponDepots: home upgrades, modular sofas, wigs, LEGO display cases and how to save every week.",
                         body, schema, og_img="1556742049-0cfed4f6a45d", active="Guides"))
    add_sm("/blog/", TODAY, "0.8")

# ---------------------------------------------------------------- INFO PAGES
def simple_page(path, title, desc, h1, lead, inner, eyebrow="", faqs=None, img_id=None, active=""):
    faq_block = faq_html(faqs) if faqs else ""
    body = f'''
<section class="page-hero"><div class="wrap narrow"><nav class="crumbs crumbs-dark" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><span aria-current="page">{e(h1)}</span></nav>{f'<p class="eyebrow">{eyebrow}</p>' if eyebrow else ''}<h1>{e(h1)}</h1><p class="lead">{lead}</p></div></section>
<section class="section section-tight"><div class="wrap narrow prose">{inner}</div></section>
{faq_block}'''
    schema = [{"@type": "WebPage", "@id": f"{BASE}{path}#webpage", "url": BASE + path, "name": title, "description": desc,
               "isPartOf": {"@id": f"{BASE}/#website"}, "dateModified": TODAY},
              crumbs([("Home", "/"), (h1, path)])]
    if faqs:
        schema.append(faq_schema(faqs))
    write(path, page(path, title, desc, body, schema, og_img=img_id or "1483985988355-763728e1935b", active=active))
    add_sm(path, TODAY, "0.5")

VERIFY_FAQ = [
    ("What does a \"Partner code\" label mean?", "The code was supplied by the merchant through its affiliate program for CouponDepots shoppers. We publish the merchant's stated terms with it."),
    ("What does \"No code needed\" mean?", "The discount applies automatically on the merchant's site, for example a sale price shown in the cart. You don't need to enter anything at checkout."),
    ("What happens when a coupon stops working?", "Tell us via the contact page or email. We review reports and remove or update broken offers as soon as we confirm the problem."),
    ("Does CouponDepots earn money from these deals?", "Yes. Some links are affiliate links. We may earn a commission when you buy, at no extra cost to you. Commission never decides whether an offer is accurate. See our <a href=\"/disclosure/\">affiliate disclosure</a>."),
    ("Can I submit a deal I found?", "Yes. Use the <a href=\"/contact/#submit\">submit a coupon</a> form. We check every submission against the merchant before publishing it."),
]

def build_info():
    simple_page("/how-we-verify/", "How We Verify Coupons | CouponDepots",
        "How CouponDepots sources, labels and checks coupons: official affiliate networks, merchant-supplied codes, price checks against the merchant's site, and fast removal of broken offers.",
        "How We Verify Coupons",
        "Every offer on CouponDepots is sourced from the merchant or its official affiliate network and clearly labeled, so you know exactly what you're getting.",
        f'''<div class="verify-steps">
<div><span>01</span><h3>Source confirmation</h3><p>Offers come from the retailer's own website, its official newsletter, or a verified affiliate network such as Awin, Impact, CJ or ShareASale. We never copy codes from other coupon aggregators.</p></div>
<div><span>02</span><h3>Evidence check</h3><p>Before publishing, we compare the code, price or promotion against the merchant's own site and terms. If we can't confirm an offer, we don't list a code, and the store page says so.</p></div>
<div><span>03</span><h3>Clear labels</h3><p>Every card says what it is: <strong>Partner code</strong>, <strong>No code needed</strong>, <strong>Featured product</strong> or <strong>Partner deal</strong>. Verified prices show the month they were checked.</p></div>
<div><span>04</span><h3>Ongoing review</h3><p>We re-check listed offers on a regular schedule and act on shopper reports. Expired or broken offers are removed or corrected once confirmed.</p></div>
</div>
<h2>Why we don't list codes we can't confirm</h2>
<p>Many coupon sites pad their pages with expired or invented codes. That wastes your time at checkout. CouponDepots would rather show fewer, real offers and link you straight to the merchant than promise savings that don't exist.</p>
<p>Spotted a problem? <a href="/contact/">Let us know</a> and we'll look into it.</p>''',
        eyebrow="Our process", faqs=VERIFY_FAQ, img_id="1472851294608-062f824d29cc", active="How we verify")

    simple_page("/about/", "About CouponDepots | Partner Coupons & Shopping Guides",
        "CouponDepots is a free coupon and shopping-guide site based in Massachusetts, featuring partner codes and evidence-based buying guides from brands we work with directly.",
        "About CouponDepots",
        "We're on a mission to make saving money effortless, with real offers from real partners and nothing padded.",
        f'''<h2>Our mission</h2>
<p>CouponDepots was built with one goal in mind: make saving money effortless. We work directly with brands through official affiliate networks to bring you working coupon codes, verified deals and honest shopping guides, all on one page.</p>
<h2>Why shoppers trust us</h2>
<div class="feature-grid"><div><h3>Sourced from merchants</h3><p>Codes come from brands and their affiliate programs, not scraped from other coupon sites.</p></div>
<div><h3>Clearly labeled</h3><p>Every offer says what it is and when it was checked. If we can't confirm a code, we say so.</p></div>
<div><h3>Free forever</h3><p>CouponDepots is completely free. No subscriptions, no hidden fees, just savings.</p></div>
<div><h3>Growing every month</h3><p>New partner brands join regularly. <a href="/contact/#partner">Want yours listed?</a></p></div></div>
<h2>Built by shoppers, for shoppers</h2>
<p>We're a small Massachusetts-based team of deal hunters and editors. We write guides that help you compare products before you buy, and we disclose every sponsored relationship.</p>
<p><a class="btn btn-gold" href="/#deals">Browse all coupons</a></p>''',
        eyebrow="Who we are", img_id="1556742049-0cfed4f6a45d")

    simple_page("/disclosure/", "Affiliate Disclosure | CouponDepots",
        "How CouponDepots earns revenue through affiliate programs like Awin, Impact, CJ and ShareASale, and how we keep our listings independent. FTC-compliant disclosure.",
        "Affiliate Disclosure",
        "We believe in full transparency about how CouponDepots works and how we earn revenue.",
        '''<div class="callout"><strong>The short version:</strong> CouponDepots earns commissions from affiliate programs when you click certain links and make purchases. This never costs you anything extra. Our goal is to save you money.</div>
<h2>How we earn revenue</h2>
<p>CouponDepots participates in affiliate marketing programs, which may include:</p>
<ul><li>Awin</li><li>Impact.com</li><li>Commission Junction (CJ Affiliate)</li><li>ShareASale</li><li>Amazon Associates</li><li>Individual retailer affiliate programs</li></ul>
<p>When you click a link on CouponDepots and subsequently make a purchase, we may receive a commission from the retailer. The commission is paid by the retailer, not by you. You pay the same price (or less, with our coupons) as you would going directly to the store.</p>
<h2>Our editorial independence</h2>
<p>Affiliate relationships do not decide whether an offer is accurate. We only publish codes and prices we can support with merchant evidence, and we label sponsored links clearly. We will never promote a deal solely because it pays a higher commission.</p>
<h2>Link tracking</h2>
<p>Outbound merchant links on CouponDepots go through the merchant's affiliate network (for example awin1.com) so the merchant can attribute your visit. These redirects are instant and do not affect the price you pay. Sponsored links are marked with <code>rel="sponsored"</code>.</p>
<h2>FTC compliance</h2>
<p>In accordance with the Federal Trade Commission's guidelines on endorsements and testimonials (16 CFR Part 255), CouponDepots discloses its material connections to advertisers and affiliate networks on this page and on relevant pages throughout the site.</p>
<p class="fine">Last updated: October 19, 2026</p>
<p>Questions about this disclosure? <a href="/contact/">Get in touch</a>.</p>''', eyebrow="Transparency")

    simple_page("/contact/", "Contact CouponDepots | Partnerships & Support",
        "Contact CouponDepots: report a broken coupon, submit a deal, or partner with us. Email admin@coupondepots.info or call (313) 729-1534, Mon–Fri 9 AM–6 PM ET.",
        "Contact Us",
        "Have a question, found a broken coupon, or want to partner with us? We'd love to hear from you.",
        f'''<div class="contact-grid">
<div class="contact-card"><h3>Email us</h3><p><a href="mailto:{EMAIL}">{EMAIL}</a></p><p class="fine">We typically respond within 24 hours.</p></div>
<div class="contact-card"><h3>Call us</h3><p><a href="tel:{PHONE_TEL}">{PHONE}</a></p><p class="fine">Monday–Friday, 9 AM–6 PM ET. Closed on major US holidays.</p></div>
<div class="contact-card"><h3>Based in</h3><p>Massachusetts, USA</p><p class="fine">Serving deal hunters nationwide.</p></div>
</div>
<h2 id="partner">Add your store</h2>
<p>Want your brand featured on CouponDepots? We're onboarding new vendors now. Email <a href="mailto:{EMAIL}?subject=Partnership%20inquiry">{EMAIL}</a> with your brand name, affiliate network (Awin, Impact, CJ, ShareASale) and program ID, and any exclusive codes for our shoppers.</p>
<h2 id="submit">Submit a coupon</h2>
<p>Found a deal we're missing? Send the store, the code or deal, and where you found it. We check every submission against the merchant before publishing.</p>
<form class="contact-form" action="mailto:{EMAIL}" method="post" enctype="text/plain">
<label>Your name<input name="name" autocomplete="name" required></label>
<label>Your email<input name="email" type="email" autocomplete="email" required></label>
<label>Topic<select name="topic"><option>Broken or expired coupon</option><option>Submit a coupon</option><option>Add your store / partnership</option><option>Report an issue</option><option>General inquiry</option></select></label>
<label>Message<textarea name="message" rows="5" required></textarea></label>
<button class="btn btn-gold" type="submit">Send message</button>
<p class="fine">This opens your email app with your message ready to send.</p>
</form>''', eyebrow="Get in touch", img_id="1556742049-0cfed4f6a45d")

    simple_page("/privacy/", "Privacy Notice | CouponDepots",
        "How CouponDepots collects, uses and shares information when you visit coupondepots.info, including cookies, affiliate tracking and your choices.",
        "Privacy Notice",
        "This notice explains how CouponDepots (\"we\" or \"us\") collects, uses and shares information when you use coupondepots.info.",
        f'''<h2>Information you provide</h2>
<p>If you contact us by email, phone or the contact form, we receive the information you choose to send, such as your name, email address and message, and use it to respond to you.</p>
<h2>Information collected automatically</h2>
<p>Like most websites, our hosting and analytics providers may collect device and usage information such as IP address, browser type, pages viewed and referring pages. We use it to keep the site secure and understand which content is useful.</p>
<h2>Cookies and affiliate tracking</h2>
<p>When you click a sponsored link, the affiliate network (for example Awin or Impact) and the merchant may set cookies to attribute your purchase to CouponDepots. Those cookies are governed by their privacy policies. Most browsers let you manage or block cookies in settings; see <a href="https://www.allaboutcookies.org" target="_blank" rel="noopener noreferrer">allaboutcookies.org</a>.</p>
<h2>How we use information</h2>
<ul><li>To operate, maintain and improve the site;</li><li>To respond to your messages and partnership inquiries;</li><li>To measure affiliate performance;</li><li>To detect and prevent fraud and abuse; and</li><li>To comply with legal obligations.</li></ul>
<h2>How we share information</h2>
<p>We don't sell your personal information. We share it only with service providers who help run the site (hosting, analytics, affiliate networks), when required by law, or with your consent.</p>
<h2>Third-party sites</h2>
<p>Our pages link to merchants we don't own or operate. Their privacy practices apply once you leave CouponDepots. Please review their policies before sharing information.</p>
<h2>Children's privacy</h2>
<p>CouponDepots is not directed to children under 13, and we don't knowingly collect their personal information.</p>
<h2>International visitors</h2>
<p>The site is operated from the United States and intended for US shoppers. Information may be processed in the United States.</p>
<h2>Changes and contact</h2>
<p>We'll post any changes on this page. Questions: <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
<p class="fine">Last updated: October 19, 2026</p>''', eyebrow="Legal")

    simple_page("/terms/", "Terms of Use | CouponDepots",
        "Terms of use for coupondepots.info: use of the site, accuracy of offers, affiliate links, third-party merchants, and governing law (Massachusetts).",
        "Terms of Use",
        "CouponDepots (\"we\", \"us\" or \"our\") owns and operates coupondepots.info. By using the site, you agree to these terms.",
        f'''<h2>Use of the site</h2>
<p>We grant you a limited, revocable right to access and use the site for personal, non-commercial purposes. We may change, suspend or discontinue any part of the site at any time without notice.</p>
<h2>Offers and accuracy</h2>
<p>Coupons, prices and promotions are set by merchants and can change or end without notice. We work to keep listings accurate, but we don't guarantee that any offer will be available or applied. Always confirm the final price at the merchant's checkout.</p>
<h2>Affiliate links and third-party merchants</h2>
<p>Some links are affiliate links. Purchases are made with the merchant, not with CouponDepots, and are governed by the merchant's terms, shipping, return and privacy policies. We are not responsible for merchant products, services or content.</p>
<h2>Content standards</h2>
<p>If you submit a coupon or message, you confirm it's accurate and lawful and that you have the right to share it, and you grant us permission to review, edit and publish it. Don't submit content that is unlawful, misleading, infringing, abusive or spam.</p>
<h2>Intellectual property</h2>
<p>Site design, text and graphics are owned by CouponDepots or its licensors. Merchant names and logos belong to their respective owners.</p>
<h2>Disclaimer and limitation of liability</h2>
<p>The site is provided "as is" without warranties of any kind. To the fullest extent permitted by law, CouponDepots is not liable for any indirect or consequential damages arising from use of the site or reliance on any offer.</p>
<h2>Governing law</h2>
<p>These terms are governed by the laws of the Commonwealth of Massachusetts, without regard to conflict-of-law rules.</p>
<h2>Changes and contact</h2>
<p>We may update these terms; changes take effect when posted. Questions: <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
<p class="fine">Last updated: October 19, 2026</p>''', eyebrow="Legal")

# ---------------------------------------------------------------- REDIRECTS (old Airo URLs)
def redirect(old, new):
    target = new if new.startswith("http") else BASE + new
    is_ext = new.startswith("http")
    rel = ' rel="sponsored nofollow"' if is_ext else ""
    canon = "" if is_ext else f'<link rel="canonical" href="{target}">'
    html_ = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Redirecting… | CouponDepots</title>
{canon}<meta name="robots" content="noindex, follow"><meta http-equiv="refresh" content="0; url={e(new)}">
<script>location.replace({json.dumps(new)} + (location.hash||""))</script></head>
<body><p>This page has moved. <a href="{e(new)}"{rel}>Continue to the new page</a>.</p></body></html>'''
    write(old if old.endswith("/") else old + "/", html_)
    REDIRECTS.append((old, new))

REDIRECTS = []
def build_redirects():
    m = {
        "/stores": "/#stores", "/deals": "/#deals", "/store/": "/#stores",
        "/stores/brkox": B["brkox"]["url"], "/coupons/zlike-hair": B["zlike-hair"]["url"],
        "/monvane-coupon-code/": B["monvane"]["url"], "/everblog-coupon-code/": B["everblog"]["url"],
        "/store/best-home-lifestyle-deals-may-2026/": "/blog/best-home-lifestyle-deals-may-2026/",
        "/store/touredge-coupon-code/": "/#stores",
        "/coupons/fashion": "/?cat=fashion#deals", "/coupons/beauty": "/?cat=beauty#deals",
        "/coupons/sports": "/#deals", "/coupons/travel": "/#deals", "/coupons/food-&-dining": "/#deals",
        "/coupons/home": "/?cat=home#deals", "/coupons/electronics": "/#deals",
        "/furniture-coupons/": "/?cat=home#deals", "/home-decor-coupons/": "/?cat=home#deals",
        "/submit-coupon": "/contact/#submit", "/lp/save-more": "/#deals",
        "/go/brkox": B["brkox"]["link"], "/go/monvane": B["monvane"]["link"], "/go/zlike-hair": B["zlike-hair"]["link"],
        "/go/simple-project": B["simple-project"]["link"], "/go/everblog": B["everblog"]["link"], "/go/yeloly": B["yeloly"]["link"],
    }
    for old, new in m.items():
        redirect(old, new)

# ---------------------------------------------------------------- 404, robots, sitemap, llms
def build_404():
    body = f'''<section class="page-hero"><div class="wrap narrow center"><p class="eyebrow">Error 404</p><h1>This page has expired, like an old coupon</h1>
<p class="lead">The page you're looking for doesn't exist or has moved. All of our live offers are on one page.</p>
<p><a class="btn btn-gold" href="/#deals">See all coupons</a> <a class="btn btn-ghost-dark" href="/blog/">Read our guides</a></p></div></section>
<section class="section section-tight"><div class="wrap"><div class="store-grid">{"".join(store_card(b) for b in BRANDS)}</div></div></section>'''
    out = page("/404.html", "Page not found | CouponDepots", "This page could not be found. Browse all CouponDepots partner coupons and deals.", body)
    out = out.replace('<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">', '<meta name="robots" content="noindex, follow">')
    out = re.sub(r'<link rel="canonical"[^>]+>\n', "", out)
    with open(os.path.join(OUT, "404.html"), "w", encoding="utf-8") as f:
        f.write(out)

def build_robots():
    bots = ["GPTBot", "OAI-SearchBot", "ChatGPT-User", "ClaudeBot", "Claude-SearchBot", "PerplexityBot", "Google-Extended", "Applebot-Extended", "Bingbot", "Googlebot"]
    txt = "# CouponDepots robots.txt\nUser-agent: *\nAllow: /\nDisallow: /go/\n\n"
    txt += "".join(f"User-agent: {b}\nAllow: /\nDisallow: /go/\n\n" for b in bots)
    txt += f"Sitemap: {BASE}/sitemap.xml\n"
    open(os.path.join(OUT, "robots.txt"), "w").write(txt)

def build_sitemap():
    rows = "".join(f"  <url>\n    <loc>{BASE}{p}</loc>\n    <lastmod>{lm}</lastmod>\n    <priority>{pr}</priority>\n  </url>\n" for p, lm, pr in SITEMAP)
    xml = f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n{rows}</urlset>\n'
    open(os.path.join(OUT, "sitemap.xml"), "w").write(xml)

def build_llms():
    L = [f"# {SITE}", "",
         "> CouponDepots (coupondepots.info) is a free US coupon and shopping-guide site. Every offer comes from a brand that partners with CouponDepots through an official affiliate network (mainly Awin). All live coupons and deals are on the homepage; each partner has a store guide page.", "",
         f"Last updated: {TODAY}. Contact: {EMAIL}, {PHONE}. Based in Massachusetts, USA.", "",
         "## Current coupon codes and deals"]
    for o in OFFERS:
        b = B[o["brand"]]
        code = f" Code: {o['code']}." if o["type"] == "code" else " No code needed." if o["label"] == "No code needed" else ""
        L.append(f"- {b['name']}: {o['title']}.{code} {o['detail']} Guide: {BASE}{b['url']}")
    L += ["", "## Partner store guides"]
    for b in BRANDS:
        L.append(f"- [{b['name']} coupons]({BASE}{b['url']}): {b['short']}{' Adults 18+ only.' if b.get('adult') else ''}")
    L += ["", "## Shopping guides"]
    for p in POSTS:
        L.append(f"- [{p['title']}]({BASE}{p['url']}): {p['description']}")
    L += ["", "## About and policies",
          f"- [Home: all coupons]({BASE}/)",
          f"- [How we verify coupons]({BASE}/how-we-verify/): Offers are sourced from merchants or official affiliate networks, checked against the merchant's site, and clearly labeled (Partner code, No code needed, Featured product, Partner deal). Codes that can't be confirmed are not listed.",
          f"- [About]({BASE}/about/)", f"- [Affiliate disclosure]({BASE}/disclosure/)", f"- [Contact / partner with us]({BASE}/contact/)",
          f"- [Privacy]({BASE}/privacy/)", f"- [Terms]({BASE}/terms/)", "",
          "## Notes for AI assistants",
          "- Prices and codes are set by merchants and can change; recommend users confirm the discount in their cart.",
          "- Links to merchants are sponsored affiliate links; CouponDepots may earn a commission at no extra cost to the shopper.",
          "- Monvane codes: MONAFF10 (10% off, new customers, one use) and AFF5OFF (5% off, unlimited)."]
    open(os.path.join(OUT, "llms.txt"), "w").write("\n".join(L) + "\n")

# ---------------------------------------------------------------- main
def main():
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)
    shutil.copytree(os.path.join(ROOT, "static"), OUT, dirs_exist_ok=True)
    load_posts()
    build_home()
    for b in BRANDS:
        build_store(b)
    build_blog_index()
    for p in POSTS:
        build_post(p)
    build_info()
    build_redirects()
    build_404()
    build_robots()
    build_sitemap()
    build_llms()
    open(os.path.join(OUT, "CNAME"), "w").write("coupondepots.info\n")
    open(os.path.join(OUT, ".nojekyll"), "w").write("")
    print(f"Built {len(SITEMAP)} indexable pages + {len(REDIRECTS)} redirects into {OUT}")

if __name__ == "__main__":
    main()
