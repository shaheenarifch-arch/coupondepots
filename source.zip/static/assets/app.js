/* CouponDepots: tiny, dependency-free interactions */
(function () {
  "use strict";
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  // year
  $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });

  // mobile nav
  var toggle = $(".nav-toggle"), nav = $("#main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  // toast
  var toast;
  function say(msg) {
    if (!toast) { toast = document.createElement("div"); toast.className = "toast"; toast.setAttribute("role", "status"); document.body.appendChild(toast); }
    toast.textContent = msg; toast.classList.add("show");
    clearTimeout(say.t); say.t = setTimeout(function () { toast.classList.remove("show"); }, 2600);
  }

  // reveal + copy code (link still opens the store in a new tab)
  $$(".reveal").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var code = btn.getAttribute("data-code");
      var label = $(".reveal-label", btn);
      if (label) label.textContent = code;
      btn.classList.add("revealed");
      try {
        if (navigator.clipboard) navigator.clipboard.writeText(code).then(function () { say("Code " + code + " copied. Paste it at checkout."); }, function () { say("Your code: " + code); });
        else say("Your code: " + code);
      } catch (e) { say("Your code: " + code); }
    });
  });

  // deal-alerts signup: the visitor fills in the form on the page; a message confirms it (no email app opens).
  // FormSubmit answers with JSON; the Apps Script web app is posted to without reading the reply.
  $$("form[data-signup]").forEach(function (f) {
    var msg = $(".signup-msg", f);
    function show(text, bad) { if (msg) { msg.textContent = text; msg.hidden = false; msg.classList.toggle("err", !!bad); } say(text); }
    f.addEventListener("submit", function (ev) {
      ev.preventDefault();
      if (f._honey && f._honey.value) return; // bot trap
      var btn = $("button", f); if (btn) btn.disabled = true;
      var json = f.action.indexOf("formsubmit.co") !== -1;
      var req = json
        ? fetch(f.action, { method: "POST", headers: { Accept: "application/json" }, body: new FormData(f) }).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        : fetch(f.action, { method: "POST", mode: "no-cors", body: new FormData(f) });
      req.then(function () { f.reset(); show("Thanks! You're on the list. Watch your inbox for deal alerts."); })
         .catch(function () { show("Sorry, that didn't go through. Please try again in a minute.", true); })
         .then(function () { if (btn) btn.disabled = false; });
    });
  });

  // contact form: topic from the link (#submit, #partner), coupon fields per topic, sent on the page (no email app).
  // Help: https://formsubmit.co/ajax-documentation
  var cf = $("form[data-contact]");
  if (cf) {
    var topic = $("#cf-topic", cf), groups = $$(".cf-coupon", cf), cmsg = $(".cf-msg", cf), txt = $("#cf-message", cf);
    function sync() {
      groups.forEach(function (g) {
        var on = g.getAttribute("data-for").split("|").indexOf(topic.value) !== -1;
        g.hidden = !on;
        $$("[data-req]", g).forEach(function (i) { i.required = on; });
      });
      if (txt) txt.required = !(topic.value === "Submit a coupon" || topic.value === "Broken or expired coupon");
      cf._subject.value = "CouponDepots: " + topic.value;
    }
    function fromHash() {
      var h = location.hash;
      if (h === "#partner") topic.value = "Add your store / partnership";
      else if (h === "#submit") topic.value = "Submit a coupon";
      else if (h === "#broken") topic.value = "Broken or expired coupon";
      sync();
    }
    topic.addEventListener("change", sync);
    window.addEventListener("hashchange", fromHash);
    fromHash();
    function cshow(t, bad) { cmsg.textContent = t; cmsg.hidden = false; cmsg.classList.toggle("err", !!bad); say(t); }
    cf.addEventListener("submit", function (ev) {
      ev.preventDefault();
      if (cf._honey && cf._honey.value) return; // bot trap
      if (!cf.checkValidity()) { cf.reportValidity(); return; }
      var btn = $("button", cf); btn.disabled = true;
      fetch(cf.action, { method: "POST", headers: { Accept: "application/json" }, body: new FormData(cf) })
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(function () { var t = topic.value; cf.reset(); topic.value = t; sync(); cshow("Thanks! Your message reached our team. We'll check it and reply within 24 hours."); })
        .catch(function () { cshow("Sorry, that didn't go through. Please try again, or email admin@coupondepots.info.", true); })
        .then(function () { btn.disabled = false; });
    });
  }

  // "Ends in" labels on deals stay correct between daily rebuilds (US Eastern dates from the merchant).
  var MON = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  $$("[data-ends]").forEach(function (el) {
    var p = el.getAttribute("data-ends").split("-"), end = new Date(+p[0], +p[1] - 1, +p[2]), now = new Date();
    now.setHours(0, 0, 0, 0);
    var d = Math.round((end - now) / 864e5);
    var when = MON[end.getMonth()] + " " + end.getDate() + ", " + end.getFullYear();
    if (d < 0) { var card = el.closest(".deal, .soon-tile"); if (card) card.hidden = true; el.textContent = "Ended " + when; return; }
    el.textContent = (d === 0 ? "Ends today" : d === 1 ? "Ends tomorrow" : d + " days left") + " · " + when;
  });

  // Things to do: show one city at a time (Boston first). ?city=paris opens Paris. Without JS every city shows.
  var cityBlocks = $$("[data-city]");
  if (cityBlocks.length) {
    var picks = $$("[data-city-pick]");
    function showCity(slug) {
      var hit = false;
      cityBlocks.forEach(function (b) { var on = b.getAttribute("data-city") === slug; b.hidden = !on; if (on) hit = true; });
      picks.forEach(function (p) { var on = p.getAttribute("data-city-pick") === slug; p.classList.toggle("is-active", on); p.setAttribute("aria-current", on ? "true" : "false"); });
      var none = $("#city-empty"); if (none) none.hidden = hit;
    }
    picks.forEach(function (p) {
      p.addEventListener("click", function (ev) {
        ev.preventDefault();
        var slug = p.getAttribute("data-city-pick");
        showCity(slug);
        try { history.replaceState(null, "", "/things-to-do/?city=" + slug); } catch (e) {}
        var blk = $("#city-" + slug); if (blk) blk.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
    var start = "boston";
    try { start = new URLSearchParams(location.search).get("city") || "boston"; } catch (e) {}
    showCity(start);
  }

  // filter + search (home)
  var grid = $("#coupon-grid");
  if (!grid) return;
  var cards = $$(".coupon", grid), chips = $$(".chip"), q = $("#q"), empty = $("#empty");
  var state = { f: "all", q: "", min: "0", sort: "featured" };
  var fMin = $("#f-min"), fSort = $("#f-sort"), count = $("#deal-count");
  function apply() {
    var shown = 0;
    cards.forEach(function (c) {
      var okF = state.f === "all" || c.dataset.cat === state.f || c.dataset.type === state.f;
      var okQ = !state.q || state.q.split(/\s+/).every(function (w) { return c.dataset.search.indexOf(w) !== -1; });
      var okM = state.min === "0" || (state.min === "d" ? +c.dataset.amt > 0 : +c.dataset.pct >= +state.min);
      var ok = okF && okQ && okM; c.hidden = !ok; if (ok) shown++;
    });
    if (empty) empty.hidden = shown !== 0;
    if (count) count.textContent = shown === cards.length ? "Showing all " + shown + " deals" : "Showing " + shown + " of " + cards.length + " deals";
  }
  // sort: featured keeps the page order; others reorder the cards (no-date offers go last for "Ending soonest")
  function sortCards() {
    var key = {
      featured: function (c) { return +c.dataset.i; },
      pct: function (c) { return -(+c.dataset.pct); },
      amt: function (c) { return -(+c.dataset.amt); },
      ends: function (c) { return c.dataset.exp ? Date.parse(c.dataset.exp) : 9e15; },
      "new": function (c) { return +c.dataset.order; }
    }[state.sort] || function (c) { return +c.dataset.i; };
    cards.slice().sort(function (a, b) { return key(a) - key(b) || (+a.dataset.i - +b.dataset.i); }).forEach(function (c) { grid.appendChild(c); });
    cards.forEach(function (c) { c.classList.toggle("deal-featured", state.sort === "featured" && c.dataset.i === "0"); });
  }
  cards.forEach(function (c, i) { c.dataset.i = i; });
  if (fMin) fMin.addEventListener("change", function () { state.min = fMin.value; apply(); });
  if (fSort) fSort.addEventListener("change", function () { state.sort = fSort.value; sortCards(); });

  // instant search: every deal, store and city, from the JSON on the page
  var idx = [];
  try { idx = JSON.parse(($("#search-index") || {}).textContent || "[]"); } catch (e) {}
  var box = $("#q-results"), on = -1;
  function esc(s) { return String(s).replace(/[&<>"]/g, function (ch) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]; }); }
  function suggest() {
    if (!box || !q) return;
    var t = q.value.trim().toLowerCase();
    if (t.length < 2) { box.hidden = true; q.setAttribute("aria-expanded", "false"); return; }
    var ws = t.split(/\s+/);
    var hits = idx.filter(function (it) { return ws.every(function (w) { return it.x.indexOf(w) !== -1; }); }).slice(0, 8);
    on = -1;
    box.innerHTML = hits.length ? hits.map(function (it, i) {
      return '<a role="option" id="qr-' + i + '" href="' + esc(it.u) + '"><i>' + esc(it.k) + '</i><span><b>' + esc(it.t) + '</b><small>' + esc(it.b) + '</small></span><em>' + esc(it.d) + '</em></a>';
    }).join("") : '<p class="q-empty">No matches. Try a store name like Bedsure, or a word like "sofa".</p>';
    box.hidden = false; q.setAttribute("aria-expanded", "true");
  }
  if (q && box) {
    q.addEventListener("input", suggest);
    q.addEventListener("keydown", function (ev) {
      var opts = $$("a", box);
      if (box.hidden || !opts.length) return;
      if (ev.key === "ArrowDown" || ev.key === "ArrowUp") {
        ev.preventDefault();
        on = (on + (ev.key === "ArrowDown" ? 1 : -1) + opts.length) % opts.length;
        opts.forEach(function (o, i) { o.classList.toggle("is-on", i === on); });
        q.setAttribute("aria-activedescendant", opts[on].id);
      } else if (ev.key === "Enter" && on >= 0) { ev.preventDefault(); location.href = opts[on].getAttribute("href"); }
      else if (ev.key === "Escape") { box.hidden = true; q.setAttribute("aria-expanded", "false"); }
    });
    document.addEventListener("click", function (ev) { if (!box.contains(ev.target) && ev.target !== q) { box.hidden = true; q.setAttribute("aria-expanded", "false"); } });
  }
  function setFilter(f) {
    state.f = f;
    chips.forEach(function (ch) { var on = ch.dataset.filter === f; ch.classList.toggle("is-active", on); ch.setAttribute("aria-pressed", on ? "true" : "false"); });
    apply();
  }
  chips.forEach(function (ch) { ch.addEventListener("click", function () { setFilter(ch.dataset.filter); }); });
  if (q) {
    q.addEventListener("input", function () { state.q = q.value.trim().toLowerCase(); apply(); });
    var form = q.form;
    if (form) form.addEventListener("submit", function () { var d = $("#deals"); if (d) d.scrollIntoView({ behavior: "smooth" }); });
  }
  var catLinks = $$("[data-cat-link]");
  function markCat(f) { catLinks.forEach(function (l) { l.classList.toggle("is-active", l.getAttribute("data-cat-link") === f); }); }
  catLinks.forEach(function (l) {
    l.addEventListener("click", function (ev) {
      ev.preventDefault();
      var f = l.getAttribute("data-cat-link");
      setFilter(f); markCat(f);
      try { history.replaceState(null, "", f === "all" ? "/#deals" : "/?cat=" + f + "#deals"); } catch (e) {}
      var d = $("#deals"); if (d) d.scrollIntoView({ behavior: "smooth" });
    });
  });
  chips.forEach(function (ch) { ch.addEventListener("click", function () { markCat(ch.dataset.filter); }); });
  var reset = $("[data-reset]");
  if (reset) reset.addEventListener("click", function () { if (q) q.value = ""; state.q = ""; state.min = "0"; if (fMin) fMin.value = "0"; setFilter("all"); });
  // deep links: ?cat=home  ?q=monvane
  try {
    var p = new URLSearchParams(location.search);
    if (p.get("q") && q) { q.value = p.get("q"); state.q = p.get("q").toLowerCase(); }
    if (p.get("cat")) { setFilter(p.get("cat")); markCat(p.get("cat")); } else { apply(); markCat("all"); }
  } catch (e) { apply(); }
})();
