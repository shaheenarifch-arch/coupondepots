#!/usr/bin/env python3
"""Download merchant images listed in images.json from each brand's Shopify CDN
and save optimized WebP sizes + a 1200x630 JPG social image into img/.
Existing files are kept, so images only download once (run by the deploy Action)."""
import io, json, os, sys, urllib.request
from PIL import Image

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "img")
STEPS = [480, 800, 1200, 1600, 2000]
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
os.makedirs(OUT, exist_ok=True)
failed = 0
for d in json.load(open(os.path.join(ROOT, "images.json"))):
    name = d["name"]
    widths = [x for x in STEPS if x < d["w"]] + [min(d["w"], 2000)]
    targets = [f"{name}-{w}.webp" for w in widths] + [f"{name}-og.jpg"]
    if all(os.path.exists(os.path.join(OUT, t)) for t in targets):
        print("ok (cached)", name); continue
    try:
        req = urllib.request.Request(f'{d["src"]}?width={min(d["w"], 2400)}', headers={"User-Agent": UA, "Accept": "image/jpeg,image/*"})
        im = Image.open(io.BytesIO(urllib.request.urlopen(req, timeout=60).read())).convert("RGB")
    except Exception as ex:
        print("FAILED", name, ex); failed += 1; continue
    for w in widths:
        h = round(im.height * w / im.width)
        im.resize((w, h), Image.LANCZOS).save(os.path.join(OUT, f"{name}-{w}.webp"), "WEBP", quality=84, method=6)
    # social image 1200x630, cropped around the focal point
    px, py = [float(v.strip("%")) / 100 for v in d.get("pos", "50% 50%").split()]
    scale = max(1200 / im.width, 630 / im.height)
    r = im.resize((round(im.width * scale), round(im.height * scale)), Image.LANCZOS)
    left = min(max(0, round(r.width * px - 600)), r.width - 1200)
    top = min(max(0, round(r.height * py - 315)), r.height - 630)
    r.crop((left, top, left + 1200, top + 630)).save(os.path.join(OUT, f"{name}-og.jpg"), "JPEG", quality=86, optimize=True, progressive=True)
    print("saved", name, widths)
sys.exit(1 if failed else 0)
