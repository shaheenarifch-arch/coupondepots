/* CouponDepots: tiny, dependency-free interactions */
(function () {
  "use strict";
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  // year
  $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });

  // mobile nav
  var toggle = $(".nav-toggle"), nav = $("#main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  // toast
  var toast;
  function say(msg) {
    if (!toast) { toast = document.createElement("div"); toast.className = "toast"; toast.setAttribute("role", "status"); document.body.appendChild(toast); }
    toast.textContent = msg; toast.classList.add("show");
    clearTimeout(say.t); say.t = setTimeout(function () { toast.classList.remove("show"); }, 2600);
  }

  // reveal + copy code (link still opens the store in a new tab)
  $$(".reveal").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var code = btn.getAttribute("data-code");
      var label = $(".reveal-label", btn);
      if (label) label.textContent = code;
      btn.classList.add("revealed");
      try {
        if (navigator.clipboard) navigator.clipboard.writeText(code).then(function () { say("Code " + code + " copied. Paste it at checkout."); }, function () { say("Your code: " + code); });
        else say("Your code: " + code);
      } catch (e) { say("Your code: " + code); }
    });
  });

  // deal-alerts signup: the visitor fills in the form on the page; a message confirms it (no email app opens).
  // FormSubmit answers with JSON; the Apps Script web app is posted to without reading the reply.
  $$("form[data-signup]").forEach(function (f) {
    var msg = $(".signup-msg", f);
    function show(text, bad) { if (msg) { msg.textContent = text; msg.hidden = false; msg.classList.toggle("err", !!bad); } say(text); }
    f.addEventListener("submit", function (ev) {
      ev.preventDefault();
      if (f._honey && f._honey.value) return; // bot trap
      var btn = $("button", f); if (btn) btn.disabled = true;
      var json = f.action.indexOf("formsubmit.co") !== -1;
      var req = json
        ? fetch(f.action, { method: "POST", headers: { Accept: "application/json" }, body: new FormData(f) }).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        : fetch(f.action, { method: "POST", mode: "no-cors", body: new FormData(f) });
      req.then(function () { f.reset(); show("Thanks! You're on the list. Watch your inbox for deal alerts."); })
         .catch(function () { show("Sorry, that didn't go through. Please try again in a minute.", true); })
         .then(function () { if (btn) btn.disabled = false; });
    });
  });

  // filter + search (home)
  var grid = $("#coupon-grid");
  if (!grid) return;
  var cards = $$(".coupon", grid), chips = $$(".chip"), q = $("#q"), empty = $("#empty");
  var state = { f: "all", q: "" };
  function apply() {
    var shown = 0;
    cards.forEach(function (c) {
      var okF = state.f === "all" || c.dataset.cat === state.f || c.dataset.type === state.f;
      var okQ = !state.q || c.dataset.search.indexOf(state.q) !== -1;
      var ok = okF && okQ; c.hidden = !ok; if (ok) shown++;
    });
    if (empty) empty.hidden = shown !== 0;
  }
  function setFilter(f) {
    state.f = f;
    chips.forEach(function (ch) { var on = ch.dataset.filter === f; ch.classList.toggle("is-active", on); ch.setAttribute("aria-pressed", on ? "true" : "false"); });
    apply();
  }
  chips.forEach(function (ch) { ch.addEventListener("click", function () { setFilter(ch.dataset.filter); }); });
  if (q) {
    q.addEventListener("input", function () { state.q = q.value.trim().toLowerCase(); apply(); });
    var form = q.form;
    if (form) form.addEventListener("submit", function () { var d = $("#deals"); if (d) d.scrollIntoView({ behavior: "smooth" }); });
  }
  var reset = $("[data-reset]");
  if (reset) reset.addEventListener("click", function () { if (q) q.value = ""; state.q = ""; setFilter("all"); });
  // deep links: ?cat=home  ?q=monvane
  try {
    var p = new URLSearchParams(location.search);
    if (p.get("q") && q) { q.value = p.get("q"); state.q = p.get("q").toLowerCase(); }
    if (p.get("cat")) setFilter(p.get("cat")); else apply();
  } catch (e) { apply(); }
})();
